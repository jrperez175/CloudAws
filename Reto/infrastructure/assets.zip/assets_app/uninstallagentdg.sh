#!/bin/sh

set -x



TOKENVSTS=$tokenvsts
IDDGVSTS="918"
HOSTNAME=$(hostname)

AUTH=$(echo -ne "svchca04@bancolombia.com.co:$TOKENVSTS" | base64 --wrap 0)


urlTASKAPI="https://dev.azure.com/GrupoBancolombia/b267af7c-3233-4ad1-97b3-91083943100d/_apis/distributedtask/deploymentgroups/$IDDGVSTS/targets"

url=$(echo "${urlTASKAPI}?api-version=6.0-preview.1&name=${HOSTNAME}")

agenttodelete=$(curl --location --request GET "$url" --header "Content-Type: application/json" --header "Authorization: Basic $AUTH" |jq -r '.value[].id')

url=$(echo "$urlTASKAPI/${agenttodelete}?api-version=5.1-preview.1")
curl --location --request DELETE "$url"        --header "Authorization: Basic $AUTH"