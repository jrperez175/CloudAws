#!/bin/bash
set -ex

TOKENAGENT=$tokenvsts
tag1=$tagEnv
tag2=$tagMurexEnv
IDDGVSTS="918"

printf -v tagdg "%s-%s" $tag1 $tag2

HOSTNAME=$(hostname)

PATHWORK_AGENT="/tmp/assets/azagent"
##########Eliminar Offline
AUTH=$(echo -ne "svchca04@bancolombia.com.co:$TOKENAGENT" | base64 --wrap 0)
urlTASKAPI="https://dev.azure.com/GrupoBancolombia/b267af7c-3233-4ad1-97b3-91083943100d/_apis/distributedtask/deploymentgroups/$IDDGVSTS/targets"
url=$(echo "$urlTASKAPI/?api-version=5.1-preview.1%0A&agentStatus=offline")

offlineagent=$(curl --location --request GET "$url" --header "Content-Type: application/json" --header "Authorization: Basic $AUTH" |jq -r '.value[].id')

for IDAGENT in ${offlineagent[@]};do
        url=$(echo "$urlTASKAPI/${IDAGENT}?api-version=5.1-preview.1")
        curl --location --request DELETE "$url" --header "Authorization: Basic $AUTH"
done
#############


$PATHWORK_AGENT/config.sh remove --auth PAT --token ${TOKENAGENT}

cd $PATHWORK_AGENT
sleep 60
cd ${PATHWORK_AGENT} && ${PATHWORK_AGENT}/config.sh --unattended --deploymentgroup --deploymentgroupname aw0434001_murex_core \
            --acceptteeeula --agent $HOSTNAME --url https://grupobancolombia.visualstudio.com/  \
            --work _work --projectname 'Vicepresidencia Servicios de Tecnología' \
            --auth PAT --token $TOKENAGENT \
             --addDeploymentGroupTags --deploymentGroupTags $tagdg


chown murex:murex -R ${PATHWORK_AGENT}

#ps -fea | awk '/azagent/{system("kill -2 "$2)}'
#sleep 60
echo "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin/:/usr/local/java/jdk1.7.0_151/bin:/usr/local/java/jdk1.7.0_151/jre/bin:/opt/oracle/11204_64/bin/" > ${PATHWORK_AGENT}/.path
PATH="/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin/:/usr/local/java/jdk1.7.0_151/bin:/usr/local/java/jdk1.7.0_151/jre/bin:/opt/oracle/11204_64/bin/"
cd ${PATHWORK_AGENT} && ${PATHWORK_AGENT}/run.sh > ${PATHWORK_AGENT}/agentout &
#if [ -f "${PATHWORK_AGENT}/.path" ]; then
#    # configure
#    export PATH=`cat ${PATHWORK_AGENT}/.path`
#    echo "${PATHWORK_AGENT}/.path=${PATH}"
#fi
#${PATHWORK_AGENT}/externals/node/bin/node ${PATHWORK_AGENT}/bin/AgentService.js &