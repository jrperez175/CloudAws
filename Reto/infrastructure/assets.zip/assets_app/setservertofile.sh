#!/bin/bash

set -ex

export HOSTNAME=$(hostname)
export PATHASSETS="/tmp/assets"
export EC2_INSTANCE_ID="`wget -q -O - http://169.254.169.254/latest/meta-data/instance-id || die \"wget instance-id has failed: $?\"`"
export ENV=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$EC2_INSTANCE_ID" "Name=key,Values=bancolombia:environment" --query 'Tags[].{Value:Value}' --output text)

export VARQUERY="`$PATHASSETS/findtag.sh`"
export TAGBYSERVER="$PATHASSETS/tagbyserver.json"
export PATHFILESRV="/murex/murex_app/app"

export FILESERVER="`jq -r .$VARQUERY $TAGBYSERVER`"

echo $HOSTNAME >> $PATHFILESRV/$FILESERVER

if [ $ENV == 'dev' ] && [ $FILESERVER == 'servidores_BS' ] && [ -e /murex/murex_app/app/servidores_BS ];
then
  head -n 1 $PATHFILESRV/$FILESERVER > $PATHFILESRV/servidores_WF
fi

if [ $ENV == 'qa' ] && [ $FILESERVER == 'servidores_BS' ] && [ -e /murex/murex_app/app/servidores_BS ];
then
  head -n 1 $PATHFILESRV/$FILESERVER > $PATHFILESRV/servidores_WF
fi
