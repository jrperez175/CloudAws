#!/bin/bash
#Registrar el hostname en Route53
aws lambda invoke --function-name aw0434001-murex-core-$env-DNS --cli-binary-format raw-in-base64-out --payload  '{ "zona": "'"$HOSTEDZONEID"'" , "dominio": "'"$DOMAIN"'" , "dns": "'"$HOSTNAME"'", "ip": "'"$EC2_LOCAL_IPV4"'", "action": "add","sharedserviceaccount": "'"$IDACCOUNTSRV"'" }' out --log-type Tail

aws lambda invoke --function-name aw0434001-murex-core-$env-DNS --cli-binary-format raw-in-base64-out --payload  '{ "zona": "'"$HOSTEDZONEID"'" , "dominio": "'"$DOMAIN"'" , "dns": "'"$DNSALL"'", "ip": "'"$EC2_LOCAL_IPV4"'", "action": "add","sharedserviceaccount": "'"$IDACCOUNTSRV"'" }' out --log-type Tail

aws lambda invoke --function-name aw0434001-murex-core-$env-DNS --cli-binary-format raw-in-base64-out --payload '{ "zona": "'"$HOSTEDZONEID"'" , "dominio": "'"$DOMAIN"'" , "dns": "'"$DNSROLE"'", "ip": "'"$EC2_LOCAL_IPV4"'", "action": "add","sharedserviceaccount": "'"$IDACCOUNTSRV"'" }' out --log-type Tail
