# Cloudwatch Agent for Murex Metrics

Collects non-Murex and Murex specific metrics and pushes them into cloudwatch custom metrics store.

# installation on RHEL:
0. Install yum requirements for repo
```bash
sudo yum groupinstall 'Development Tools' -y
sudo yum install git -y
```
1. Clone the repo murex_cloudwatch to /opt/
```bash
sudo runuser -l murex -c 'python3 -m pip install pip --upgrade --user'
sudo runuser -l murex -c 'python3 -m pip install git-remote-codecommit --user'
cd /opt
sudo git clone codecommit::us-east-1://cwagent_murex
sudo chown murex:murex /opt/cwagent_murex
sudo chmod +x /opt/cwagent_murex/cwagent_*.py
```
2. Install yum requirements for cwagent_murex
```bash
sudo wget https://www.rpmfind.net/linux/centos/7.8.2003/os/x86_64/Packages/python3-devel-3.6.8-13.el7.x86_64.rpm -O "/tmp/python3-devel.rpm"
sudo yum install /tmp/python3-devel.rpm -y
```
3. Install python3 requirements for cwagent_murex
```python
sudo runuser -l murex -c 'python3 -m pip install -r /opt/cwagent_murex/requirements.txt --user'
```

# configuration on RHEL:
1. Configure cwagent_murex
```bash
sudo runuser -l murex -c 'vi /opt/cwagent_murex/config.yml'
```
2. Switch to user murex now
```bash
sudo su - murex
. /home/murex/.bash_profile
```
3. Test cwagent_murex
```bash
/opt/cwagent_murex/cwagent_test_output.py
```
4. Create inital metrics and send to cloudwatch custom namespace
```bash
/opt/cwagent_murex/cwagent_create_inital_metrics.py
```

5. Configure Systemd for cwagent_murex
If you change aws Default region name or profile, then you need to set these values in /opt/cwagent_murex/systemd/cwagent_murex.service
```bash
sudo cp /opt/cwagent_murex/systemd/cwagent_murex.service /etc/systemd/system/
sudo systemctl enable cwagent_murex
sudo systemctl daemon-reload (note: only if you change config)
sudo systemctl start cwagent_murex
sudo systemctl status cwagent_murex
```

6. Helper Script: If JMX module is used and RMI endpoints are defined in config.yml, this scripts will list all available JMX metrics which can be used for cloudwatch
```bash
. /home/murex/.bash_profile  (Note: if logged in as root)
/opt/cwagent_murex/cwagent_jmx_list_available_metrics.py
```

7. Helper Script: Test all Sqls (COunt/Error Checks) defined
```bash
. /home/murex/.bash_profile  (Note: if logged in as root)
/opt/cwagent_murex/cwagent_test_sqls.py
```

# general:
Please see config.yml

# IAM Role:
Please see iam\MurexCloudwatchAgent.json and replace 1234567890123 with you AWS Account ID

# installation on AWS Cloudwatch:
1. Goto to AWS Cloudwatch and import dashboards from folder /opt/murex_cloudwatch/aws-dashboards (Note: replace mx_environment_value, mx_role_value, mx_host_value accordingly)

# Cloudwatch Costs
Costs are measured per region, per metric per API call - for more details see https://aws.amazon.com/cloudwatch/pricing/?nc1=h_ls
In a nutshell, the more metrics you activate, the higher your cloudwatch costs will be per Murex environment. Only activate what you need to monitor your environment.


# Links
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/create-cloudwatch-agent-configuration-file-wizard.html
https://developer.nvidia.com/cuda-downloads?target_os=Linux&target_arch=x86_64&target_distro=RHEL&target_version=8&target_type=rpmlocal follow https://www.nvidia.de/content/DriverDownload-March2009/confirmation.php?url=/tesla/440.64.00/NVIDIA-Linux-x86_64-440.64.00.run&lang=de&type=Tesla
https://github.com/dgildeh/JMXQuery/blob/master/java/README.md
