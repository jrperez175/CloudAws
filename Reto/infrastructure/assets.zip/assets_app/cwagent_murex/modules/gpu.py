# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

# Links
# https://pypi.org/project/nvgpu/
# Requires nvidia-smi binary (Install latest nvidia driver, respectively cuda)
# Optional run nvidia-smi asa daemon --> sudo nvidia-smi daemon

import nvgpu
import yaml
import modules.logger

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)


def force_deactivation():
    '''
        Function to check if one ore more GPUs are installed
    '''
    try:
        nvgpu.available_gpus()
    except:
        modules.logger.info('Module GPU is activated in configuration. No GPU Hardware found. Module was forced deactivated.')
        return True
    else:
        return False


def get_utilisation():
    '''
        Function to get utilisation of GPUS
    '''

    gpus = []

    # each gpus
    gpus_stats = nvgpu.gpu_info()
    for gpu in gpus_stats:
        gpus.append({
            "gpu_name": 'gpu{}'.format(gpu['index']),  # not included in cloudwatch montoring
            "gpu_type": gpu['type'],  # not included in cloudwatch montoring
            "gpu_mem_total_gigabytes": float(gpu['mem_total']) / 1024,  # not included in cloudwatch montoring
            "gpu_mem_used_gigabytes": float(gpu['mem_used']) / 1024,  # not included in cloudwatch montoring
            "gpu_mem_used_percent": gpu['mem_used_percent'],  # not included in cloudwatch montoring
                    })

    return(gpus)


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics
    '''
    metrics = []
    gpus = get_utilisation()
    for gpu in gpus:

        if cfg['gpu']['gpu_mem_total_gigabytes']:
            metric = {
                    'MetricName': 'gpu_mem_total_gigabytes',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'gpu',
                            'Value': gpu['gpu_name']
                        },
                        {
                            'Name': 'type',
                            'Value': gpu['gpu_type']
                        },
                    ],
                    'Unit': 'Gigabytes',
                    'Value': gpu['gpu_mem_total_gigabytes']
                }
            metrics.append(metric)

        if cfg['gpu']['gpu_mem_used_gigabytes']:
            metric = {
                    'MetricName': 'gpu_mem_used_gigabytes',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'gpu',
                            'Value': gpu['gpu_name']
                        },
                        {
                            'Name': 'type',
                            'Value': gpu['gpu_type']
                        },
                    ],
                    'Unit': 'Gigabytes',
                    'Value': gpu['gpu_mem_used_gigabytes']
                }
            metrics.append(metric)

        if cfg['gpu']['gpu_mem_used_percent']:
            metric = {
                    'MetricName': 'gpu_mem_used_percent',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'gpu',
                            'Value': gpu['gpu_name']
                        },
                        {
                            'Name': 'type',
                            'Value': gpu['gpu_type']
                        },
                    ],
                    'Unit': 'Percent',
                    'Value': gpu['gpu_mem_used_percent']
                }
            metrics.append(metric)

    return(metrics)
