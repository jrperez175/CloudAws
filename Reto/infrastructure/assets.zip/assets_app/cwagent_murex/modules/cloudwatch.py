# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import boto3
import yaml
import modules.hostname
import modules.payload
import modules.logger
import modules.cpu
import modules.database
import modules.disks
import modules.files
import modules.gpu
import modules.network
import modules.processes
import modules.ram
import modules.jmx
import modules.ec2
import modules.server

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

# Create Cloudwatch Client
cloudwatch = boto3.client(service_name='cloudwatch', region_name=cfg['general']['aws_region'])
mx_environment_value, mx_role_value = modules.ec2.get_cloudwatch_tags()

# manual or automatic cloudwatch_namespace
if cfg['general']['cloudwatch_namespace_manual']:
    cloudwatch_namespace = cfg['general']['cloudwatch_namespace']
else:
    cloudwatch_namespace = mx_environment_value


class Module():
    '''
        Class to define orchestration for modules to be used with cloudwatch
    '''

    def __init__(self, module_name):
        # Variable definition
        self.module_name = module_name
        self.module_error = False
        self.module_skip_messages = False
        self.module_host_name = modules.hostname.get_name()
        self.module_metrics_class = self.module_name.upper()
        self.module_cloudwatch_namespace = cloudwatch_namespace
        self.module_mx_environment_value = mx_environment_value
        self.module_mx_role_value = mx_role_value

        # Set active or deactive
        if cfg['modules'][self.module_name]['enabled']:
            self.module_enable = True
        else:
            self.module_enable = False

        # Check if GPU Hardware is available and if not deactivate GPU module
        if self.module_name == 'gpu':
            if modules.gpu.force_deactivation():
                self.module_enable = False

        # Check if JMX required Murexcredential file is accessible for authentification
        if self.module_name == 'jmx':
            if modules.jmx.force_deactivation():
                self.module_enable = False

    def send_metrics(self):
        '''
            Function to send metrics to cloudwatch
        '''
        self.metrics_payload = None

        # Execute
        if self.module_enable:

            # Create payload
            if self.module_name == 'server':
                self.metrics_payload = modules.server.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'cpu':
                self.metrics_payload = modules.cpu.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'database':
                self.metrics_payload = modules.database.cwatch_router(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'disks':
                self.metrics_payload = modules.disks.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'files':
                self.metrics_payload = modules.files.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'gpu':
                self.metrics_payload = modules.gpu.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'network':
                self.metrics_payload = modules.network.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'processes':
                self.metrics_payload = modules.processes.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'ram':
                self.metrics_payload = modules.ram.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            elif self.module_name == 'jmx':
                self.metrics_payload = modules.jmx.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
            else:
                if self.module_skip_messages is False:
                    modules.logger.error(f'Module {self.module_metrics_class} is disabled due to "no module found" error.')  # TODO raise error
                self.module_enable = False
                self.module_skip_messages = True

        if self.module_enable:
            try:
                self.response = modules.payload.send_metrics(self.module_metrics_class, self.metrics_payload, self.module_cloudwatch_namespace)
            except:
                modules.logger.error(f'Module {self.module_metrics_class} had error {str(self.response)}.')
                self.module_enable = False
        else:
            if self.module_skip_messages is False:
                modules.logger.debug(f'Module {self.module_metrics_class} is disabled.')
                self.module_skip_messages = True

    def print_metrics(self):
        '''
            Function to send metrics to cloudwatch
        '''
        self.metrics_payload = None

        # Execute
        if self.module_enable:

            # Create payload
            if self.module_name == 'server':
                self.metrics_payload = modules.server.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('----------------------- S E R V E R --------------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
                print('--------------------------------------------------------------------')
                print('')

            elif self.module_name == 'cpu':
                self.metrics_payload = modules.cpu.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ C P U -------------------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
                print('--------------------------------------------------------------------')
                print('')

            elif self.module_name == 'database':
                self.metrics_payload = modules.database.cwatch_router(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ D A T A B A S E ---------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
                print('--------------------------------------------------------------------')
                print('')

            elif self.module_name == 'disks':
                self.metrics_payload = modules.disks.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ D I S K S ---------------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
                print('--------------------------------------------------------------------')
                print('')

            elif self.module_name == 'files':
                self.metrics_payload = modules.files.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ F I L E S ---------------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
                print('--------------------------------------------------------------------')
                print('')

            elif self.module_name == 'gpu':
                self.metrics_payload = modules.gpu.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ G P U -------------------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
                print('--------------------------------------------------------------------')
                print('')

            elif self.module_name == 'network':
                self.metrics_payload = modules.network.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ N E T W O R K -----------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
                print('--------------------------------------------------------------------')
                print('')

            elif self.module_name == 'processes':
                self.metrics_payload = modules.processes.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ P R O C E S S E S -------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
                print('--------------------------------------------------------------------')
                print('')

            elif self.module_name == 'ram':
                self.metrics_payload = modules.ram.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ R A M -------------------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)

            elif self.module_name == 'jmx':
                self.metrics_payload = modules.jmx.cwatch_metrics(self.module_mx_environment_value, self.module_mx_role_value, self.module_host_name)
                print('--------------------------------------------------------------------')
                print('------------------------ J M X -------------------------------------')
                print('--------------------------------------------------------------------')
                for self.x in self.metrics_payload:
                    print(self.x)
            else:
                modules.logger.error(f'Module {self.module_metrics_class} is not printing due to "no module found" error.')  # TODO raise error
