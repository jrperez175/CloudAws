# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import boto3
import yaml
import modules.logger

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

cloudwatch = boto3.client(service_name='cloudwatch', region_name=cfg['general']['aws_region'])

# The collection MetricData must not have a size greater than 20
collection_size = 20


def send_metrics(metrics_class, metrics_payload, cloudwatch_namespace):
    '''
        Function to send payload to cloudwatch
    '''
    # Process Payload within collections (to save put_metric_data calls)
    metrics_payload_size = len(metrics_payload)
    metric_payload_counter = 0
    metric_cloudwatch_counter = 0
    cloudwatch_collection_counter = 0
    metrics = []
    for metric in metrics_payload:

        metric_name = metric['MetricName']
        if len(metric['Dimensions']) == 4:
            metric_item = metric['Dimensions'][3]['Value']
            metric_string = f'{metric_item}-{metric_name}'
        else:
            metric_item = None
            metric_string = metric_item

        # Add metric
        metric_payload_counter += 1
        metric_cloudwatch_counter += 1
        if [metric] != []:
            metrics.append(metric)
        else:
            modules.logger.warning(f'{metrics_class} metrics empty - {metric_string}.')

        # send metrics if collection size is matched or last item of list
        if metric_cloudwatch_counter == collection_size or metric_payload_counter == metrics_payload_size:

            # Increase collection
            cloudwatch_collection_counter += 1

            # Send Payload
            try:
                response = cloudwatch.put_metric_data(MetricData=metrics, Namespace=cloudwatch_namespace)
                # Reset payload
                metrics = []
            except Exception as e:
                modules.logger.error(f'Collection {cloudwatch_collection_counter}: {metric_cloudwatch_counter}x {metrics_class} metrics failed: {str(e)}')
            else:
                if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    modules.logger.info(f'Collection {cloudwatch_collection_counter}: {metric_cloudwatch_counter}x {metrics_class} metrics pushed successfully.')
                else:
                    modules.logger.error(f'Collection {cloudwatch_collection_counter}: {metric_cloudwatch_counter}x {metrics_class} metrics failed. Error message: ' + str(response))

            # Reset metric counter
            metric_cloudwatch_counter = 0
