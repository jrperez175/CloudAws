# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import yaml
import modules.cloudwatch
import modules.cloudwatchlogs
import modules.functions
import modules.ec2

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)


def run():
    '''
        Common init code
    '''

    # Initialize Cloudwatch Log Group for Logger
    log_group_suffix = cfg['general']['log_group_suffix']
    log_stream = cfg['general']['log_stream']
    if cfg['general']['log_group_mode'] == 'string':
        log_group_name = cfg['general']['log_group_string_name']
    elif cfg['general']['log_group_mode'] == 'auto':
        log_group_name, _ = modules.ec2.get_cloudwatch_tags()
    elif cfg['general']['log_group_mode'] == 'tags':
        log_group_name = modules.ec2.get_cloudwatchlogs_tags(cfg['general']['log_group_tags_list'])
    else:
        log_group_name = 'log-group-not-defined'
    modules.cloudwatchlogs.log_streams_validate(f'/{log_group_name}/{log_group_suffix}', log_stream)

    # Initialize Cloudwatch Log Groups and Log Streams for Database Module
    for log_group_database, schedule, log_stream, sql_count, sql_error in cfg['database']['sql_list_node_primary_orchestrator'] + cfg['database']['sql_list_nodes_all']:
        modules.cloudwatchlogs.log_streams_validate(f'/{log_group_name}/{log_group_database}', log_stream)
