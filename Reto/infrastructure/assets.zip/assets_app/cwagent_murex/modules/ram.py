# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

# Links
# https://pypi.org/project/psutil/

import psutil
import yaml

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)


def get_utilisation():
    '''
        Function to get utilisation of CPUS
    '''

    # total view
    mem_virtual = psutil.virtual_memory()
    mem_swap = psutil.swap_memory()
    memory = {
        "mem_used_percent": mem_virtual.percent,  # included in cloudwatch montoring - BASIC or STANDARD or ADVANCED
        "mem_total_gigabytes": mem_virtual.total / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "mem_available_gigabytes": mem_virtual.available / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "mem_used_gigabytes": mem_virtual.used / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "mem_free_gigabytes": mem_virtual.free / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "swap_used_percent": mem_swap.percent,  # included in cloudwatch montoring - STANDARD or ADVANCED
        "swap_total_gigabytes": mem_swap.total / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "swap_available_gigabytes": (int(mem_swap.total) - int(mem_swap.used)) / 1024 / 1024 / 1024,   # not included in cloudwatch montoring
        "swap_used_gigabytes": mem_swap.used / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "swap_free_gigabytes": mem_swap.free / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
            }

    return(memory)


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics
    '''
    metrics = []
    memory = get_utilisation()

    if cfg['ram']['mem_used_percent']:
        metric = {
                'MetricName': 'mem_used_percent',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Percent',
                'Value': memory['mem_used_percent']
            }
        metrics.append(metric)

    if cfg['ram']['mem_total_gigabytes']:
        metric = {
                'MetricName': 'mem_total_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': memory['mem_total_gigabytes']
            }
        metrics.append(metric)

    if cfg['ram']['mem_used_gigabytes']:
        metric = {
                'MetricName': 'mem_used_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': memory['mem_used_gigabytes']
            }
        metrics.append(metric)

    if cfg['ram']['mem_free_gigabytes']:
        metric = {
                'MetricName': 'mem_free_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': memory['mem_free_gigabytes']
            }
        metrics.append(metric)

    if cfg['ram']['swap_used_percent']:
        metric = {
                'MetricName': 'swap_used_percent',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Percent',
                'Value': memory['swap_used_percent']
            }
        metrics.append(metric)

    if cfg['ram']['swap_used_gigabytes']:
        metric = {
                'MetricName': 'swap_used_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Percent',
                'Value': memory['swap_used_gigabytes']
            }
        metrics.append(metric)

    if cfg['ram']['swap_total_gigabytes']:
        metric = {
                'MetricName': 'swap_total_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': memory['swap_total_gigabytes']
            }
        metrics.append(metric)

    if cfg['ram']['swap_used_gigabytes']:
        metric = {
                'MetricName': 'swap_used_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': memory['swap_used_gigabytes']
            }
        metrics.append(metric)

    if cfg['ram']['swap_free_gigabytes']:
        metric = {
                'MetricName': 'swap_free_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': memory['swap_free_gigabytes']
            }
        metrics.append(metric)

    return(metrics)
