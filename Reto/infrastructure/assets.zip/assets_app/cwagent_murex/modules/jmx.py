# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import os
import yaml
import socket
from jmxquery import JMXConnection, JMXQuery
import modules.logger

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)


def force_deactivation():
    '''
        Function to check if cfg['mx']['credentials'] is available for authentification
    '''
    credentials_file = cfg['mx']['credentials']
    # Check if file exists
    if os.path.isfile(credentials_file):
        return False
    else:
        modules.logger.info('Module JMX is activated in configuration. No Credentials file found. Module was forced deactivated.')
        return True


def mx_load_credentials():
    '''
        Read Murex Credentials File
    '''
    output = []
    credentials_file = cfg['mx']['credentials']

    # Check if file exists
    if os.path.isfile(credentials_file):

        # Load configuration file
        with open(credentials_file, 'r') as cred_file:
            for line in cred_file.readlines():
                if 'PASSWORD.' in line:
                    user_name, user_password = line.split('=')
                    output.append([user_name.replace('PASSWORD.', ''), user_password.replace('\n', '')])
    else:
        modules.logger.error(f'Credentials not found in {credentials_file}')

    return output


def request_build_dictionary():
    '''
        Reads provided configuration and return list of connection dictionaries to be processed
    '''
    output = []
    urls = cfg['jmx']['urls']
    servers = cfg['jmx']['servers']
    users = cfg['jmx']['users']
    services = cfg['jmx']['services']
    metrics = cfg['jmx']['metrics']
    mappings = cfg['jmx']['mapping']

    # Process mappings
    for m in mappings:
        jmx_server_id, jmx_service_id, jmx_url_id, jmx_user_id, jmx_metric_id = m

        # Initialisation
        jmx_dict = {}
        jmx_server_name = ''
        jmx_service_port = ''

        # Get Values - Server
        for srv in servers:
            server_id, server_name = srv
            if server_id == jmx_server_id:
                jmx_server_name = server_name
                jmx_dict['server'] = server_name

        # Get Values - Service
        for svc in services:
            service_id, service_name, service_port = svc
            if service_id == jmx_service_id:
                jmx_dict['service'] = service_name
                jmx_dict['port'] = service_port
                jmx_service_port = service_port

        # Get Values - Users
        for usr in users:
            user_id, user_name, user_password = usr
            if user_id == jmx_user_id:
                jmx_dict['user'] = user_name
                if user_password != '':
                    jmx_dict['password'] = user_password
                else:
                    for credential in mx_load_credentials():
                        if credential[0] == user_name:
                            jmx_dict['password'] = credential[1]

        # Get Values - Metrics
        for mcs in metrics:
            metric_id, metric, metric_valid_list = mcs
            if metric_id == jmx_metric_id:
                jmx_dict['metric'] = metric
                if metric_valid_list != []:
                    jmx_dict['valid'] = metric_valid_list

        # Get Values - Urls
        for url in urls:
            url_id, url_string = url
            if url_id == jmx_url_id:
                jmx_dict['url'] = url_string.replace('@@@SERVER_NAME@@@', jmx_server_name).replace('@@@SERVER_PORT@@@', str(jmx_service_port))

        # Add to output list
        output.append(jmx_dict)

    return output


def check_server_port(server, service, port):
    '''
        Return True if Server:Port is open or False when not
    '''
    a_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    location = (server, port)
    result_of_check = a_socket.connect_ex(location)

    a_socket.close()

    if result_of_check == 0:
        return True
    else:
        if cfg['jmx']['LogClosedPorts']:
            modules.logger.warning(f'Service {service} - Port {port} of Server {server} is closed.')
        return False


def jmx_get_metrics(jmx_dictionary):
    '''
        Execute provided JMX connection dictionary
    '''
    # Initialisation
    output = []
    service = jmx_dictionary.get('service')

    # Chgeck Server:Port is open
    if check_server_port(jmx_dictionary.get('server'), service, jmx_dictionary.get('port')):

        try:
            # Establish  connection
            jmxConnection = JMXConnection(jmx_dictionary.get('url'), jmx_username=jmx_dictionary.get('user'), jmx_password=jmx_dictionary.get('password'))

            # Get raw metrics
            jmxQuery = [JMXQuery(jmx_dictionary.get('metric'))]
            metrics = jmxConnection.query(jmxQuery)

        except Exception as e:
            modules.logger.error(f'{str(e)}')

        else:
            # Process Metrics
            for metric in metrics:
                if metric.attributeKey is not None:
                    metric_name = f'{metric.attribute}_{metric.attributeKey}'
                    metric_attributeKey = metric.attributeKey
                else:
                    metric_name = metric.attribute
                    metric_attributeKey = ''

                # Check availavle valid list
                if 'valid' in jmx_dictionary:
                    if metric_name in jmx_dictionary['valid']:
                        # Only Long and Integer for metrics
                        if metric.value_type in ('Long', 'Integer'):
                            output.append([service, metric.mBeanName.replace('java.lang:type=', '').replace(',name=', '_').replace(' ', '_'), metric.attribute, metric_attributeKey, metric.value])
                else:
                    # Only Long and Integer for metrics
                    if metric.value_type in ('Long', 'Integer'):
                        output.append([service, metric.mBeanName.replace('java.lang:type=', '').replace(',name=', '_').replace(' ', '_'), metric.attribute, metric_attributeKey, metric.value])

    # Return
    return output


def jmx_request_list_mbeans(jmx_dictionary):
    '''
        Lsit all MBEANS for provided JMX connection dictionary
    '''
    # Initialisation
    service = jmx_dictionary.get('service')

    # Chgeck Server:Port is open
    if check_server_port(jmx_dictionary.get('server'), service, jmx_dictionary.get('port')):

        try:
            # Establish  connection
            jmxConnection = JMXConnection(jmx_dictionary.get('url'), jmx_username=jmx_dictionary.get('user'), jmx_password=jmx_dictionary.get('password'))

            # Get raw metrics
            jmxQuery = [JMXQuery('java.lang:*')]
            metrics = jmxConnection.query(jmxQuery)

        except Exception as e:
            modules.logger.error(f'{str(e)}')

        else:
            print('')
            print('')
            print('')
            print('--------------------------------------------------------------------')
            print(f'--- MX Service: {service} - URL: {jmx_dictionary.get("url")} ---')
            print('--------------------------------------------------------------------')
            print('')
            # Process Metrics
            for metric in metrics:
                if metric.attributeKey is not None:
                    metric_name = f'{metric.attribute}_{metric.attributeKey}'
                else:
                    metric_name = metric.attribute
                # Only Long and Integer for metrics
                if metric.value_type in ('Long', 'Integer'):
                    print([service, metric.mBeanName, metric.attribute, metric.attributeKey, metric.value, 'Filter_Key: ' + metric_name])
                # else:
                #     print(metric.value_type)


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics out of jmx metrics
    '''
    metrics = []

    for request_dictionary in request_build_dictionary():
        for jmx in jmx_get_metrics(request_dictionary):
            mx_service, jmx_bean_name, jmx_attribute, jmx_attributeKey, jmx_value = jmx
            if jmx_attributeKey == '':
                metric_name = jmx_attribute
            else:
                metric_name = f'{jmx_attribute}_{jmx_attributeKey}'
            if jmx_attribute in ['HeapMemoryUsage', 'NonHeapMemoryUsage', 'PeakUsage', 'Usage']:
                metric = {
                        'MetricName': metric_name,
                        'Dimensions': [
                            {
                                'Name': 'mx_host',
                                'Value': mx_host_value
                            },
                            {
                                'Name': 'mx_role',
                                'Value': mx_role_value
                            },
                            {
                                'Name': 'mx_environment',
                                'Value': mx_environment_value
                            },
                            {
                                'Name': 'mx_service',
                                'Value': mx_service
                            },
                            {
                                'Name': 'mbean',
                                'Value': jmx_bean_name
                            },
                        ],
                        'Unit': 'Megabytes',
                        'Value': float(jmx_value) / 1024 / 1024
                    }
            else:
                metric = {
                        'MetricName': metric_name,
                        'Dimensions': [
                            {
                                'Name': 'mx_host',
                                'Value': mx_host_value
                            },
                            {
                                'Name': 'mx_role',
                                'Value': mx_role_value
                            },
                            {
                                'Name': 'mx_environment',
                                'Value': mx_environment_value
                            },
                            {
                                'Name': 'mx_service',
                                'Value': mx_service
                            },
                            {
                                'Name': 'mbean',
                                'Value': jmx_bean_name
                            },
                        ],
                        'Unit': 'Count',
                        'Value': jmx_value
                    }

            metrics.append(metric)

    return(metrics)
