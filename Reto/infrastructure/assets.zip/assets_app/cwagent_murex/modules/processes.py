# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import psutil
import yaml
import subprocess
import os
import socket
import modules.hostname
import modules.logger

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

mem_virtual = psutil.virtual_memory()
mem_total_megabytes = mem_virtual.total / 1024 / 1024


def get_utilisation(os_pid, os_nickname):
    '''
        Function to get ram/cpu of processes
    '''
    try:
        os_cpu_raw = subprocess.check_output(['ps', '-p', str(os_pid), '-o', '%cpu']).decode('utf-8')
        for cpu in os_cpu_raw.split():
            if cpu.strip() != '%CPU':
                os_cpu = cpu.strip()
        os_check = True
    except:
        os_cpu = -1
        os_mem = -1
        os_cmd = 'PID {} not found'.format(os_pid)
        os_check = False

    if os_check:
        os_mem_raw = subprocess.check_output(['ps', '-p', str(os_pid), '-o', '%mem']).decode('utf-8')
        for mem in os_mem_raw.split():
            if mem.strip() != '%MEM':
                os_mem = mem.strip()

        os_cmd_raw = subprocess.check_output(['ps', '-p', str(os_pid), '-o', 'cmd']).decode('utf-8')
        os_cmd = ""
        os_cmd_count = 0
        for cmd in os_cmd_raw.split():
            if os_cmd_count > 0:
                os_cmd = os_cmd + cmd.strip() + ' '
            os_cmd_count += 1
            os_cmd = os_cmd.strip()
    return([os_nickname, os_cpu, os_mem, os_cmd])


def check_pid(pid):
    """
        Check For the existence of a unix pid.
    """
    try:
        os.kill(pid, 0)  # does nothing for an existing process
    except OSError:
        return False
    else:
        return True


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics based on manual path
    '''
    metrics = []
    all_utilisation = []

    # Childs
    proc_childs_scan = cfg['processes']['proc_childs_scan']
    proc_childs_individual_metrics = cfg['processes']['proc_childs_individual_metrics']
    proc_childs_summary_metrics = cfg['processes']['proc_childs_summary_metrics']

    # manual
    manual_process_list = []
    if cfg['processes']['manual']:
        manual_process_list = cfg['processes']['manual_pid_list']

    # automatic
    automatic_process_list = []
    if cfg['processes']['automatic']:
        automatic_process_list = pid_scanner_murex(cfg['processes']['automatic_folder'], mx_environment_value)

    # combined processes to watch
    process_list = manual_process_list + automatic_process_list

    # Read process pid files
    for (os_pidfile, os_nickname) in process_list:

        # open os_pidfile
        if os.path.isfile(os_pidfile) and os.path.exists(os_pidfile):

            # validate content
            try:
                with open(os_pidfile, 'r') as f:

                    contents = f.read()
                    try:
                        os_pid = int(contents)
                    except:
                        os_pid = -1

                    # Process valid return and check if Pid exists
                    if os_pid != -1 and check_pid(os_pid):
                        os_nickname_parent, os_cpu_parent, os_mem_parent, os_cmd_parent = get_utilisation(os_pid, os_nickname)

                        # Process valid return
                        if os_cpu_parent != -1:

                            # add parent values to all_utilisation
                            all_utilisation.append([os_nickname_parent, os_cpu_parent, os_mem_parent])

                            # Scan for Child process
                            if proc_childs_scan:
                                childs = pid_child_scanner_murex(pid_parent=os_pid, pid_nickname=os_nickname)

                                # Child Scan has valid return
                                number_of_childs = len(childs)
                                if number_of_childs > 0:

                                    # Create summary process
                                    os_nickname_summary = f'{os_nickname}_summary'
                                    os_cpu_summary = float(os_cpu_parent)
                                    os_mem_summary = float(os_mem_parent)

                                    # Process Childs
                                    for key in childs.keys():
                                        os_nickname_child, os_cpu_child, os_mem_child, os_cmd_child = get_utilisation(childs[key], key)

                                        # add child values to all_utilisation
                                        if proc_childs_individual_metrics:
                                            all_utilisation.append([os_nickname_child, os_cpu_child, os_mem_child])

                                        # add child values to summary process
                                        if proc_childs_summary_metrics:
                                            os_cpu_summary += float(os_cpu_child)
                                            os_mem_summary += float(os_mem_child)

                                    # Add summary metric to all_utilisation
                                    if proc_childs_summary_metrics:
                                        all_utilisation.append([os_nickname_summary, os_cpu_summary, os_mem_summary])

            except Exception as e:
                modules.logger.error(f'{str(e)}')

    # Process all utilisation
    for (os_nickname, os_cpu, os_mem) in all_utilisation:

        # Push only live process to cloudwatch
        if os_cpu != -1:

            # proc_cpu_percent
            if cfg['processes']['proc_cpu_percent']:

                metric = {
                        'MetricName': 'proc_cpu_percent',
                        'Dimensions': [
                            {
                                'Name': 'mx_host',
                                'Value': mx_host_value
                            },
                            {
                                'Name': 'mx_role',
                                'Value': mx_role_value
                            },
                            {
                                'Name': 'mx_environment',
                                'Value': mx_environment_value
                            },
                            {
                                    'Name': 'mx_process',
                                    'Value': os_nickname
                                },
                        ],
                        'Unit': 'Percent',
                        'Value': float(os_cpu)
                    }
                metrics.append(metric)

            # proc_mem_percent
            if cfg['processes']['proc_mem_percent']:

                metric = {
                        'MetricName': 'proc_mem_percent',
                        'Dimensions': [
                            {
                                'Name': 'mx_host',
                                'Value': mx_host_value
                            },
                            {
                                'Name': 'mx_role',
                                'Value': mx_role_value
                            },
                            {
                                'Name': 'mx_environment',
                                'Value': mx_environment_value
                            },
                            {
                                    'Name': 'mx_process',
                                    'Value': os_nickname
                                },
                        ],
                        'Unit': 'Percent',
                        'Value': float(os_mem)
                    }
                metrics.append(metric)

            # proc_mem_megabytes
            if cfg['processes']['proc_mem_megabytes']:

                metric = {
                        'MetricName': 'proc_mem_megabytes',
                        'Dimensions': [
                            {
                                'Name': 'mx_host',
                                'Value': mx_host_value
                            },
                            {
                                'Name': 'mx_role',
                                'Value': mx_role_value
                            },
                            {
                                'Name': 'mx_environment',
                                'Value': mx_environment_value
                            },
                            {
                                    'Name': 'mx_process',
                                    'Value': os_nickname
                                },
                        ],
                        'Unit': 'Megabytes',
                        'Value': float(os_mem) / 100 * mem_total_megabytes
                    }
                metrics.append(metric)

    return(metrics)


def pid_scanner_murex(source_directory, mx_environment_value):
    '''
        Function to read folder and files from source to return list of items
    '''
    # Assign lists
    files = []
    for (folder_path, folder_name, files_in_folder) in os.walk(source_directory):
        # Files
        for f in files_in_folder:
            file_path = os.path.join(folder_path, f)
            # DENY - exclude_file_extensions
            file_extension = os.path.splitext(f)[1]
            if file_extension.lower() in cfg['processes']['automatic_extension']:
                # Cleanup to identify good process name for Murex
                file_name_raw = os.path.splitext(f)[0].strip()
                deny_hostname = modules.hostname.get_name()
                deny_hostname_full = socket.gethostname()
                deny_list = ['site1', 'public', 'mxres', 'common', 'launcher', 'loadbalance', 'standalone', deny_hostname, deny_hostname_full, mx_environment_value]
                file_name = 'not_found'
                for x in file_name_raw.split('.'):
                    if file_name == 'not_found':
                        if x not in deny_list:
                            if x[0:10] == 'launchermx':
                                # Exclusion for mxml
                                if 'mxml' in x and 'launcher' in x:
                                    file_name = x[8:100]
                                else:
                                    file_name = x[10:100]
                            elif x[0:8] == 'launcher' and 'mxml' not in x and 'launcherall' not in x:
                                file_name = x[8:100]
                            elif x[0:2] == 'mx' and x[0:4] != 'mxml':
                                file_name = x[2:100]
                            else:
                                file_name = x

                files.append([file_path, file_name])
    # Return
    return files


def pid_child_scanner_murex(pid_parent, pid_nickname, pid_user=None):
    '''
        Function to identify potential childs of a PID
    '''

    # Variables
    os_ppid_pid_dict = {}
    os_counter = 0

    # Create list of all pids with its parent relation
    os_pids = subprocess.check_output(['ps', '-eo', 'user,ppid,pid']).decode('utf-8')

    # Scan this list for given parameters
    for os_line in os_pids.splitlines():
        os_line_cleaned = os_line.replace('  ', ' ').replace('  ', ' ').replace('  ', ' ').replace('  ', ' ').replace(' ', '@')
        os_user = os_line_cleaned.split('@')[0]
        os_pid_parent = os_line_cleaned.split('@')[1]
        ps_pid_child = os_line_cleaned.split('@')[2]
        if str(os_pid_parent) == str(pid_parent):
            os_counter += 1
            if pid_user is None or os_user == pid_user:
                os_ppid_pid_dict[pid_nickname + '_' + str(os_counter)] = int(ps_pid_child)
    # Return
    return os_ppid_pid_dict
