# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import math


def set_frequency_counter(loop_frequency, module_frequency, module_frequency_counter_current):
    loop_frequency = loop_frequency
    module_frequency = module_frequency
    module_frequency_counter_current = module_frequency_counter_current
    if module_frequency_counter_current == 0 or module_frequency_counter_current < 0:
        module_frequency_counter_current = 0
        return math.ceil(module_frequency / loop_frequency)
    else:
        module_frequency_counter_current = module_frequency_counter_current - 1
        return math.ceil(module_frequency / loop_frequency) - (math.ceil(module_frequency / loop_frequency) - module_frequency_counter_current)
