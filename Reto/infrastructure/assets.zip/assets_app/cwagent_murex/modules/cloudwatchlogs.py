# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import boto3
import yaml
import time
import logging
import modules.hostname
import os
import modules.ec2

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)
filename = cfg['general']['log_file']

# Initialisation
host_name = modules.hostname.get_name()

# Check presence of logfile
if os.path.isfile(filename) is False:
    try:
        # if not present, create an empty file
        with open(filename, 'w'):
            pass
    except:
        filename = '/tmp/cloudwatch.log'


# Local Logging if Cloudwatch Logs failed
def main():
    '''
        Function to define main properties - Cloudwatch Logs Version - Local Only
    '''
    logging.basicConfig(format='%(asctime)s %(message)s', filename=filename, level=logging.INFO)


def debug(payload):
    '''
        Function for log level DEBUG - Cloudwatch Logs Version - Local Only
    '''
    main()
    if os.path.isfile(filename):
        logging.debug(f'DEBUG   : {host_name}: {payload}')
    else:
        print(payload)


def info(payload):
    '''
        Function for log level INFO - Cloudwatch Logs Version - Local Only
    '''
    main()
    if os.path.isfile(filename):
        logging.info(f'INFO    : {host_name}: {payload}')
    else:
        print(payload)


def warning(payload):
    '''
        Function for log level WARNING - Cloudwatch Logs Version - Local Only
    '''
    main()
    if os.path.isfile(filename):
        logging.warning(f'WARNING : {host_name}: {payload}')
    else:
        print(payload)


def error(payload):
    '''
        Function for log level ERROR - Cloudwatch Logs Version - Local Only
    '''
    main()
    if os.path.isfile(filename):
        logging.error(f'ERROR   : {host_name}: {payload}')
    else:
        print(payload)


# Create Cloudwatch Client
cloudwatchlogs = boto3.client(service_name='logs', region_name=cfg['general']['aws_region'])
mx_environment_value, mx_role_value = modules.ec2.get_cloudwatch_tags()
mx_environment_tag = cfg['tags']['mx_environment']
if 'aws:' in mx_environment_tag:
    warning(f'Warning - Murex environment Tag {mx_environment_tag} cannot be used. aws: is a reserved tag space. Using Tag "mx_environment" instead.')
    mx_environment_tag = 'mx_environment'


def log_group_exists(log_group):
    '''
        Function to check if a given log group exists
    '''
    try:
        # Get existing log groups
        response = cloudwatchlogs.describe_log_groups(logGroupNamePrefix=log_group)
        # Check if log group exists
        if 'logGroups' in response:
            for i in response['logGroups']:
                if log_group == i['logGroupName']:
                    return True
        return False

    except Exception as e:
        error(f'Log Group {log_group} - Error: {str(e)}')
        return False


def log_group_create(log_group):
    '''
        Function to create a log group and tag it with Murex environment value
    '''
    # create log group
    try:
        response = cloudwatchlogs.create_log_group(
            logGroupName=log_group,
            # kmsKeyId='string',
            tags={
                mx_environment_tag: mx_environment_value
            }
        )
    except Exception as e:
        error(f'Log Group {log_group} - Error: {str(e)}')
        return False
    else:
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            info(f'Log Group {log_group} created.')
            return True
        else:
            error(f'Log Group {log_group} creation failed.')
            return False


def log_group_delete(log_group):
    '''
        Function to delete a log group
    '''
    # delete log group
    try:
        response = cloudwatchlogs.delete_log_group(
            logGroupName=log_group
        )
    except Exception as e:
        error(f'Log Group {log_group} - Error: {str(e)}')
        return False
    else:
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            info(f'Log Group {log_group} dropped.')
            return True
        else:
            error(f'Log Group {log_group} drop failed.')
            return False


def log_group_validate(log_group):
    '''
        Function to create a log group if it does not exist
    '''
    # Check if Log Group already exists or create it
    if log_group_exists(log_group) is False:
        return log_group_create(log_group)
    else:
        return True


def log_stream_exists(log_group, log_stream):
    '''
        Function to check if a given log stream in a given log_group exists
    '''
    try:
        # Get existing log streams in given log group
        response = cloudwatchlogs.describe_log_streams(
            logGroupName=log_group
        )

        # Check if log stream exists
        if 'logStreams' in response:
            for i in response['logStreams']:
                if log_stream == i['logStreamName']:
                    return True
        return False

    except Exception as e:
        error(f'Log Group {log_group}: Log Stream {log_stream} - Error: {str(e)}')
        return False


def log_stream_create(log_group, log_stream):
    '''
        Function to delete a log stream in a log group
    '''
    # create log stream
    try:
        response = cloudwatchlogs.create_log_stream(
            logGroupName=log_group,
            logStreamName=log_stream
        )
    except Exception as e:
        error(f'Log Group {log_group}: Log Stream {log_stream} - Error: {str(e)}')
    else:
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            info(f'Log Group {log_group}: Log Stream {log_stream} created.')
            return True
        else:
            error(f'Log Group {log_group}: Log Stream {log_stream} creation failed.')
            return False


def log_stream_delete(log_group, log_stream):
    '''
        Function to delete a log stream in a log group
    '''
    # delete log stream
    try:
        response = cloudwatchlogs.delete_log_stream(
            logGroupName=log_group,
            logStreamName=log_stream
        )
    except Exception as e:
        error(f'Log Group {log_group}: Log Stream {log_stream} - Error: {str(e)}')
        return False
    else:
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            info(f'Log Group {log_group}: Log Stream {log_stream} dropped.')
            return True
        else:
            error(f'Log Group {log_group}: Log Stream {log_stream} drop failed.')
            return False


def log_streams_validate(log_group, log_stream):
    '''
        Function to create a log streams in a given log group if it does not exist
    '''
    # Check if Log Group already exists or create it
    if log_group_validate(log_group):

        # Check if Log Stream already exists or create it
        if log_stream_exists(log_group, log_stream) is False:
            return log_stream_create(log_group, log_stream)
        else:
            return True


def log_streams_put_event_list(log_group, log_stream, event_list):
    '''
        Function to put items of an event list to a log streams in a given log group - Batch Processing
    '''

    if log_streams_validate(log_group, log_stream):
        # Define Epoch
        epoch_timestamp = int(round(time.time() * 1000))
        events = []
        # Prepare messages
        for event in event_list:
            events.append(
                            {
                                'timestamp': epoch_timestamp,
                                'message': event
                            },
            )

        # Get last upload token
        try:
            response = cloudwatchlogs.describe_log_streams(
                logGroupName=log_group,
                logStreamNamePrefix=log_stream
            )
            skip_token = True
            sequence_token = None
            if response['ResponseMetadata']['HTTPStatusCode'] != 200:
                error(f'Log Group {log_group}: Log Stream {log_stream} - Put Operation: Sequence Token Error: {response}')
            else:
                for i in response['logStreams']:
                    if i['logStreamName'] == log_stream:
                        if 'uploadSequenceToken' in i:
                            sequence_token = i['uploadSequenceToken']
                            skip_token = False

        except Exception as e:
            error(f'Log Group {log_group}: Log Stream {log_stream} - Put Operation: Describe Log stream Error: {str(e)}')
            return False

        else:
            try:
                if skip_token:
                    response = cloudwatchlogs.put_log_events(
                        logGroupName=log_group,
                        logStreamName=log_stream,
                        logEvents=events
                    )
                else:
                    response = cloudwatchlogs.put_log_events(
                        logGroupName=log_group,
                        logStreamName=log_stream,
                        logEvents=events,
                        sequenceToken=sequence_token
                    )
                if response['ResponseMetadata']['HTTPStatusCode'] != 200:
                    error(f'Log Group {log_group}: Log Stream {log_stream} - Put Operation: Event Error: {response}')
                else:
                    info(f'Log Group {log_group}: Log Stream {log_stream} - Put Operation: Events ({str(len(events))}) successful')
            except Exception as e:
                error(f'Log Group {log_group}: Log Stream {log_stream} - Put Operation: Event Error: {str(e)}')
                return False
