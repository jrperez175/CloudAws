# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

# Links
# https://pypi.org/project/psutil/

import psutil
import socket
import yaml
import time

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

host_ip = socket.gethostbyname(socket.getfqdn())


def get_utilisation():
    '''
        Function to get utilisation of netstatS
    '''

    netstats = []
    interfaces = psutil.net_io_counters(pernic=True)
    pre_conn_eth0_bytes_sent, pre_conn_eth0_bytes_recv, pre_conn_eth0_packets_sent, pre_conn_eth0_packets_recv, pre_conn_eth0_errin, pre_conn_eth0_errout, pre_conn_eth0_dropin, pre_conn_eth0_dropout = interfaces['eth0']
    time.sleep(3)
    interfaces = psutil.net_io_counters(pernic=True)
    post_conn_eth0_bytes_sent, post_conn_eth0_bytes_recv, post_conn_eth0_packets_sent, post_conn_eth0_packets_recv, post_conn_eth0_errin, post_conn_eth0_errout, post_conn_eth0_dropin, post_conn_eth0_dropout = interfaces['eth0']
    conns = psutil.net_connections(kind='inet')
    conn_internal_other_count = 0
    conn_internal_listen_count = 0
    conn_internal_established_count = 0
    conn_internal_time_wait_count = 0
    conn_external_other_count = 0
    conn_external_listen_count = 0
    conn_external_established_count = 0
    conn_external_time_wait_count = 0
    for conn in conns:
        _fd, _family, _type, _laddr, _raddr, _status, _pid = conn
        if 'SocketKind.SOCK_STREAM' in str(_type):

            if ('127.0.0.1' in str(_laddr) and '127.0.0.1' in str(_raddr)) or (host_ip in str(_laddr) and host_ip in str(_raddr)):
                if _status == 'TIME_WAIT':
                    conn_internal_time_wait_count += 1
                elif _status == 'LISTEN':
                    conn_internal_listen_count += 1
                elif _status == 'ESTABLISHED':
                    conn_internal_established_count += 1
                else:
                    conn_internal_other_count += 1
            else:
                if _status == 'TIME_WAIT':
                    conn_external_time_wait_count += 1
                elif _status == 'LISTEN':
                    conn_external_listen_count += 1
                elif _status == 'ESTABLISHED':
                    conn_external_established_count += 1
                else:
                    conn_external_other_count += 1

    netstats.append({
        "netstat_bytes_sent": post_conn_eth0_bytes_sent,
        "netstat_bytes_recv": post_conn_eth0_bytes_recv,
        "netstat_bytes_sent_throughput": post_conn_eth0_bytes_sent - pre_conn_eth0_bytes_sent,
        "netstat_bytes_recv_throughput": post_conn_eth0_bytes_recv - pre_conn_eth0_bytes_recv,
        "netstat_packets_sent": post_conn_eth0_packets_sent,
        "netstat_packets_recv": post_conn_eth0_packets_recv,
        "netstat_packets_sent_throughput": post_conn_eth0_packets_sent - pre_conn_eth0_packets_sent,
        "netstat_packets_recv_throughput": post_conn_eth0_packets_recv - pre_conn_eth0_packets_recv,
        "netstat_tcp_internal_other": conn_internal_other_count,
        "netstat_tcp_internal_listen": conn_internal_listen_count,
        "netstat_tcp_internal_established": conn_internal_established_count,
        "netstat_tcp_internal_time_wait": conn_internal_time_wait_count,
        "netstat_tcp_external_other": conn_external_other_count,
        "netstat_tcp_external_listen": conn_external_listen_count,
        "netstat_tcp_external_established": conn_external_established_count,
        "netstat_tcp_external_time_wait": conn_external_time_wait_count,
                })

    return(netstats)


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics
    '''
    metrics = []
    netstats = get_utilisation()
    for netstat in netstats:

        if cfg['network']['netstat_bytes_sent']:
            metric = {
                    'MetricName': 'netstat_bytes_sent',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Bytes',
                    'Value': netstat['netstat_bytes_sent']
                }
            metrics.append(metric)

        if cfg['network']['netstat_bytes_recv']:
            metric = {
                    'MetricName': 'netstat_bytes_recv',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Bytes',
                    'Value': netstat['netstat_bytes_recv']
                }
            metrics.append(metric)

        if cfg['network']['netstat_packets_sent']:
            metric = {
                    'MetricName': 'netstat_packets_sent',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                      ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_packets_sent']
                }
            metrics.append(metric)

        if cfg['network']['netstat_packets_recv']:
            metric = {
                    'MetricName': 'netstat_packets_recv',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_packets_recv']
                }
            metrics.append(metric)

        if cfg['network']['netstat_tcp_internal_other']:
            metric = {
                    'MetricName': 'netstat_tcp_internal_other',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_tcp_internal_other']
                }
            metrics.append(metric)

        if cfg['network']['netstat_tcp_internal_listen']:
            metric = {
                    'MetricName': 'netstat_tcp_internal_listen',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_tcp_internal_listen']
                }
            metrics.append(metric)

        if cfg['network']['netstat_tcp_internal_established']:
            metric = {
                    'MetricName': 'netstat_tcp_internal_established',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_tcp_internal_established']
                }
            metrics.append(metric)

        if cfg['network']['netstat_tcp_internal_time_wait']:
            metric = {
                    'MetricName': 'netstat_tcp_internal_time_wait',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_tcp_internal_time_wait']
                }
            metrics.append(metric)

        if cfg['network']['netstat_tcp_external_other']:
            metric = {
                    'MetricName': 'netstat_tcp_external_other',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_tcp_external_other']
                }
            metrics.append(metric)

        if cfg['network']['netstat_tcp_external_listen']:
            metric = {
                    'MetricName': 'netstat_tcp_external_listen',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_tcp_external_listen']
                }
            metrics.append(metric)

        if cfg['network']['netstat_tcp_external_established']:
            metric = {
                    'MetricName': 'netstat_tcp_external_established',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_tcp_external_established']
                }
            metrics.append(metric)

        if cfg['network']['netstat_tcp_external_time_wait']:
            metric = {
                    'MetricName': 'netstat_tcp_external_time_wait',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_tcp_external_time_wait']
                }
            metrics.append(metric)

        if cfg['network']['netstat_bytes_sent_throughput']:
            metric = {
                    'MetricName': 'netstat_bytes_sent_throughput',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_bytes_sent_throughput']
                }
            metrics.append(metric)

        if cfg['network']['netstat_bytes_recv_throughput']:
            metric = {
                    'MetricName': 'netstat_bytes_recv_throughput',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_bytes_recv_throughput']
                }
            metrics.append(metric)

        if cfg['network']['netstat_packets_sent_throughput']:
            metric = {
                    'MetricName': 'netstat_packets_sent_throughput',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_packets_sent_throughput']
                }
            metrics.append(metric)

        if cfg['network']['netstat_packets_recv_throughput']:
            metric = {
                    'MetricName': 'netstat_packets_recv_throughput',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                    ],
                    'Unit': 'Count',
                    'Value': netstat['netstat_packets_recv_throughput']
                }
            metrics.append(metric)

    return(metrics)
