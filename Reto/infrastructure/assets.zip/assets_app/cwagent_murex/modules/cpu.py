# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

# Links
# https://pypi.org/project/psutil/

import psutil
import yaml

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

cpu_metrics_per_core = cfg['cpu']['cpu_metrics_per_core']


def get_utilisation():
    '''
        Function to get utilisation of CPUS
    '''

    cpus = []

    # Cores enabled?
    if cpu_metrics_per_core:
        # each cpus
        cpu_times_percent_percpu = psutil.cpu_times_percent(interval=1, percpu=True)
        cpu_freq_percent_percpu = psutil.cpu_freq(percpu=True)
        cpu_count = 0
        for cpu in cpu_times_percent_percpu:
            cpu_count += 1
            cpus.append({
                "cpu_name": 'cpu{}'.format(cpu_count),
                "cpu_usage_user": cpu.user,   # not included in cloudwatch montoring
                "cpu_usage_system": cpu.system,   # not included in cloudwatch montoring
                "cpu_usage_idle": cpu.idle,   # not included in cloudwatch montoring
                "cpu_usage_iowait": cpu.iowait,   # not included in cloudwatch montoring
                "cpu_usage_load": cpu.system + cpu.iowait + cpu.user,  # included in cloudwatch montoring - STANDARD or ADVANCED == cpu_usage_system + cpu_usage_user + cpu_usage_iowait
                "cpu_frequency": cpu_freq_percent_percpu[cpu_count - 1].current,  # not included in cloudwatch montoring
                        })

    # total view
    cpu_times_percent_total = psutil.cpu_times_percent(interval=1, percpu=False)
    cpu_freq = psutil.cpu_freq()
    cpus.append({
        "cpu_name": 'cpu total',
        "cpu_usage_user": cpu_times_percent_total.user,  # not included in cloudwatch montoring
        "cpu_usage_system": cpu_times_percent_total.system,  # not included in cloudwatch montoring
        "cpu_usage_idle": cpu_times_percent_total.idle,  # not included in cloudwatch montoring
        "cpu_usage_iowait": cpu_times_percent_total.iowait,  # not included in cloudwatch montoring
        "cpu_usage_load": cpu_times_percent_total.system + cpu_times_percent_total.iowait + cpu_times_percent_total.user,  # included in cloudwatch montoring - STANDARD or ADVANCED == cpu_usage_system + cpu_usage_user + cpu_usage_iowait
        "cpu_frequency": cpu_freq.current,  # not included in cloudwatch montoring
                })

    return(cpus)


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics
    '''
    metrics = []
    cpus = get_utilisation()

    for cpu in cpus:

        if cfg['cpu']['cpu_usage_system']:
            metric = {
                    'MetricName': 'cpu_usage_system',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'cpu',
                            'Value': cpu['cpu_name']
                        },
                    ],
                    'Unit': 'Percent',
                    'Value': cpu['cpu_usage_system']
                }
            metrics.append(metric)

        if cfg['cpu']['cpu_usage_iowait']:
            metric = {
                    'MetricName': 'cpu_usage_iowait',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'cpu',
                            'Value': cpu['cpu_name']
                        },
                    ],
                    'Unit': 'Percent',
                    'Value': cpu['cpu_usage_iowait']
                }
            metrics.append(metric)

        if cfg['cpu']['cpu_usage_load']:
            metric = {
                    'MetricName': 'cpu_usage_load',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'cpu',
                            'Value': cpu['cpu_name']
                        },
                    ],
                    'Unit': 'Percent',
                    'Value': cpu['cpu_usage_load']
                }
            metrics.append(metric)

        if cfg['cpu']['cpu_usage_user']:
            metric = {
                    'MetricName': 'cpu_usage_user',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'cpu',
                            'Value': cpu['cpu_name']
                        },
                    ],
                    'Unit': 'Percent',
                    'Value': cpu['cpu_usage_user']
                }
            metrics.append(metric)

        if cfg['cpu']['cpu_usage_idle']:
            metric = {
                    'MetricName': 'cpu_usage_idle',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'cpu',
                            'Value': cpu['cpu_name']
                        },
                    ],
                    'Unit': 'Percent',
                    'Value': cpu['cpu_usage_idle']
                }
            metrics.append(metric)

        if cfg['cpu']['cpu_frequency']:

            metric = {
                    'MetricName': 'cpu_frequency',
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        },
                        {
                            'Name': 'cpu',
                            'Value': cpu['cpu_name']
                        },
                    ],
                    'Unit': 'Count',
                    'Value': cpu['cpu_frequency']
                }
            metrics.append(metric)

    return(metrics)
