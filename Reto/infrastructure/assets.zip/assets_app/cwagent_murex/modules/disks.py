# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

# Links
# https://pypi.org/project/psutil/

import psutil
import yaml

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)


def get_utilisation():
    '''
        Function to get utilisation of CPUS
    '''

    # total view
    disk_usage = psutil.disk_usage('/')
    disk_io_counters = psutil.disk_io_counters(perdisk=False)
    disks = {
        "disk_used_percent": disk_usage.percent,  # included in cloudwatch montoring - BASIC or STANDARD or ADVANCED
        "disk_total_gigabytes": disk_usage.total / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "disk_used_gigabytes": disk_usage.used / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "disk_free_gigabytes": disk_usage.free / 1024 / 1024 / 1024,  # not included in cloudwatch montoring
        "diskio_read_count": disk_io_counters.read_count,  # not included in cloudwatch montoring
        "diskio_write_count": disk_io_counters.write_count,  # not included in cloudwatch montoring
        "diskio_read_bytes": disk_io_counters.read_bytes,  # not included in cloudwatch montoring
        "diskio_write_bytes": disk_io_counters.write_bytes,  # not included in cloudwatch montoring
        "diskio_read_time": disk_io_counters.read_time,  # not included in cloudwatch montoring
        "diskio_write_time": disk_io_counters.write_time,  # not included in cloudwatch montoring
        "diskio_read_count_throughput": round(disk_io_counters.read_count / disk_io_counters.read_time, 2),  # not included in cloudwatch montoring
        "diskio_write_count_throughput": round(disk_io_counters.write_count / disk_io_counters.write_time, 2),  # not included in cloudwatch montoring
        "diskio_read_bytes_throughput": round(disk_io_counters.read_bytes / disk_io_counters.read_time, 2),  # not included in cloudwatch montoring
        "diskio_write_bytes_throughput": round(disk_io_counters.write_bytes / disk_io_counters.write_time, 2),  # not included in cloudwatch montoring
            }

    return(disks)


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics
    '''
    metrics = []
    disks = get_utilisation()

    if cfg['disks']['disk_used_percent']:
        metric = {
                'MetricName': 'disk_used_percent',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Percent',
                'Value': disks['disk_used_percent']
            }
        metrics.append(metric)

    if cfg['disks']['disk_total_gigabytes']:
        metric = {
                'MetricName': 'disk_total_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': disks['disk_total_gigabytes']
            }
        metrics.append(metric)

    if cfg['disks']['disk_used_gigabytes']:
        metric = {
                'MetricName': 'disk_used_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': disks['disk_used_gigabytes']
            }
        metrics.append(metric)

    if cfg['disks']['disk_free_gigabytes']:
        metric = {
                'MetricName': 'disk_free_gigabytes',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Gigabytes',
                'Value': disks['disk_free_gigabytes']
            }
        metrics.append(metric)

    if cfg['disks']['diskio_read_count']:
        metric = {
                'MetricName': 'diskio_read_count',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Count',
                'Value': disks['diskio_read_count']
            }
        metrics.append(metric)

    if cfg['disks']['diskio_write_count']:
        metric = {
                'MetricName': 'diskio_write_count',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Count',
                'Value': disks['diskio_write_count']
            }
        metrics.append(metric)

    if cfg['disks']['diskio_read_time']:
        metric = {
                'MetricName': 'diskio_read_time',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Count',
                'Value': disks['diskio_read_time']
            }
        metrics.append(metric)

    if cfg['disks']['diskio_write_time']:
        metric = {
                'MetricName': 'diskio_write_time',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Count',
                'Value': disks['diskio_write_time']
            }
        metrics.append(metric)

    if cfg['disks']['diskio_read_count_throughput']:
        metric = {
                'MetricName': 'diskio_read_count_throughput',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Count',
                'Value': disks['diskio_read_count_throughput']
            }
        metrics.append(metric)

    if cfg['disks']['diskio_write_count_throughput']:
        metric = {
                'MetricName': 'diskio_write_count_throughput',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Count',
                'Value': disks['diskio_write_count_throughput']
            }
        metrics.append(metric)

    if cfg['disks']['diskio_read_bytes_throughput']:
        metric = {
                'MetricName': 'diskio_read_bytes_throughput',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Count',
                'Value': disks['diskio_read_bytes_throughput']
            }
        metrics.append(metric)

    if cfg['disks']['diskio_write_bytes_throughput']:
        metric = {
                'MetricName': 'diskio_write_bytes_throughput',
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                ],
                'Unit': 'Count',
                'Value': disks['diskio_write_bytes_throughput']
            }
        metrics.append(metric)

    return(metrics)
