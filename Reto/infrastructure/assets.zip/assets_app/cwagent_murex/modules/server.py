# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import yaml
import modules.ec2

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)


def get_utilisation():
    '''
        Function to get server meta data
    '''

    server_meta_data = []

    server_meta_data.append({
        "server_instance_type": modules.ec2.get_instance_type()   # not included in cloudwatch montoring
                })

    return(server_meta_data)


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics
    '''
    metrics = []
    server_meta_data = get_utilisation()

    for server in server_meta_data:

        if cfg['server']['server_instance_type']:
            instance_type = 'instance_' + server['server_instance_type']
            metric = {
                    'MetricName': instance_type.replace('.', '_'),
                    'Dimensions': [
                        {
                            'Name': 'mx_host',
                            'Value': mx_host_value
                        },
                        {
                            'Name': 'mx_role',
                            'Value': mx_role_value
                        },
                        {
                            'Name': 'mx_environment',
                            'Value': mx_environment_value
                        }
                    ],
                    'Unit': 'Count',
                    'Value': 1
                }
            metrics.append(metric)

    return(metrics)
