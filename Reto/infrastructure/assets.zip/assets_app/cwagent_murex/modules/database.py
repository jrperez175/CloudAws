# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

# Links
# https://cx-oracle.readthedocs.io/en/latest/user_guide/sql_execution.html

import yaml
import cx_Oracle
import modules.secretmanager
import modules.logger
import modules.scheduler
import modules.ec2
import modules.cloudwatchlogs

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

# Read Tags
mx_environment_value, mx_role_value = modules.ec2.get_cloudwatch_tags()


# Define database class
class Schema():

    def __init__(self, secret_name, secret_tag_schema, secret_tag_username, secret_tag_password, secret_tag_host, secret_tag_port):
        self.secret_name = secret_name
        self.secret_tag_schema = secret_tag_schema
        self.secret_tag_username = secret_tag_username
        self.secret_tag_password = secret_tag_password
        self.secret_tag_host = secret_tag_host
        self.secret_tag_port = secret_tag_port
        self.sql_connection = None
        self.sql_result = None

        # Access Secret Manager to load database data
        if cfg['modules']['database']['enabled']:
            self.response = modules.secretmanager.get_secret(self.secret_name)
            if self.response is not None:

                # Defaults to be overwritten
                self.schema_username = 'not_found'
                self.schema_password = 'not_found'
                self.schema_host = 'not_found'
                self.schema_database_port = 'not_found'

                # username
                if self.secret_tag_username in self.response:
                    self.schema_username = self.response[self.secret_tag_username]
                    if self.schema_username == '':
                        self.schema_username = 'no_value'
                        modules.logger.error(f'Secret {self.secret_name} has an empty key pair for {self.secret_tag_username}. Please reconfigure Secret Manager.')
                else:
                    modules.logger.error(f'Secret {self.secret_name} has no key pair for {self.secret_tag_username}. Please reconfigure Secret Manager and config.yml.')

                # password
                if self.secret_tag_password in self.response:
                    self.schema_password = self.response[self.secret_tag_password]
                    if self.schema_password == '':
                        self.schema_password = 'no_value'
                        modules.logger.error(f'Secret {self.secret_name} has an empty key pair for {self.secret_tag_password}. Please reconfigure Secret Manager.')
                else:
                    modules.logger.error(f'Secret {self.secret_name} has no key pair for {self.secret_tag_password}. Please reconfigure Secret Manager and config.yml.')

                # host
                if self.secret_tag_host in self.response:
                    self.schema_host = self.response[self.secret_tag_host]
                    if self.schema_host == '':
                        self.schema_host = 'no_value'
                        modules.logger.error(f'Secret {self.secret_name} has an empty key pair for {self.secret_tag_host}. Please reconfigure Secret Manager.')
                else:
                    modules.logger.error(f'Secret {self.secret_name} has no key pair for {self.secret_tag_host}. Please reconfigure Secret Manager and config.yml.')

                # dbname
                if self.secret_tag_schema in self.response:
                    self.schema_database_name = self.response[self.secret_tag_schema]
                    if self.schema_database_name == '':
                        self.schema_database_name = 'no_value'
                        modules.logger.error(f'Secret {self.secret_name} has an empty key pair for {self.secret_tag_schema}. Please reconfigure Secret Manager.')
                else:
                    modules.logger.error(f'Secret {self.secret_name} has no key pair for {self.secret_tag_schema}. Please reconfigure Secret Manager and config.yml.')

                # port
                if self.secret_tag_port in self.response:
                    self.schema_database_port = self.response[self.secret_tag_port]
                    if self.schema_database_port == '':
                        self.schema_database_port = 'no_value'
                        modules.logger.error(f'Secret {self.secret_name} has an empty key pair for {self.secret_tag_port}. Please reconfigure Secret Manager.')
                else:
                    modules.logger.error(f'Secret {self.secret_name} has no key pair for {self.secret_tag_port}. Please reconfigure Secret Manager and config.yml.')

            else:
                modules.logger.error(f'Secret {self.secret_name} does not exist. Please reconfigure config.yml.')

    def get_connection(self):
        '''
            Establish connection to database
        '''
        self.sql_connection_string = f'{self.schema_host}:{str(self.schema_database_port)}/{self.schema_database_name}'
        try:
            self.sql_connection = cx_Oracle.connect(self.schema_username, self.schema_password, self.sql_connection_string)
            self.sql_connection.autocommit = True
        except Exception as e:
            self.sql_connection = None
            modules.logger.error(str(e))
        return self.sql_connection

    def execute_sql(self, sql_command_count, sql_command_error):
        '''
            Execute SQL on database
        '''
        # Variables
        self.sql_command_count = sql_command_count
        self.sql_command_error = sql_command_error

        # Estbalish Connection
        self.sql_connection_established = self.get_connection()

        # Execute SQL
        if self.sql_connection_established is not None and self.sql_command_count is not None:
            self.sql_cursor = self.sql_connection_established.cursor()
            self.sql_result = self.sql_cursor.execute(self.sql_command_count)
            # Execute SQL for Count
            if self.sql_result is not None:
                self.sql_rows = self.sql_result.fetchone()  # Only expecting SQL with one return, if not use fetchall()
                if self.sql_rows is not None:
                    self.sql_output = self.sql_rows[0]  # Only return first item of list
                else:
                    self.sql_output = 0  # No rows returned
            else:
                self.sql_output = -1  # Should not happen TODO raise error

            # Execute SQL for Text if count > 0
            self.sql_error_output = []
            if self.sql_output > 0:
                self.sql_result = self.sql_cursor.execute(self.sql_command_error)
                if self.sql_result is not None:
                    for line in self.sql_result.fetchall():
                        self.sql_error_output.append(str(line))
            self.sql_cursor.close()
            self.sql_connection_established.close()

        # Result
        return [self.sql_output, self.sql_error_output]


# Initialise databases
financialDB = Schema(cfg['secrets']['database_financial']['tag_secret'], cfg['secrets']['database_financial']['tag_schema'], cfg['secrets']['database_financial']['tag_username'], cfg['secrets']['database_financial']['tag_password'], cfg['secrets']['database_financial']['tag_host'], cfg['secrets']['database_financial']['tag_port'])
datamartDB = Schema(cfg['secrets']['database_datamart']['tag_secret'], cfg['secrets']['database_datamart']['tag_schema'], cfg['secrets']['database_datamart']['tag_username'], cfg['secrets']['database_datamart']['tag_password'], cfg['secrets']['database_datamart']['tag_host'], cfg['secrets']['database_datamart']['tag_port'])
limitDB = Schema(cfg['secrets']['database_limits']['tag_secret'], cfg['secrets']['database_limits']['tag_schema'], cfg['secrets']['database_limits']['tag_username'], cfg['secrets']['database_limits']['tag_password'], cfg['secrets']['database_limits']['tag_host'], cfg['secrets']['database_limits']['tag_port'])

# Initialise sql lists
if mx_role_value == cfg['tags']['mx_role_value_for_primary_orchestrator']:
    sql_list = cfg['database']['sql_list_node_primary_orchestrator'] + cfg['database']['sql_list_nodes_all']
else:
    sql_list = cfg['database']['sql_list_nodes_all']


def validate_sql_output(cloudwatch_metric_name, sql_output, sql_output_has_errors_lines, sql_output_valid=True):
    '''
        Function to validate output if type is integer or float
    '''

    # Probe for integer or float
    if type(sql_output) not in (int, float):
        modules.logger.error(f'Sql {cloudwatch_metric_name}: expected type to be integer or float. Value given {sql_output} with type {type(sql_output)}')
        sql_output = -1
        sql_output_valid = False

    # Return
    return [sql_output, sql_output_has_errors_lines, sql_output_valid]


def get_sqls():
    '''
        Function to get output of sql statements
    '''

    # SQLs to process
    sql_cw_metrics_outputs = []
    sql_cw_log_groups_outputs = []

    for (cloudwatch_name, schedule_name, cloudwatch_metric_name, sql_statement_count, sql_statement_error) in sql_list:
        try:
            # Financial SQL
            if cloudwatch_name == 'financialDB':
                if modules.scheduler.validate_schedule(schedule_name):
                    sql_result = financialDB.execute_sql(sql_statement_count, sql_statement_error)
                    cloudwatch_metric_value = validate_sql_output(cloudwatch_metric_name, sql_result[0], sql_result[1])
                    if cloudwatch_metric_value[2]:
                        sql_cw_metrics_outputs.append([cloudwatch_name, cloudwatch_metric_name, cloudwatch_metric_value[0]])
                        if cloudwatch_metric_value[1] != []:
                            sql_cw_log_groups_outputs.append([cloudwatch_name, cloudwatch_metric_name, cloudwatch_metric_value[1]])

            # Datamart SQL
            elif cloudwatch_name == 'datamartDB':
                if modules.scheduler.validate_schedule(schedule_name):
                    sql_result = datamartDB.execute_sql(sql_statement_count, sql_statement_error)
                    cloudwatch_metric_value = validate_sql_output(cloudwatch_metric_name, sql_result[0], sql_result[1])
                    if cloudwatch_metric_value[2]:
                        sql_cw_metrics_outputs.append([cloudwatch_name, cloudwatch_metric_name, cloudwatch_metric_value[0]])
                        if cloudwatch_metric_value[1] != []:
                            sql_cw_log_groups_outputs.append([cloudwatch_name, cloudwatch_metric_name, cloudwatch_metric_value[1]])

            # Limit SQL
            elif cloudwatch_name == 'limitDB':
                if modules.scheduler.validate_schedule(schedule_name):
                    sql_result = limitDB.execute_sql(sql_statement_count, sql_statement_error)
                    cloudwatch_metric_value = validate_sql_output(cloudwatch_metric_name, sql_result[0], sql_result[1])
                    if cloudwatch_metric_value[2]:
                        sql_cw_metrics_outputs.append([cloudwatch_name, cloudwatch_metric_name, cloudwatch_metric_value[0]])
                        if cloudwatch_metric_value[1] != []:
                            sql_cw_log_groups_outputs.append([cloudwatch_name, cloudwatch_metric_name, cloudwatch_metric_value[1]])

            else:
                modules.logger.error(f'Sql {cloudwatch_metric_name}: cloudwatch_name {cloudwatch_name} is not configured')

        except Exception as e:
            modules.logger.error(f'Sql {cloudwatch_metric_name}: {str(e)}')

    # Return
    return [sql_cw_metrics_outputs, sql_cw_log_groups_outputs]


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value, sql_cw_metrics_outputs):
    '''
        Function to create Cloudwatch metrics for database sqls
    '''

    metrics = []

    for (cloudwatch_name, cloudwatch_metric_name, cloudwatch_metric_value) in sql_cw_metrics_outputs:
        metric = {
                'MetricName': cloudwatch_metric_name,
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                    {
                        'Name': 'database',
                        'Value': cloudwatch_name
                    },
                ],
                'Unit': 'Count',
                'Value': cloudwatch_metric_value
            }

        if cloudwatch_metric_value == 0:
            if cfg['database']['heartbeat'] or cfg['general']['inital_metrics_mode']:
                metrics.append(metric)
        else:
            metrics.append(metric)

    return(metrics)


def cwatch_log_groups(mx_environment_value, mx_role_value, mx_host_value, sql_cw_log_groups_outputs):
    '''
        Function to create Cloudwatch Log Group entries for database sqls
    '''
    for log_group in sql_cw_log_groups_outputs:
        if log_group != []:
            database, cloudwatch_metric_name, sql_cw_log_group_outputs = log_group
            modules.cloudwatchlogs.log_streams_put_event_list(f'/{mx_environment_value}/{database}', cloudwatch_metric_name, sql_cw_log_group_outputs)


def cwatch_router(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics for database sqls and logging entries for Cloudwatch Log Groups
    '''
    sql_cw_metrics_outputs, sql_cw_log_groups_outputs = get_sqls()

    # Process Metrics
    metrics = cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value, sql_cw_metrics_outputs)

    # Process Log Groups
    cwatch_log_groups(mx_environment_value, mx_role_value, mx_host_value, sql_cw_log_groups_outputs)

    return(metrics)
