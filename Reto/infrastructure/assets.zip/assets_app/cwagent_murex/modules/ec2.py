# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import requests
import boto3
import yaml

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)


def get_instance_id():
    '''
        Function to read the ec2 instance-id from metadata service
    '''
    try:
        response = requests.get('http://169.254.169.254/latest/meta-data/instance-id')
    except:
        return 'no-instance-id'
    else:
        if response.status_code == 200:
            return response.text
        else:
            return 'no-instance-id'


def get_tags():
    '''
        Function to read the ec2 tags
    '''
    ec2 = boto3.client(service_name='ec2', region_name=cfg['general']['aws_region'])
    ec2Tags = ec2.describe_tags(
        Filters=[
            {
                'Name': 'resource-id',
                'Values': [
                    get_instance_id(),
                ],
            },
        ],
    )
    return ec2Tags


def get_instance_type():
    '''
        Process to determine the EC2 instance type
    '''
    client_ec2 = boto3.resource(service_name='ec2', region_name=cfg['general']['aws_region'])

    try:
        response_ec2 = client_ec2.Instance(get_instance_id())
    except:
        return None
    else:
        return response_ec2.instance_type


def get_cloudwatch_tags():
    '''
        Function to receive ec2 tag information for mx_environment_value and mx_role_value
    '''
    # Define defaults
    mx_environment_value = 'untagged_environment'
    mx_role_value = 'untagged_role'
    # Get tags
    ec2Tags = get_tags()
    # Read tags
    for tag in ec2Tags['Tags']:
        # mx_environment_value
        if tag['Key'] == cfg['tags']['mx_environment'] and tag['ResourceType'] == 'instance':
            mx_environment_value = tag['Value']
        # mx_role_value
        elif tag['Key'] == cfg['tags']['mx_role'] and tag['ResourceType'] == 'instance':
            mx_role_value = tag['Value']
    return([mx_environment_value, mx_role_value])


def get_cloudwatchlogs_tags(log_group_tags_list):
    '''
        Function to receive ec2 tag information for given tags in log_group_tags_list
    '''
    # Define Value list
    log_group_value_list = []

    # Get EC2 tags
    ec2Tags = get_tags()

    # Read Tags List
    for loggroup_tag in log_group_tags_list:
        loggroup_tag_found = False
        loggroup_tag_value = None
        # Read EC2 tags
        for tag in ec2Tags['Tags']:
            if tag['Key'] == loggroup_tag and tag['ResourceType'] == 'instance':
                loggroup_tag_found = True
                loggroup_tag_value = tag['Value']
        # Copy Value
        if loggroup_tag_found:
            log_group_value_list.append(loggroup_tag_value)
        else:
            log_group_value_list.append(f'{loggroup_tag}')

    # Build log_group_name
    log_group_name = ''
    for value in log_group_value_list:
        log_group_name += f'{value}-'

    return log_group_name[:len(log_group_name) - 1]  # (removing trailing -)
