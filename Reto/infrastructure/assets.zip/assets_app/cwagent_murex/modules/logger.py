
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import yaml
import os
import logging
import modules.hostname
import modules.ec2
import modules.cloudwatchlogs

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)
filename = cfg['general']['log_file']

# Initialisation
host_name = modules.hostname.get_name()

# Check presence of logfile
if os.path.isfile(filename) is False:
    try:
        # if not present, create an empty file
        with open(filename, 'w'):
            pass
    except:
        process_pid = os.getpid()
        alternative_filename = f'/tmp/cloudwatch.{process_pid}.log'
        print(f'ERROR - logfile {filename} is missing and could not be created. Please check if folders/mounts are present. Redirecting to {alternative_filename}')
        filename = alternative_filename

# Check presence of log group and log stream
log_to_cloudwatchlogs = cfg['general']['log_to_cloudwatchlogs']
log_stream_push = cfg['general']['log_stream_push']
log_group_suffix = cfg['general']['log_group_suffix']
log_stream = cfg['general']['log_stream']
if log_to_cloudwatchlogs:
    # Get

    # Initialize Cloudwatch Log Group for Logger
    if cfg['general']['log_group_mode'] == 'string':
        log_group_name = cfg['general']['log_group_string_name']
    elif cfg['general']['log_group_mode'] == 'auto':
        log_group_name, _ = modules.ec2.get_cloudwatch_tags()
    elif cfg['general']['log_group_mode'] == 'tags':
        log_group_name = modules.ec2.get_cloudwatchlogs_tags(cfg['general']['log_group_tags_list'])
    else:
        log_group_name = 'log-group-not-defined'


def main():
    '''
        Function to define main properties
    '''
    logging.basicConfig(format='%(asctime)s %(message)s', filename=filename, level=logging.INFO)


def debug(payload):
    '''
        Function for log level DEBUG
    '''
    main()
    if log_to_cloudwatchlogs and 'DEBUG' in log_stream_push:
        modules.cloudwatchlogs.log_streams_put_event_list(f'/{log_group_name}/{log_group_suffix}', log_stream, [f'DEBUG   : {host_name}: {payload}', ])
    if os.path.isfile(filename):
        logging.debug(f'DEBUG   : {host_name}: {payload}')
    else:
        print(payload)


def info(payload):
    '''
        Function for log level INFO
    '''
    main()
    if log_to_cloudwatchlogs and 'INFO' in log_stream_push:
        modules.cloudwatchlogs.log_streams_put_event_list(f'/{log_group_name}/{log_group_suffix}', log_stream, [f'INFO   : {host_name}: {payload}', ])
    if os.path.isfile(filename):
        logging.info(f'INFO    : {host_name}: {payload}')
    else:
        print(payload)


def warning(payload):
    '''
        Function for log level WARNING
    '''
    main()
    if log_to_cloudwatchlogs and 'WARNING' in log_stream_push:
        modules.cloudwatchlogs.log_streams_put_event_list(f'/{log_group_name}/{log_group_suffix}', log_stream, [f'WARNING: {host_name}: {payload}', ])
    if os.path.isfile(filename):
        logging.warning(f'WARNING : {host_name}: {payload}')
    else:
        print(payload)


def error(payload):
    '''
        Function for log level ERROR
    '''
    main()
    if log_to_cloudwatchlogs and 'ERROR' in log_stream_push:
        modules.cloudwatchlogs.log_streams_put_event_list(f'/{log_group_name}/{log_group_suffix}', log_stream, [f'ERROR   : {host_name}: {payload}', ])
    if os.path.isfile(filename):
        logging.error(f'ERROR   : {host_name}: {payload}')
    else:
        print(payload)


# Message for Cloudwatch Client
mx_environment_tag = cfg['tags']['mx_environment']
if 'aws:' in mx_environment_tag:
    modules.cloudwatchlogs.log_streams_put_event_list(f'/{log_group_name}/{log_group_suffix}', log_stream, [f'WARNUNG: {host_name}: Murex environment Tag {mx_environment_tag} cannot be used. aws: is a reserved tag space. Using Tag "mx_environment" instead.', ])
