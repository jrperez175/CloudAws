# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import yaml
import datetime

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

schedules = cfg['scheduler']['schedules']


def validate_day(schedule_day):
    '''
        validates string date value against today'S weekday
    '''

    # Translate schedule day
    if schedule_day == 'monday':
        schedule_day_identifier = 0
    elif schedule_day == 'tuesday':
        schedule_day_identifier = 1
    elif schedule_day == 'wednesday':
        schedule_day_identifier = 2
    elif schedule_day == 'thursday':
        schedule_day_identifier = 3
    elif schedule_day == 'friday':
        schedule_day_identifier = 4
    elif schedule_day == 'saturday':
        schedule_day_identifier = 5
    elif schedule_day == 'sunday':
        schedule_day_identifier = 6
    elif schedule_day == 'workdays':
        schedule_day_identifier = [0, 1, 2, 3, 4]
    elif schedule_day == 'daily':
        schedule_day_identifier = [0, 1, 2, 3, 4, 5, 6]
    elif schedule_day == 'weekends':
        schedule_day_identifier = [5, 6]
    else:
        schedule_day_identifier = -1

    # Today
    today_day_identifier = datetime.datetime.today().weekday()

    # Validation
    if type(schedule_day_identifier) == int:
        if today_day_identifier == schedule_day_identifier:
            return True
        else:
            return False
    else:  # List check daily, workdays, weekends
        if today_day_identifier in schedule_day_identifier:
            return True
        else:
            return False


def validate_time(schedule_start_time, schedule_end_time):
    '''
        validates string date value against today'S weekday
    '''
    # Now
    now = datetime.datetime.now()
    # Window - Start
    start_hour, start_minute, start_second = schedule_start_time.split(':')
    start_time = now.replace(hour=int(start_hour), minute=int(start_minute), second=int(start_second), microsecond=0)
    # Window - End
    end_hour, end_minute, end_second = schedule_end_time.split(':')
    end_time = now.replace(hour=int(end_hour), minute=int(end_minute), second=int(end_second), microsecond=0)

    # Validation
    if now >= start_time and now <= end_time:
        return True
    else:
        return False


def validate_schedule(cloudwatch_metric_name):
    '''
        Check if cloudwatch_metric_name is allowed to be executed
    '''
    cloudwatch_metric_validation = False

    # Check if cloudwatch_metric_name is defiend in scheduler
    if cloudwatch_metric_name in schedules[0]:
        # Read specific scheduler configuration
        for (metric_name, metric_schedules) in schedules:
            if metric_name == cloudwatch_metric_name:
                for metric_schedule in metric_schedules:
                    schedule_day = metric_schedule[0]
                    schedule_start_time = metric_schedule[1]
                    schedule_end_time = metric_schedule[2]
                    # Validate matching day
                    if validate_day(schedule_day):
                        # Validate matching time
                        if validate_time(schedule_start_time, schedule_end_time):
                            # Avoid overriding if several schedules are defined: if True than stay True
                            if cloudwatch_metric_validation is False:
                                cloudwatch_metric_validation = True
    else:
        # No schedule defined = automatic True
        cloudwatch_metric_validation = True

    return cloudwatch_metric_validation
