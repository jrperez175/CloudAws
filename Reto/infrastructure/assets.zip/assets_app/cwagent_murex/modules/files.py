# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

# Links
# https://pypi.org/project/pygtail/

from pygtail import Pygtail
import yaml
import os
import modules.logger
import modules.ec2
import modules.hostname

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

# Host name to replace placeholder variable @@@HOSTNAME@@@ from yaml
host_name = modules.hostname.get_name()

# Read Tags
mx_environment_value, mx_role_value = modules.ec2.get_cloudwatch_tags()

# Initialise log lists
if mx_role_value == cfg['tags']['mx_role_value_for_primary_orchestrator']:
    log_files_list = cfg['files']['log_files_list_node_primary_orchestrator'] + cfg['files']['log_files_list_nodes_all']
else:
    log_files_list = cfg['files']['log_files_list_nodes_all']


def get_logs():
    '''
        Function to scan log files for patterns
    '''
    # logs_container
    logs = []

    # Read configuration
    for (logfile_destination, logfile_cloudwatch_name, logfile_patterns) in log_files_list:

        # Replace @@@HOSTNAME@@@ in log destination by host_name
        logfile_destination = logfile_destination.replace('@@@HOSTNAME@@@', host_name)

        # Replace @@@MUREX_ENVIRONMENT@@@ in log destination by mx_environment_value
        logfile_destination = logfile_destination.replace('@@@MUREX_ENVIRONMENT@@@', mx_environment_value)

        # Check if logfile exists
        if os.path.isfile(logfile_destination):

            # Check access rights
            if os.access(logfile_destination, os.R_OK):

                # Set identifier
                pattern_count = 0
                logfile_patterns_identified = []
                for (logfile_pattern, logfile_cloudwatch_metric_name, logfile_cloudwatch_metric_value) in logfile_patterns:
                    logfile_patterns_identified.append([logfile_pattern, logfile_cloudwatch_metric_name, logfile_cloudwatch_metric_value, False])
                    pattern_count += 1

                # Read new content
                for logfile_line in Pygtail(logfile_destination):

                    # Read logfile patterns
                    pattern_count = 0
                    for (logfile_pattern, logfile_cloudwatch_metric_name, logfile_cloudwatch_metric_value, logfile_pattern_new_content) in logfile_patterns_identified:

                        # Check for logfile pattern
                        if logfile_pattern.lower() in logfile_line.lower():

                            # Match of pattern inline
                            logs.append([logfile_cloudwatch_name, logfile_cloudwatch_metric_name, logfile_cloudwatch_metric_value])

                            # Update identifier
                            logfile_patterns_identified[pattern_count][3] = True

                        # Increase pattern_count
                        pattern_count += 1

                # Read logfile patterns
                for (logfile_pattern, logfile_cloudwatch_metric_name, logfile_cloudwatch_metric_value, logfile_pattern_new_content) in logfile_patterns_identified:

                    # sending heartbeat
                    if logfile_pattern_new_content is False and (cfg['files']['heartbeat'] or cfg['general']['inital_metrics_mode']):
                        logs.append([logfile_cloudwatch_name, logfile_cloudwatch_metric_name, 0.0])

            # No Access
            else:
                modules.logger.error(f'Access rights missing for file {logfile_destination}')

    # Return
    return logs


def cwatch_metrics(mx_environment_value, mx_role_value, mx_host_value):
    '''
        Function to create Cloudwatch metrics for log files pattern analysis
    '''

    metrics = []
    logfiles = get_logs()

    for (logfile_cloudwatch_name, logfile_cloudwatch_metric_name, logfile_cloudwatch_metric_value) in logfiles:
        metric = {
                'MetricName': logfile_cloudwatch_metric_name,
                'Dimensions': [
                    {
                        'Name': 'mx_host',
                        'Value': mx_host_value
                    },
                    {
                        'Name': 'mx_role',
                        'Value': mx_role_value
                    },
                    {
                        'Name': 'mx_environment',
                        'Value': mx_environment_value
                    },
                    {
                        'Name': 'log_file',
                        'Value': logfile_cloudwatch_name
                    },
                ],
                'Unit': 'Count',
                'Value': logfile_cloudwatch_metric_value
            }
        metrics.append(metric)

    return(metrics)
