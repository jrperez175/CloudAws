#!/bin/python3
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import yaml
import modules.cloudwatch
# import boto3
# import logging

# boto3.set_stream_logger('', logging.DEBUG)

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

# Initialize modules for cloudwatch
if cfg['modules']['server']['enabled']:
    server = modules.cloudwatch.Module('server')
if cfg['modules']['cpu']['enabled']:
    cpu = modules.cloudwatch.Module('cpu')
if cfg['modules']['database']['enabled']:
    database = modules.cloudwatch.Module('database')
if cfg['modules']['disks']['enabled']:
    disks = modules.cloudwatch.Module('disks')
if cfg['modules']['files']['enabled']:
    files = modules.cloudwatch.Module('files')
if cfg['modules']['gpu']['enabled']:
    gpu = modules.cloudwatch.Module('gpu')
if cfg['modules']['network']['enabled']:
    network = modules.cloudwatch.Module('network')
if cfg['modules']['processes']['enabled']:
    processes = modules.cloudwatch.Module('processes')
if cfg['modules']['ram']['enabled']:
    ram = modules.cloudwatch.Module('ram')
if cfg['modules']['jmx']['enabled']:
    jmx = modules.cloudwatch.Module('jmx')

# Main
if __name__ == '__main__':

    # SERVER
    if cfg['modules']['server']['enabled']:
        server.print_metrics()

    # CPU
    if cfg['modules']['cpu']['enabled']:
        cpu.print_metrics()

    # RAM
    if cfg['modules']['ram']['enabled']:
        ram.print_metrics()

    # Disks
    if cfg['modules']['disks']['enabled']:
        disks.print_metrics()

    # Network
    if cfg['modules']['network']['enabled']:
        network.print_metrics()

    # GPU
    if cfg['modules']['gpu']['enabled']:
        gpu.print_metrics()

    # Processes
    if cfg['modules']['processes']['enabled']:
        processes.print_metrics()

    # Files
    if cfg['modules']['files']['enabled']:
        files.print_metrics()

    # Database
    if cfg['modules']['database']['enabled']:
        database.print_metrics()

    # JMX
    if cfg['modules']['jmx']['enabled']:
        jmx.print_metrics()
