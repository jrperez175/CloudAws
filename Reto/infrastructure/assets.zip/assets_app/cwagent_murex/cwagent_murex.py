#!/bin/python3
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import os
import sys
import time
import yaml
import modules.cloudwatch
import modules.cloudwatchlogs
import modules.functions
import modules.ec2
import modules.init

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

# Commom init
modules.init.run()

# Initialize modules for cloudwatch
server = modules.cloudwatch.Module('server')
cpu = modules.cloudwatch.Module('cpu')
database = modules.cloudwatch.Module('database')
disks = modules.cloudwatch.Module('disks')
files = modules.cloudwatch.Module('files')
gpu = modules.cloudwatch.Module('gpu')
network = modules.cloudwatch.Module('network')
processes = modules.cloudwatch.Module('processes')
ram = modules.cloudwatch.Module('ram')
jmx = modules.cloudwatch.Module('jmx')

# Read individual modules frequencies
loop_frequency = cfg['general']['frequency']
server_frequency = cfg['modules']['server']['frequency']
cpu_frequency = cfg['modules']['cpu']['frequency']
database_frequency = cfg['modules']['database']['frequency']
disks_frequency = cfg['modules']['disks']['frequency']
files_frequency = cfg['modules']['files']['frequency']
gpu_frequency = cfg['modules']['gpu']['frequency']
network_frequency = cfg['modules']['network']['frequency']
processes_frequency = cfg['modules']['processes']['frequency']
ram_frequency = cfg['modules']['ram']['frequency']
jmx_frequency = cfg['modules']['jmx']['frequency']

# Set individual modules frequencies counter
server_frequency_counter = 0
cpu_frequency_counter = 0
database_frequency_counter = 0
disks_frequency_counter = 0
files_frequency_counter = 0
gpu_frequency_counter = 0
network_frequency_counter = 0
processes_frequency_counter = 0
ram_frequency_counter = 0
jmx_frequency_counter = 0

# Main
if __name__ == '__main__':
    fpid = os.fork()
    if fpid != 0:
        # Running as daemon now. PID is fpid
        while 1:

            # Server
            if server_frequency_counter == 0:
                cpu.send_metrics()
            server_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, server_frequency, server_frequency_counter)

            # CPU
            if cpu_frequency_counter == 0:
                cpu.send_metrics()
            cpu_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, cpu_frequency, cpu_frequency_counter)

            # RAM
            if ram_frequency_counter == 0:
                ram.send_metrics()
            ram_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, ram_frequency, ram_frequency_counter)

            # Disks
            if disks_frequency_counter == 0:
                disks.send_metrics()
            disks_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, disks_frequency, disks_frequency_counter)

            # Network
            if network_frequency_counter == 0:
                network.send_metrics()
            network_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, network_frequency, network_frequency_counter)

            # GPU
            if gpu_frequency_counter == 0:
                gpu.send_metrics()
            gpu_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, gpu_frequency, gpu_frequency_counter)

            # Processes
            if processes_frequency_counter == 0:
                processes.send_metrics()
            processes_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, processes_frequency, processes_frequency_counter)

            # Files
            if files_frequency_counter == 0:
                files.send_metrics()
            files_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, files_frequency, files_frequency_counter)

            # Database
            if database_frequency_counter == 0:
                database.send_metrics()
            database_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, database_frequency, database_frequency_counter)

            # JMX
            if jmx_frequency_counter == 0:
                jmx.send_metrics()
            jmx_frequency_counter = modules.functions.set_frequency_counter(loop_frequency, jmx_frequency, jmx_frequency_counter)

            # Loop Frequency (sleep)
            time.sleep(loop_frequency)

    sys.exit(0)
