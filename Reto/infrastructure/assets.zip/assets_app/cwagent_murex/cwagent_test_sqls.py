#!/bin/python3
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import yaml
import modules.database

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

# Read Tags
mx_environment_value, mx_role_value = modules.ec2.get_cloudwatch_tags()

# Initialise databases
financialDB = modules.database.Schema(cfg['secrets']['database_financial']['tag_secret'], cfg['secrets']['database_financial']['tag_schema'], cfg['secrets']['database_financial']['tag_username'], cfg['secrets']['database_financial']['tag_password'], cfg['secrets']['database_financial']['tag_host'], cfg['secrets']['database_financial']['tag_port'])
datamartDB = modules.database.Schema(cfg['secrets']['database_datamart']['tag_secret'], cfg['secrets']['database_datamart']['tag_schema'], cfg['secrets']['database_datamart']['tag_username'], cfg['secrets']['database_datamart']['tag_password'], cfg['secrets']['database_datamart']['tag_host'], cfg['secrets']['database_datamart']['tag_port'])
limitDB = modules.database.Schema(cfg['secrets']['database_limits']['tag_secret'], cfg['secrets']['database_limits']['tag_schema'], cfg['secrets']['database_limits']['tag_username'], cfg['secrets']['database_limits']['tag_password'], cfg['secrets']['database_limits']['tag_host'], cfg['secrets']['database_limits']['tag_port'])

# Initialise sql lists
if mx_role_value == cfg['tags']['mx_role_value_for_primary_orchestrator']:
    sql_list = cfg['database']['sql_list_node_primary_orchestrator'] + cfg['database']['sql_list_nodes_all']
else:
    sql_list = cfg['database']['sql_list_nodes_all']

# Runs Sqls
for (database_name, schedule_name, sql_name, sql_statement_count, sql_statement_error) in sql_list:
    print(f'Processing database {database_name} - sql {sql_name}')
    print('----------------------------------------------------------')
    print('')
    try:
        # Financial SQL
        if database_name == 'financialDB':
            # Exec Count SQL
            sql_result = financialDB.execute_sql(sql_statement_count, sql_statement_error)
            print([sql_name, 'count_sql', sql_result[0]])
            # Force Error SQL Execution
            sql_statement_count = "select 1 from dual"
            sql_result = financialDB.execute_sql(sql_statement_count, sql_statement_error)
            print([sql_name, 'error_sql', sql_result[1]])

        # Datamart SQL
        elif database_name == 'datamartDB':
            # Exec Count SQL
            sql_result = financialDB.execute_sql(sql_statement_count, sql_statement_error)
            print([sql_name, 'count_sql', sql_result[0]])
            # Force Error SQL Execution
            sql_statement_count = "select 1 from dual"
            sql_result = financialDB.execute_sql(sql_statement_count, sql_statement_error)
            print([sql_name, 'error_sql', sql_result[1]])

        # Limit SQL
        elif database_name == 'limitDB':
            # Exec Count SQL
            sql_result = financialDB.execute_sql(sql_statement_count, sql_statement_error)
            print([sql_name, 'count_sql', sql_result[0]])
            # Force Error SQL Execution
            sql_statement_count = "select 1 from dual"
            sql_result = financialDB.execute_sql(sql_statement_count, sql_statement_error)
            print([sql_name, 'error_sql', sql_result[1]])
    except Exception as e:
        print([sql_name, 'error', str(e)])
    print('')
    print('')
    print('')
