#!/bin/python3
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at:
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.

import yaml
import modules.cloudwatch
import modules.cloudwatchlogs
import modules.functions
import modules.ec2
import modules.init

# Load configuration file
with open('config.yml', 'r') as ymlfile:
    cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

# Commom init
modules.init.run()

# Initialize modules for cloudwatch
server = modules.cloudwatch.Module('server')
cpu = modules.cloudwatch.Module('cpu')
database = modules.cloudwatch.Module('database')
disks = modules.cloudwatch.Module('disks')
files = modules.cloudwatch.Module('files')
gpu = modules.cloudwatch.Module('gpu')
network = modules.cloudwatch.Module('network')
processes = modules.cloudwatch.Module('processes')
ram = modules.cloudwatch.Module('ram')
jmx = modules.cloudwatch.Module('jmx')

# Main
if __name__ == '__main__':

    # SERVER
    server.send_metrics()

    # CPU
    cpu.send_metrics()

    # RAM
    ram.send_metrics()

    # Disks
    disks.send_metrics()

    # Network
    network.send_metrics()

    # GPU
    gpu.send_metrics()

    # Processes
    processes.send_metrics()

    # Files
    files.send_metrics()

    # Database
    database.send_metrics()

    # JMX
    jmx.send_metrics()
