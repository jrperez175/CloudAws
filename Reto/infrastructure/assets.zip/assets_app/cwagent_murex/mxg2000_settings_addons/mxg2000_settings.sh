#EDEunchmxj.app 2.10 version
# Mx G2000 Environment variables setup
#set -x

OS_TYPE=`uname`

if [ "$OS_TYPE" = "SunOS" ]; then
JAVAHOME=/usr/local/java/jdk1.7.0_151
fi
if [ "$OS_TYPE" = "AIX" ]; then
JAVAHOME=/usr/local/java/jdk1.7.0_151
fi
if [ "$OS_TYPE" = "HP-UX" ]; then
JAVAHOME=/usr/local/java/jdk1.7.0_151
fi
if [ "$OS_TYPE" = "Linux" ]; then
JAVAHOME=/usr/local/java/jdk1.7.0_151
JAVAHOME_64=/usr/local/java/jdk1.7.0_151
export JAVAHOME_64
fi
export JAVAHOME

FD_LIMIT=4096
export FD_LIMIT

# Sybase home used to locate interface files and Open Client dynamic libraries
#SYBASE=/opt/sybase/oc15.7-EBF21018
#export SYBASE

# Oracle Home used to locate Oracle Client dynamic libraries
ORACLE_HOME=/opt/oracle/11204_64
export ORACLE_HOME
NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export NLS_LANG

JVM_OPTION="$JVM_OPTION"

# Configuration Sourcing
FILES="/murex/murex_app/app/mxg2000_settings_memory_addon.sh /murex/murex_app/app/mxg2000_settings_jmx_addon.sh /murex/murex_app/app/mxg2000_settings_gc_addon.sh"
for F in $FILES; do
# echo "File $F loaded"
[ -e $F ] && . $F
done

#MXG2000_HOME=/apps/murfx2000_new
#export MXG2000_HOME

#MXJ_JDK_OR_JRE=jdk
#MXJ_JDK_OR_JRE=jre

# Define the encrypted password for the monitor 
MXJ_PASSWORD=00d000530057002500a000d500d000e300670067

# Define your default Mx G2000 File Server environment
# Warning : Take care of the MXJ_FILESERVER_HOST in case of running on different host.
MXJ_FILESERVER_HOST=lbcldwdmuc01
MXJ_FILESERVER_PORT=10000

# Optional File ServerTLS/SSL settings
#MXJ_FILESERVER_TLS_PORT=10001
#MXJ_FILESERVER_TLS_CLIENT_AUTH=N


MXJ_FILESERVER_TIME_ADJUSTMENT=1
# Optional arguments passed to the FileServer.
# " " are mandatory if several args.
FILESERVER_ARGS="$FILESERVER_ARGS"

# Define your default Mx G2000 XmlServer environment
#Backward compatibility with Version 2.2.9 
#Leave it blank with 2.2.10.
MXJ_HOST=
MXJ_PORT=

# Optional arguments passed to the XmlServer such as forcing attachment to
# a specific IP adrress. " " are mandatory if several args.
#XML_SERVER_ARGS="-Djava.rmi.server.hostname=mxapp"
XML_SERVER_ARGS="$XML_SERVER_ARGS"

# Define your default Mx G2000 Site and Hub environment
#Define your site name, must be defined in site.mxres.
#Leave it by default. 
MXJ_SITE_NAME=site1

#Define your hub name, must be defined in site.mxres.
#Leave it by default. 
MXJ_HUB_NAME=hub1

# Optional arguments passed to the Hub home such as forcing attachment to
# a specific IP adrress. " " are mandatory if several args.
HUB_HOME_ARGS="-Djava.rmi.server.hostname=lbcldwdmuc01"

# Define your default Mx G2000 MxMlExchange environment
# Optional arguments passed to the MxMlExchange Server.
# " " are mandatory if several args.
#MXML_SERVER_ARGS="$MXML_SERVER_ARGS -Xmx512m -Djava.rmi.server.hostname=X.X.X.X"
MXML_JVM_ARGS="$MXML_JVM_ARGS"
MXMLSECONDARY_JVM_ARGS="$MXMLSECONDARY_JVM_ARGS"
MXMLSPACES_JVM_ARGS="$MXMLSPACES_JVM_ARGS"
MXMLWORKER_JVM_ARGS="$MXMLWORKER_JVM_ARGS -Dcom.ibm.mq.cfg.useIBMCipherMappings=false -Djavax.net.debug=ssl,handshake -Djavax.net.ssl.trustStore=/murex/certs/murex/keystorecnxqqmrx.jks -Djavax.net.ssl.trustStorePassword=ex/keystorecnxqqmrx.jks -Djavax.net.ssl.trustStorePassword=0011007b003300a700d600c4004b00ce00fd0012008e0089001b003500f5002e00e00030003a00c4004c007d0063002a009d00a600b8007e003400e7000c0039000f008e00d1000300af002500130017001400f200da002a00f400f2002300a2 -Djavax.net.ssl.keyStore=/murex/certs/murex/keystorecnxqqmrx.jks -Djavax.net.ssl.keyStorePassword=ex/keystorecnxqqmrx.jks -Djavax.net.ssl.keyStorePassword=0011007b003300a700d600c4004b00ce00fd0012008e0089001b003500f5002e00e00030003a00c4004c007d0063002a009d00a600b8007e003400e7000c0039000f008e00d1000300af002500130017001400f200da002a00f400f2002300a2"


# Define your default Mx G2000 WAREHOUSE environment
# Optional arguments passed to the WAREHOUSE Server.
# " " are mandatory if several args.
#WAREHOUSE_SERVER_ARGS="$WAREHOUSE_SERVER_ARGS -Djava.rmi.server.hostname=X.X.X.X"
WAREHOUSE_JVM_ARGS="$WAREHOUSE_JVM_ARGS"
MXJ_WAREHOUSE_LOGGER_FILE=public.mxres.loggers.warehouse_logger.mxres

# Define your default Mx G2000 MANDATORY environment
# Optional arguments passed to the MANDATORY Server.
# " " are mandatory if several args.
#MANDATORY_SERVER_ARGS="$MANDATORY_SERVER_ARGS -Djava.rmi.server.hostname=X.X.X.X"
MANDATORY_JVM_ARGS="$MANDATORY_JVM_ARGS"

# Define your default Mx G2000 Launcher environment
# Optional arguments passed to launcher.
# " " are mandatory if several args.
LAUNCHER_ARGS="$LAUNCHER_ARGS"

# Define your default Mx G2000 Murexnet environment
# Warning : Must be the same as specified into the murexnet.mxres configuration file
# by /IPHOST:namedhost:8000
# The Murexnet usually run on 8000 port, but you can use another one.
MUREXNET_PORT=10080

#Optional arguments passed to the murexnet such as forcing attachment to
# a specific IP adrress or logs." " are mandatory if several args.
#MUREXNET_ARGS="/IPALTADDR:10.10.8.150 /IPLOG"
MUREXNET_ARGS="$MUREXNET_ARGS"

# Variable to set the DISPLAY for X window rticachesession display.
# Leave it dynamic.
RTISESSION_XWIN_DISP=`echo $DISPLAY`
RTICACHESESSION_XWIN_DISP=`echo $DISPLAY`

# Define your default Mx G2000 MDCS environment
# Optional arguments passed to the MDCS Server.
# " " are mandatory if several args.
MDCS_JVM_ARGS="$MDCS_JVM_ARGS"

# Define your default Mx G2000 MLC environment
# Optional arguments passed to the MLC Server.
# " " are mandatory if several args.
MXMLC_JVM_ARGS="$MXMLC_JVM_ARGS -d64 -server"

# Define your default Mx G2000 LRB environment
# Optional arguments passed to the LRB Server.
# " " are mandatory if several args.
LRB_JVM_ARGS="$LRB_JVM_ARGS -d64 -server"

# Define your default Mx G2000 HIBERNATE environment
# Optional arguments passed to the HIBERNATE Server.
# " " are mandatory if several args.
RTBS_JVM_ARGS="$RTBS_JVM_ARGS"

# Define your default Mx G2000 HIBERNATE environment
# Optional arguments passed to the HIBERNATE Server.
# " " are mandatory if several args.
MXHIBERNATE_JVM_ARGS="$MXHIBERNATE_JVM_ARGS"

# Define your default Mx G2000 Alert Engine environment
# Optional arguments passed to the Alert Engine Server.
# " " are mandatory if several args.
ALERT_JVM_ARGS="$ALERT_JVM_ARGS"

# Define your default Mx G2000 AmendmentAgent environment
# Optional arguments passed to the AmendmentAgent Server.
# " " are mandatory if several args.
AAGENT_JVM_ARGS="$AAGENT_JVM_ARGS"

# Define your default Mx G2000 BOS environment
# Optional arguments passed to the BOS Server.
# " " are mandatory if several args.
BOS_JVM_ARGS="$BOS_JVM_ARGS"

# Define your default Mx G2000 Federation environment
# Optional arguments passed to the Federation Server.
# " " are mandatory if several args.
FEDERATION_JVM_ARGS="$FEDERATION_JVM_ARGS"
