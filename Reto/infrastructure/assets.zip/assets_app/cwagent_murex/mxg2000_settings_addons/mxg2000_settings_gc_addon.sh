# Create gc folder
GC_FOLDER="/murex/murex_app/app/logs/gc"
[ ! -d $GC_FOLDER ] && mkdir -p $GC_FOLDER

# Derive Hostname
HOST_NAME=$(/usr/bin/hostname)

# Garbage Collector (GC) Enablement
#Java general
JVM_OPTION="$JVM_OPTION"
#FileServer
FILESERVER_JVM_ARGS="$FILESERVER_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.fileserver.log"
# XmlServer
XML_SERVER_JVM_ARGS="$XML_SERVER_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.xml_server.log"
# Hub
HUB_HOME_JVM_ARGS="$HUB_HOME_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.hub_home.log"
#MxMlExchange all
MXML_JVM_ARGS="$MXML_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxml.log"
# MxMlExchange secondary
MXMLSECONDARY_JVM_ARGS="$MXMLSECONDARY_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxmlsecondary.log"
# MxMlExchange spaces
MXMLSPACES_JVM_ARGS="$MXMLSPACES_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxmlspaces.log"
# MxMlExchange worker
MXMLWORKER_JVM_ARGS="$MXMLWORKER_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxmlworker.log"
MXMLWORKER_JVM_ARGS="$MXMLWORKER_JVM_ARGS -Dsun.rmi.dgc.client.gcInterval=3600000 -Dsun.rmi.dgc.server.gcInterval=3600000 -XX:+HeapDumpOnOutOfMemoryError"
# AmendmentAgent
AAGENT_JVM_ARGS="$AAGENT_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.aagent.log"
# AlertEngine
ALERT_JVM_ARGS="$ALERT_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.alert.log"
# BOS
BOS_JVM_ARGS="$BOS_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.bos.log"
# MxHibernate
MXHIBERNATE_JVM_ARGS="$MXHIBERNATE_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxhibernate.log"
# Dsd
DSD_JVM_ARGS="$DSD_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.dsd.log"
# PrintSrv
PRINTSRV_JVM_ARGS="$PRINTSRV_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.printsrv.log"
# InlineHelp
INLINEHELP_JVM_ARGS="$INLINEHELP_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.inlinehelp.log"
# ModelerSrv
MODELERSRV_JVM_ARGS="$MODELERSRV_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.modelersrv.log"
# Warehouse
WAREHOUSE_JVM_ARGS="$WAREHOUSE_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.warehouse.log"
WAREHOUSE_JVM_ARGS="$WAREHOUSE_JVM_ARGS -Dsun.rmi.dgc.client.gcInterval=3600000 -Dsun.rmi.dgc.server.gcInterval=3600000"
# Inventory
INVENTORY_JVM_ARGS="$INVENTORY_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.inventory.log"
# Mandatory
MANDATORY_JVM_ARGS="$MANDATORY_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mandatory.log"
# MxRepository
# MXREPOSITORY_SERVER_ARGS="$MXREPOSITORY_SERVER_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxrepository_server.log"
# MDCS
MDCS_JVM_ARGS="$MDCS_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mdcs.log"
# MDRS
MDRS_JVM_ARGS="$MDRS_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mdrs.log"
# MDSS
MDSS_JVM_ARGS="$MDSS_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mdss.log"
# RTBS
RTBS_JVM_ARGS="$RTBS_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.rtbs.log"
RTBS_JVM_ARGS="$RTBS_JVM_ARGS -Dsun.rmi.dgc.client.gcInterval=36000000 -Dsun.rmi.dgc.server.gcInterval=36000000"
# FEDERATION
FEDERATION_JVM_ARGS="$FEDERATION_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.federation.log"
# Log Access
LOGACCESS_JVM_ARGS="$LOGACCESS_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.access.log"
# MPC
MPC_JVM_ARGS="$MPC_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mpc.log"
# MXOSP
OSP_JVM_ARGS="$OSP_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.osp.log"
# StaticData
STATIC_DATA_JVM_ARGS="$STATIC_DATA_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.static_data.log"
# OSPWS
OSP_WS_JVM_ARGS="$OSP_WS_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.osp_ws.log"
# Entitlement
ENTITLEMENT_JVM_ARGS="$ENTITLEMENT_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.entitlement.log"
# MLC
MXMLC_JVM_ARGS="$MXMLC_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxmlc.log"
# LRB
LRB_JVM_ARGS="$LRB_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.lrb.log"
# Launcher
# LAUNCHER_ARGS="$LAUNCHER_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.launcher.log"
# Murexnet
# MUREXNET_ARGS="$MUREXNET_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.murexnet.log"
# MxDataPublisher
MXDATAPUBLISHER_JVM_ARGS="$MXDATAPUBLISHER_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxdatapublisher.log"
# MxReportSrv
MXREPORTSRV_JVM_ARGS="$MXREPORTSRV_JVM_ARGS -verbose:gc -XX:+PrintGCTimeStamps -XX:+PrintGCDetails -Xloggc:${GC_FOLDER}/${HOST_NAME}.mxreportsrv.log"
