#!/bin/bash -l
cd /murex/proceso/
while read LINE ; do
        touch $LINE.stop
done < serversCluster.txt

while read LINE ; do
                touch $LINE.kill
        done < serversCluster.txt

