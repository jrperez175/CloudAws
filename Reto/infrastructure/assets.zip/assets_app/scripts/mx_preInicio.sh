#!/bin/bash -l

#########################################
# mx_preInicio.sh
# Descripcion                           Comandos de precondicion a ejecutar antes del reinicio que va antes del cierre
# Fecha de creacion                     2010/01/04
#########################################

cd $MUREX_HOME/proceso
hostname=`hostname`
strFecha=`date +"%Y%m%d"`
strFileName=$hostname.$strFecha.log

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Inicio precondiciones" >> $strFileName

#cp $MUREX_HOME/mlcLogger/mlclogger.debug $MUREX_HOME$MUREX_APP/fs/public/mxres/mxmlc/mlclogger.xml

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Fin precondiciones" >> $strFileName
