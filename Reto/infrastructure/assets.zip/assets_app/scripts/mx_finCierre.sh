#!/bin/bash -l

#########################################
# mx_finCierre.sh
# Descripcion                           Se invoca cuando termina el cierre. Ejecuta los siguientes pasos:
#					Detiene los horizontales
#					Reinicia el 03
#					Reinicia los horizontales
# Fecha de creacion                     2009/10/26
# Fech modificacion                     2013/03/20
# Descripcion modificacion              Se modifica un mensaje que estaba saliendo erroneo (parando en lugar de subiendo)
#                                       Se a�ade mensaje al script que dice que el servicio esta disponible
# Fecha modificacion                    2013/02/20
# Descripcion modificacion              Se a�ade el manejo de matar las horizontales en caso de pasar 10 minutos sin responder
# Fecha modificacion			2010/01/04
# Descripcion modificacion		Se a�ade lineas de precondicion para ejecutar antes del reinicio
#
# Fecha modificacion                    2014/04/03
# Descripcion modificacion              Se a�ade linea para subir workflows para iniciar operacion en las mesas
#########################################

declare -i numArchivos
declare -i numEspera

cd $MUREX_HOME/proceso
strFecha=`date +"%Y%m%d"`
hostname=`hostname`
strFileName=$hostname.$strFecha.log
strLock=$hostname.mx_cierre.lock

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Verificando y ejecutando precondiciones" >> $strFileName
mx_preFinal.sh

if [ ! -f $MUREX_HOME/proceso/serversCluster.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCluster.txt no existe" >> $strFileName
        exit 1
elif [ ! -r $MUREX_HOME/proceso/serversCluster.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCluster.txt no se puede leer" >> $strFileName
        exit 2
fi

if [ ! -f $MUREX_HOME/proceso/serversCierre.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCierre.txt no existe" >> $strFileName
        exit 3
elif [ ! -r $MUREX_HOME/proceso/serversCierre.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCierre.txt no se puede leer" >> $strFileName
        exit 4
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Murex - $0 - Fin de cierre diario" >> $strFileName
rm $strLock

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Iniciando fin de cierre - Parando las horizontales..." >> $strFileName
rm *.up

numServersCluster=`wc -l < serversCluster.txt`
numServersCierre=`wc -l < serversCierre.txt`

while read LINE ; do
        touch $LINE.stop
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Esperando el $LINE para terminar el cierre..." >> $strFileName
done < serversCierre.txt

numEspera=0
while [ $numEspera -lt 10 ]
do
        numArchivos=0

        while read LINE ; do
                if [ -e $LINE.down ]
                then
                        let numArchivos++
                fi
        done < serversCierre.txt

        if [ $numArchivos -eq $numServersCierre ]
        then
                numEspera=11
        else
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud de bajar para el fin de cierre" >> $strFileName
                let numEspera++
                sleep 60
        fi
done

if [ $numEspera -eq 10 ]
then
        while read LINE ; do
                touch $LINE.kill
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando MATAR Murex en la $LINE" >> $strFileName
        done < serversCluster.txt

        numEspera=0
        while [ $numEspera -lt 3 ]
        do
                numArchivos=0

                while read LINE ; do
                        if [ -e $LINE.kill ]
                        then
                                let numArchivos++
                        fi
                done < serversCluster.txt

                if [ $numArchivos -eq 0 ]
                then
                        numEspera=4
                else
                        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud de matar, no han parado $numArchivos horizontal
es" >> $strFileName
                        let numEspera++
                        sleep 60
                fi
        done
        if [ $numEspera -eq 3 ]
        then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - No bajo el sistema en las horizontales - Solo bajaron $numArchivos servidores" >> $strFileName
                ls -lrt *.down >> $strFileName
                exit 3

        fi
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Bajando el Middleware" >> $strFileName
mx_lanzarMxPdn.sh stop $hostname

sleep 10

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Validando precondiciones de inicio" >> $strFileName
mx_preFinSube.sh

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Subiendo el Middleware Server" >> $strFileName

mx_lanzarMxPdn.sh start $hostname

while read LINE ; do
        touch $LINE.start
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando subir Murex en la $LINE" >> $strFileName
done < serversCluster.txt

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Esperando que suban los horizontales..." >> $strFileName

numEspera=0
echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Esperando que suban los horizontales..." >> $strFileName

while [ $numEspera -lt 10 ]
do
        numArchivos=0

        while read LINE ; do
                if [ -e $LINE.up ]
                then
                        let numArchivos++
                fi
        done < serversCluster.txt

        if [ $numArchivos -eq $numServersCluster ]
        then
                numEspera=16
        else
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud, han subido $numArchivos horizontales" >> $strFileName
                let numEspera++
                sleep 60
        fi
done

if [ $numEspera -eq 10 ]
then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - No subieron los horizontales, solo subieron $numArchivos servidor(es)" >> $strFileName
        ls -lrt *.up >> $strFileName
        exit 6
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Subiendo Proceso Workflows inicio mesas" >> $strFileName

cd $MUREX_HOME/murex_app/app/mxprocessingscript; ./xmlprocessingscript_xmlreq_startAll.sh; cd - 

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Servicio Murex disponible" >> $strFileName
echo "Servicio Murex disponible"
rm *.up
rm *.start
rm *.down
rm *.stop

exit 0

