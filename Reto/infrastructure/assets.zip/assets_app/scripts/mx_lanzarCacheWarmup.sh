#!/bin/bash -l

#########################################
# mx_lanzarCacheWarmup
# Descripcion                           Lanza los comandos para ejecutar el cache warmupse como parametro
# Parametros                            No tiene
# Fecha de creacion                     2011/10/21
#########################################

strFechaHora=`date +"%Y%m%d-%H%M%S"`
cd $MUREX_HOME$MUREX_APP

set -e
cd eod_scripts;./cache-warmup.sh;cd ..
echo "Cache warmup listo"
