#!/bin/bash
#########################################
# ejecutar.sh            
# Descripcion                           Ejecuta el comando que se le pase como par�metro
# Parametros                            No tiene
# Fecha de creacion                     2011/10/21
#########################################

set -e
$1
echo "Comando ejecutado"
