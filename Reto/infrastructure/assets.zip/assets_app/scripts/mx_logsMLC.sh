#!/bin/bash -l

#########################################
# mx_logsMLC.sh
# Descripcion                           Genera los logs de MLC a archivo
# Fecha de creacion                     2011/02/18
#########################################

strFechaHora=`date +"%Y%m%d-%H%M%S"`
strFileName=MLC.$strFechaHora.tar.gz

echo "Empezando proceso de respaldos..."
cd $MUREX_HOME$MUREX_APP

echo "Copiando logs de MLC para revision de Murex..."
cp logs/pbmdeapmur03.mxmlc.site1.public.mxres.common.launchermxmlc.mxres.log $MUREX_HOME/MLC
cp logs/mxmlc.gc.log $MUREX_HOME/MLC
cp -R logs/mxmlc/mxmlc/ $MUREX_HOME/MLC
cp logs/pbmdeapmur03.lrb.site1.public.mxres.common.launchermxlrb.mxres.log $MUREX_HOME/MLC
cp logs/mxlrb.gc.log $MUREX_HOME/MLC
cp -R logs/mxlrb/mxlrb/ $MUREX_HOME/MLC
cp mlc_histo.log $MUREX_HOME/MLC
tar -cpvf - $MUREX_HOME/MLC/ | gzip -9 -c > $MUREX_HOME/$strFileName
rm -r $MUREX_HOME/MLC/*

