#!/bin/bash 

#########################################
# mx_manejarCore.sh
# Descripcion                           Copia, tar y gzip los archivos core generados durante el dia para 
#					enviarlos a cinta
# Fecha de creacion                     2010/03/17
#########################################

strFecha=`date +"%Y%m%d%H%M"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
strFechaArchivo=`date +"%Y%m%d"`
hostname=`hostname`
strFileName=$MUREX_HOME/proceso/$hostname.$strFechaArchivo.log

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Manejar Core" >> $strFileName

cd $MUREX_HOME$MUREX_APP

if [ -e core ]
then
 	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Respaldando archivo Core..." >> $strFileName
	mv core core.dmp
	mx_backup.sh 'core*' arcCore_$strFecha
#	rm core.*
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Proceso terminado, archivos respaldados en la ruta de backup" >> $strFileName
else
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - No hay archivos core para respaldar" >> $strFileName
fi
