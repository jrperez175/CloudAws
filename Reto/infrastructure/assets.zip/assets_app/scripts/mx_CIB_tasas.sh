#!/bin/bash

##################################################################################################################
# este programa verifica cada 5 minutos que exita el archvo de datas de CIB en case que exista los sube y luego #
# sube el modulo de tasas, siempre deja una copia del archivo durante un dia, ademas recibe como parametro -l   #
# si este es usado el deja un log de todo lo que hizo.                                                          #
# 2012/08/17 se adicionan lineas para bajar el modulo de impuestos                                              #
# 2020 Se elimina el reinicio del módulo para independizarlo en un proceso aparte                               #
#################################################################################################################

cd /murex/scripts

i=0
j=0
h=0
c=$1

log=tasasCIB`date +"%d%m%Y"`.log
./festivo `date +"%d %m %Y"`
Ans=$?

if [ $Ans = 0 ]; then
  while [ $i -ne 1 ]; do
    if [ -f /impyval/conf/CIB_IMV_Tasas.txt ]; then
      cd /impyval/conf
      rm CIB_IMV_Tasas.old
      if [ "$c" = '-l' ]; then
        echo "`date +"%d/%m/%Y %T"` Borrando archivo viejo de tasas CIB" >> $log
      fi
      cp CIB_IMV_Tasas.txt CIB_IMV_Tasas.old
      if [ "$c" = '-l' ]; then
        echo "`date +"%d/%m/%Y %T"` Copio archivo nuevo a viejo" >> $log
      fi
      cd /impyval/lib/
      ./base-rates-cib.sh
      if [ "$c" = '-l' ]; then
        echo "`date +"%d/%m/%Y %T"` Subio archivo de tasas" >> $log
      fi
      i=1
      if [ -f /impyval/conf/CIB_IMV_Tasas.txt ]; then
        cd /impyval/conf/
        rm CIB_IMV_Tasas.txt
        if [ "$c" = '-l' ]; then
          echo "`date +"%d/%m/%Y %T"` Borro el archivo de tasas" >> $log
        fi
      fi
     h=1
    fi
    if [ $i -ne 1 ]; then
      sleep 60
      j=`date +%H%M`
      if [ $j -gt 0745 ]; then
        i=1
        cd /impyval/lib/
        ./base-rates-cib.sh
      fi
    fi
  done
  if [ $h -ne 1 ]; then
    dia=`date +%a`
    if [ $dia = "sat" -o $dia = "sun" ]; then
      exit 0
#    else
#      if [ $c = '-l' ]; then
#        echo "`date +"%d/%m/%Y %T"` Termina programa porque no se encontro archivo de tasas" >> $log
#      fi
#      exit 1
    fi
  fi 
  if [ "$c" = '-l' ]; then
    echo "`date +"%d/%m/%Y %T"` Termina el programa en forma normal" >> $log
  fi
else
  echo "`date +"%d/%m/%Y %T"` Dia Festivo no se ejecuta programa" >> $log
fi