#!/bin/bash

#########################################
# mx_licencias.sh
# Descripcion                           Realiza la actualizacion de licencias de los servicios en el directorio
#					[appDir]fs/license
#					Las licencias se copian a ese directorio y se actualizan
# Parametros                            $1 Ruta del servidor donde esta el archivo de las licencias
# Fecha de creacion                     2009/10/26
#########################################

strDirectorio=$MUREX_HOME$MUREX_APP/fs/license

echo "Copiando archivo de licencias a directorio $strDirectorio"
cp $1 $strDirectorio

cd $MUREX_HOME$MUREX_APP

echo "Parando los servicios..."
mx3_launchall.sh stop

echo "Actualizando las licencias"
cd $strDirectorio
jar xvf $1
cd $MUREX_HOME$MUREX_APP

echo "Subiendo los servicios..."
./mx3_launchall.sh start

echo "Proceso de actualizaci�n terminado."
