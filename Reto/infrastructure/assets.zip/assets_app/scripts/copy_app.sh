#!/bin/bash

#Realiza la copia del app de produccion
strFecha=`date +"%Y%m%d"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
echo "Hora de inicio:" $strFechaHora > /murex/scripts/log_copy.log

#Elimina la copia del app anterior
rm -rf /murex/murex_app/rest/app_dir/appProd*.tar.gz

# Comprime el app
cd /murex/murex_app/
tar -zcf /murex/murex_app/appProd$strFecha.tar.gz --exclude=\*.{log,tar,txt,TXT} --exclude='/murex/murex_app/app/log*.xml' --exclude='mxdoc_fs' --exclude='/murex/murex_app/app/*.tar.gz' --exclude='/murex/murex_app/app/core.*' --exclude='/murex/murex_app/app/tmp_mra/mr_engine_all' --exclude='/murex/murex_app/app/tmp_mra/mrb_run_0' --exclude='/murex/murex_app/app/hs_err_*.log' --exclude='/murex/murex_app/app/4*.jar' --exclude='/murex/murex_app/arch_conversion' --exclude='/murex/murex_app/temporal' --exclude='/murex/murex_app/modulos_bck' --exclude='/murex/murex_app/Reportes_audit' --exclude='/murex/murex_app/logs_back' --exclude='/murex/murex_app/Controles_sox' --exclude='/murex/murex_app/rest' --exclude='/murex/murex_app/appP*.tar.gz' --exclude='/murex/murex_app/.mxdoc_fs.tar.8oeeSH'  --exclude='/murex/murex_app/app/logs' /murex/murex_app/

sleep 2
mv /murex/murex_app/appProd$strFecha.tar.gz /murex/murex_app/rest/app_dir/

echo "Copia del app finalizada" >> /murex/scripts/log_copy.log

strFecha=`date +"%Y%m%d"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
echo "Hora de finalizacion:" $strFechaHora >> /murex/scripts/log_copy.log
echo "paso 1: Copia produccion realizada OK" >> /murex/scripts/log_copy.log
