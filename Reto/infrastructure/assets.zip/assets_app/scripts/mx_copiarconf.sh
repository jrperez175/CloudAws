#!/bin/bash

#respalda los archivos de configuracion en el directorio backup


cd /murex/backup
mkdir conf
cd conf
mkdir mlc


cp /murex/murex_app/app/mxg2000_settings.sh /murex/backup/conf/ 
cp /murex/murex_app/app/fs/public/mxres/sites/sites.mxres /murex/backup/conf/ 
cp /murex/murex_app/app/fs/public/mxres/common/dbconfig/murexnet.mxres /murex/backup/conf/ 
cp /murex/murex_app/app/fs/public/mxres/common/dbconfig/dbsource.mxres /murex/backup/conf/ 
cp /murex/murex_app/app/fs/public/mxres/common/dbconfig/dbsourceoracle.mxres /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/common/dbconfig/dbsource_rep.mxres /murex/backup/conf/  
cp /murex/murex_app/app/fs/public/mxres/mxmlc/dbconfig/dbsource_mlc.mxres /murex/backup/conf/  
cp /murex/murex_app/app/fs/public/mxres/mxmlc/dbconfig/dbsource.mxres /murex/backup/conf/mlc/ 
cp /murex/murex_app/app/fs/public/mxres/mxmlc/mlc.mxres /murex/backup/conf/  

cp /murex/murex_app/app/fs/public/mxres/script/middleware/broadcastmessage1.mxres /murex/backup/conf/   
cp /murex/murex_app/app/fs/public/mxres/script/middleware/broadcastmessage2.mxres /murex/backup/conf/   
cp /murex/murex_app/app/fs/public/mxres/script/middleware/broadcastmessage3.mxres /murex/backup/conf/   
cp /murex/murex_app/app/fs/public/mxres/script/middleware/broadcastmessage4.mxres /murex/backup/conf/  
cp /murex/murex_app/app/fs/public/mxres/script/middleware/broadcastmessage5.mxres /murex/backup/conf/  

cp /murex/murex_app/app/fs/public/mxres/common/launcherall.mxres /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/common/launcherhss.mxres /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/common/launchergc.mxres /murex/backup/conf/  
cp /murex/murex_app/app/mlc/launchmlc.sh /murex/backup/conf/  
cp /murex/murex_app/app/mxprocessingscript/xmlrequestscript.sh /murex/backup/conf/  
cp /murex/murex_app/app/mxprocessingscript/ps-xmlrequestscript.sh /murex/backup/conf/  


#Archivos de claves

cp /murex/murex_app/app/fs/public/mxres/common/dbconfig/mxservercredential.mxres /murex/backup/conf/
cp /murex/murex_app/app/mlc/mlc_eod/eod_reset.xml /murex/backup/conf/
cp /murex/murex_app/app/mlc/mlc_eod/intraday_reset.xml /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/mxmlc/scripts/cptReporte4.xml /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/mxmlc/scripts/tradersReportes.xml /murex/backup/conf/
#cp /murex/murex_app/app/fs/public/mxres/mxmlc/mlc.mxres /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/mxsoaprelay/start_mxsoapregistry.mxres /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/mxsoaprelay/stop_mxsoapregistry.mxres /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/mxentitlement/startstopentitlements.mxres /murex/backup/conf/

#Archivos de colas MQ

cp -r /murex/murex_app/app/fs/mqconfig /murex/backup/conf

#Chequeo de sesiones
cp /murex/murex_app/app/fs/public/mxres/script/middleware/sessioncheck.mxres /murex/backup/conf/

#Archivos de configuracion Bloomberg
cp /murex/murex_app/app/fs/public/mxres/mxinterfaces/bloomberg/bloomberg-properties.mxres /murex/backup/conf/
cp /murex/murex_app/app/fs/public/mxres/mxinterfaces/bloomberg/rtbsbbg.properties /murex/backup/conf/
