#!/bin/bash
strFecha=`date +"%Y%m%d"`
ruta=/murex/murex_app/Controles_sox
destino1="OJRODRIG@bancolombia.com.co"
destino2="edwpalac@bancolombia.com.co"
destino3="MAMGARCI@BANCOLOMBIA.COM.CO"
destino5="solivare@bancolombia.com.co"
destino6="DIEAGUIR@bancolombia.com.co"
destino7="mararcil@bancolombia.com.co"

asunto1="Controles_SOX Modulo mfc" $mes
asunto2="Controles_SOX Modulo VALUATION-MODULE" $mes
asunto3="Controles_SOX Modulo VALMODULE-BSMO" $mes
 
VAR=$(date +%m)
case $VAR in
01)
mes="Enero";;
02)
mes="Febrero";;
03)
mes="Marzo";;
04) 
mes="Abril";;
05)
mes="Mayo";;
06)
mes="Junio";;
07)
mes="Julio";;
08)
mes="Agosto";;
09)
mes="Septiembre";;
10)
mes="Octubre";;
11)
mes="Noviembre";;
12)
mes="Diciembre";;
esac
 
body_mail_0="Informacion generada para el periodo: "$mes
body_mail=". Adjunto envío controles SOX sobre los módulos externos de murex. Esta información fue generada y enviada automaticamente desde Urbancode. Cualquier inquietud por favor comunicarse con Sergio Enrique Olivares solivare@bancolombia.com.co o con Diego Alejandro Aguirre dieguir@bancolombia.com.co"
 
echo $body_mail_0 $body_mail | mail -a $ruta/mfc-module$strFecha.txt -s $asunto1 $destino1 $destino2 $destino3 $destino5 $destino6 $destino7
sleep 5
echo $body_mail_0 $body_mail | mail -a $ruta/VALUATION-MODULE$strFecha.txt -s $asunto2 $destino1 $destino2 $destino3 $destino5 $destino6 $destino7
sleep 5
echo $body_mail_0 $body_mail | mail -a $ruta/VALMODULE-BSMO$strFecha.txt -s $asunto3 $destino1 $destino2 $destino3 $destino5 $destino6 $destino7
