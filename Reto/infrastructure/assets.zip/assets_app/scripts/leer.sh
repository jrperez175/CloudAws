#!/bin/bash

numLineas=`wc -l < servers.txt`
echo $numLineas
while read LINE ; do
	touch $LINE.stop
done < servers.txt
