#include <stdio.h>
#include <stdlib.h>


/* este programa resive como parametro una fecha y debuelve como resultado un codigo de terminacion, si el codigo es 0 es porque la fecha
   corresponde a un dia habil y si el codigo es 1 es porque la fecha corresponde a un fin de semana o un dia festivo.   */

float juliana(int an, int me, int di)

/* Esta funcion convierte una fecha en calendario Gregoriano en fecha de dia Juliano  */

  {
    int A, B, C, E, F;

    if (me == 1 || me == 2)
      {
        an = an - 1;
        me = me + 12;
      }
    A = an / 100;
    B = A / 4;
    C = 2 - A + B;
    E = 365.25 * (an + 4716);
    F = 30.6001 * (me + 1);
    return C + di + E + F - 1524.5;
  }

int gregoriana(long jd, int tipo)
  {
   /* esta funcion combierte una dia juliano al calendario gregoriano de pendiendo del
      parametro tipo el duvuelve el dia el mes o el año asi:
      si tipo = 1 la funcion devuelve el dia
      si tipo = 2 la funcion devuelve el mes
      si tipo = 3 la funcion devuelve el año   */

    int Z, W, X, A, B, C, D, E, F, DM, M, Y, tem;

    Z = jd + 0.5;
    W = (Z - 1867216.25) / 36524.25;
    X = W / 4;
    A = Z + 1 + W - X;
    B = A + 1524;
    C = (B - 122.1) / 365.25;
    D = 365.25 * C;
    E = (B - D) / 30.6001;
    F = 30.6001 * E;
    DM = B - D - F;
    if (E <= 12)
      M = E - 1;
    else
      M = E - 13;
    if (M == 1 || M == 2)
      Y = C - 4715;
    else
      Y = C - 4716;
    switch(tipo)
      {
        case 2:
          tem = M;
          break;
        case 1:
          tem = DM;
          break;
        case 3:
          tem = Y;
      }
    return tem;
  }

int diasem(int di, int me, int an)
  {
   /* esta funcion recive el dia el mes y el año de una fecha y retorna el dia de la semana asi:
      1:Lunes
      2:Martes
      3:Miercoles
      4:Jueves
      5:Viernes
      6:Sabado
      0:Domingo
      Aplicando la formula N=D+M+A+E[A/4]+S
   */
    int D, M, A, E, S, N;

    D = di;
    if (me == 1 || me == 10)
      M = 0;
    if (me == 5)
      M = 1;
    if (me == 8)
      M = 2;
    if (me == 2 || me == 3 || me == 11)
      M = 3;
    if (me == 6)
      M = 4;
    if (me == 9 || me == 12)
      M = 5;
    if (me == 4 || me == 7)
      M = 6;
    if (an >= 1900 && an <= 1999)
      {
        A = an - 1900;
        S = 0;
      }
    if (an >= 2000 && an <= 2999)
      {
        A = an - 2000;
        S = 6;
      }
    E = A / 4;
    N = D + M + A + E + S;
    return N % 7;
  }

char *dialetra(int dia, int mes, int ano)

/* esta funcion devulve el dia de la semana dado una fecha, se bbase en la funcion diasem  */

  {
    int dian;
    char *dial;
    
    dian = diasem(dia,mes,ano);
    switch(dian)
      {
        case 0:
          dial = "Domingo";
          break;
        case 1:
          dial = "Lunes";
          break;
        case 2:
          dial = "Martes";
          break;
        case 3:
          dial = "Miercoles";
          break;
        case 4:
          dial = "Jueves";
          break;
        case 5:
          dial = "Viernes";
          break;
        case 6:
          dial = "Sabado";
          break;
      }
  return dial;
  }


main(int argc, char* argv[])
{
  int M, N, A, B, C, D, E, ano, mes, dia, i, dia1, mes1;
  float j;

if (argc < 4)
  {
    printf("Uso: esfestivo dia mes año\n");
    return 1;
  }


  M = 0;
  N = 0;
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  ano = 0;
  mes = 0;
  dia = 0;

    M=24;
    N=5;

    dia1 = atoi(argv[1]);
    mes1 = atoi(argv[2]);
    ano = atoi(argv[3]);
    
    mes = 4;
    dia = 14;
  
    if (ano >= 1583 && ano <= 1699) 
      {
        M=22;
        N=2;
      }
    else
      {
        if (ano >= 1700 && ano <= 1799) 
          {
            M=23;
            N=3;
          }
         else
           {
             if (ano >= 1800 && ano <= 1899) 
               {
                M=23;
                N=4; 
               }
             else
               {
                  if (ano >= 1900 && ano <= 2099) 
                    {
                      M=24;
                      N=5; 
                    }
                  else
                    {
                      if (ano >= 2100 && ano <= 2199) 
                        {
                          M=24;
                          N=6;
                        }
                      else
                        {
                          if (ano >= 2200 && ano <= 2299) 
                            {
                              M=25;
                              N=0;
                            }
                        }
                    }
               }
           }
      }
    A = ano % 19;
    B = ano % 4;
    C = ano % 7;
    D = (19 * A + M) % 30;
    E = (2 * B + 4 * C + 6 * D + N) % 7;

    if ((D + E) < 10) 
      {
        dia = D + E + 22;
        mes = 3;
      }
    else
      {
        dia = D + E - 9;
        mes = 4;
      }
    if (dia == 26 && mes == 4)
      {
        dia = 19;
      }
    if (dia == 25 && mes == 4 && D == 28 && E == 6 && A > 10) 
      {
        dia = 18;
      } 

  if (diasem(dia1,mes1,ano) == 0)
    {
      return 1;
    }
  else
    {
      if (diasem(dia1,mes1,ano) == 6)
        {
          return 1;
        }
    }
  

  if (dia1 == 1 && mes1 == 1)
      {
        return 1;
      }
      if (mes1 == 1)
        {
          i = diasem(6,1,ano);
          if (i == 1 && dia1 == 6)
            {
              return 1;
            }
          else
            {
              if (i == 0)
                i = 7;
              i = 8 - i;
              j = juliana(ano, 1, 6) + i + 1;
              if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2) == mes1)
                {
                  return 1;
                }
            }
        }
      if (mes1 == 3)
        {
          i = diasem(19,3,ano);
          if (i == 1 && dia1 == 19)
            {
              return 1;
            }
          else
            {
              if (i == 0)
                i = 7;
              i = 8 - i;
              j = juliana(ano, 3, 19) + i + 1;
              if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2))
                {
                  return 1;
                }
            }
        }
      if (mes1 == mes)
        {
          j = juliana(ano, mes, dia) - 2;
          if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2))
            {
              return 1;
            }
          j = juliana(ano, mes, dia) - 1;
          if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2))
            {
              return 1;
            }
        }
      if (dia1 == 1 && mes1 == 5)
        {
          return 1;
        }
      j = juliana(ano, mes, dia) + 39;
      i = diasem(gregoriana(j,1), gregoriana(j,2), ano);
      if (i == 1)
        if (gregoriana(j,1) == dia1 && gregoriana(j,2) == mes1)
          {
            return 1;
          }
        else
            printf("");
      else
        {
          if (i == 0)
            i = 7;
          i = 8 - i;
          j = j + i;
          if (gregoriana(j,1) == dia1 && gregoriana(j,2)== mes1)
            {
              return 1;
            }
        }
      j = juliana(ano, mes, dia) + 60;
      i = diasem(gregoriana(j,1), gregoriana(j,2), ano);
      if (i == 1)
        if (gregoriana(j,1) == dia1 && gregoriana(j,2) == mes1)
          {
            return 1;
          }
        else
          printf("");
      else
        {
          if (i == 0)
            i = 7;
          i = 8 - i;
          j = j + i;
          if (gregoriana(j,1) == dia1 && gregoriana(j,2) == mes1)
            {
              return 1;
            }
        }
      j = juliana(ano, mes, dia) + 68;
      i = diasem(gregoriana(j,1), gregoriana(j,2), ano);
      if (i == 1)
        if (gregoriana(j,1) == dia1 && gregoriana(j,2) == mes1)
          {
            return 1;
          }
        else
          printf("");
      else
            {
              if (i == 0)
                i = 7;
              i = 8 - i;
              j = j + i;
              if (gregoriana(j,1) == dia1 && gregoriana(j,2) == mes1)
                {
                  return 1;
                }
            }
          if (mes1 == 6 || mes1 == 7)
            {
              i = diasem(29,6,ano);
              if (i == 1 && dia1 == 29)
                {
                  return 1;
                }
              else
                {
                  if (i == 0)
                    i = 7;
                  i = 8 - i;
                  j = juliana(ano, 6, 29) + i + 1;
                  if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2))
                    {
                      return 1;
                    }
                }
            }
          if (dia1 == 20 && mes1 == 7)
            {
              return 1;
            }
          if (dia1 == 7 && mes1 == 8)
            {
              return 1;
            }
          if (mes1 == 8)
            {
              i = diasem(15,8,ano);
              if (i == 1 && dia1 == 15)
                {
                  return 1;
                 }
              else
                {
                  if (i == 0)
                    i = 7;
                  i = 8 - i;
                  j = juliana(ano, 8, 15) + i + 1;
                  if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2))
                    {
                      return 1;
                     }
                }
            }
          if (mes1 == 10)
            {
              i = diasem(12,10,ano);
              if (i == 1 && dia1 == 12)
                {
                   return 1;
                 }
              else
                {
                  if (i == 0)
                    i = 7;
                  i = 8 - i;
                  j = juliana(ano, 10, 12) + i + 1;
                  if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2))
                    {
                      return 1;
                     }
                }
            }
          if (mes1 == 11)
            {
              i = diasem(1,11,ano);
              if (i == 1 && dia1 == 1)
                {
                  return 1;
                 }
              else
                {
                  if (i == 0)
                    i = 7;
                  i = 8 - i;
                  j = juliana(ano, 11, 1) + i + 1;
                  if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2))
                    {
                       return 1;
                     }
                }
              i = diasem(11,11,ano);
              if (i == 1 && dia1 == 11)
                {
                  return 1;
                 }
              else
                {
                  if (i == 0)
                    i = 7;
                  i = 8 - i;
                  j = juliana(ano, 11, 11) + i + 1;
                  if (dia1 == gregoriana(j,1) && mes1 == gregoriana(j,2))
                    {
                      return 1;
                    }
                }
            }
          if (mes1 == 12)
            {
              if (dia1 == 8)
                {
                  return 1;
                 }
              else
                {
                  printf("");
                }
              if (dia1 == 25)
                {
                  return 1;
                 }
              else
                {
                    printf("");
                }
            }
  return 0;
}

