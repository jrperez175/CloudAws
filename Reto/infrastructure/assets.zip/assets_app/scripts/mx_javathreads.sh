#!/bin/ksh

MLCPID=$( cat logs/`uname -n`.mxmlc.site1.public.mxres.common.launchermxmlc.mxres.pid )
DELAY=19
while (( 1 == 1 )) ; do
        DATE=$( date '+%Y-%m-%d--%H:%M:%S' )
        echo "MLC PID TRACE: $DATE" >> ./bin/mlc.log
        sleep 1
        kill -3 $MLCPID
        sleep $DELAY
done

