#!/bin/bash

#Realiza el backup de los modulos externos antes de la restauracion
strFechaHora=`date +"%Y%m%d-%H%M%S"`
strFecha=`date +"%Y%m%d"`
echo "Hora de inicio:" 
date > /murex/scripts/log_rest_modules.log
############################
#Elimina los archivos anteriores
cd /murex/murex_app/rest/modules
rm -rf *.tar.gz 
sleep 2

cd /
tar -cvf - impyval | gzip -9 -c > /murex/murex_app/rest/modules/impyval_$strFecha.tar.gz
echo "paso 1: Backup Modulo impyval realizada OK" >> /murex/scripts/log_rest_modules.log

tar -cvf - mfc-module | gzip -9 -c > /murex/murex_app/rest/modules/mfc_module_$strFecha.tar.gz
echo "paso 1: Backup mfc_module realizada OK" >> /murex/scripts/log_rest_modules.log

tar -cvf - VALUATION-MODULE | gzip -9 -c > /murex/murex_app/rest/modules/VALUATION-MODULE_$strFecha.tar.gz
echo "paso 1: Backup VALUATION-MODULE  realizada OK" >> /murex/scripts/log_rest_modules.log

tar -cvf - VALMODULE-BSMO | gzip -9 -c > /murex/murex_app/rest/modules/VALMODULE-BSMO_$strFecha.tar.gz
echo "paso 1: Backup VALMODULE-BSMO realizada OK" >> /murex/scripts/log_rest_modules.log

echo "Hora de finalizacion:" 
echo $strFechaHora 
date >> /murex/scripts/log_rest_modules.log
