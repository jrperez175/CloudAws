#!/bin/sh

parametro1="\$1"
parametro2="\$9"

while read line
do
  netstat -Aan | grep ${line} | grep LISTEN | awk {"print $parametro1"} > socket.txt

  echo "**********************************************************************"
  echo "Informacion para puerto tcp ${line}"
  echo
  while read line
  do
    echo "Proceso asociado: ${line}"
    socket=`rmsock ${line} tcpcb | awk {"print $parametro2"}`
    ps -eaf | grep $socket
    echo
  done < socket.txt
  rm socket.txt
done < lista.txt

