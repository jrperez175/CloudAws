#!/bin/bash -l

#########################################
# mx_reiniciar.sh
# Descripcion                           Baja los horizontales, reinicia el 03 y luego vuelve a subir los horizontales
# Fecha de creacion                     2009/10/26
# Fecha modificacion                    2013/02/20
# Descripcion modificacion              Se a�ade el manejo de matar las horizontales en caso de pasar 10 minutos sin responder
#########################################

declare -i numArchivos
declare -i numEspera

cd $MUREX_HOME/proceso
strFecha=`date +"%Y%m%d"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
hostname=`hostname`
strFileName=$hostname.$strFecha.log
strLock=$hostname.mx_cierre.lock

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Reinicio de ambiente" >> $strFileName

if [ ! -f $MUREX_HOME/proceso/serversCluster.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCluster.txt no existe" >> $strFileName
        exit 1
elif [ ! -r $MUREX_HOME/proceso/serversCluster.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCluster.txt no se puede leer" >> $strFileName
        exit 2
fi

if [ ! -f $MUREX_HOME/proceso/serversCierre.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCierre.txt no existe" >> $strFileName
        exit 3
elif [ ! -r $MUREX_HOME/proceso/serversCierre.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCierre.txt no se puede leer" >> $strFileName
        exit 4
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando parar Murex en las horizontales" >> $strFileName

if [ -e $strLock ]
then
        numServers=`wc -l < serversCierre.txt`
	while read LINE ; do
        	touch $LINE.stop
        	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Esperando parada del $LINE para reiniciar..." >> $strFileName
	done < serversCierre.txt
else
	numServers=`wc -l < serversCluster.txt`
	while read LINE ; do
        	touch $LINE.stop
        	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando parar Murex en la $LINE para reiniciar..." >> $strFileName
	done < serversCluster.txt
fi

numEspera=0

while [ $numEspera -lt 10 ]
do
        numArchivos=0

	if [ -e $strLock ]
	then
	        while read LINE ; do
        	        if [ -e $LINE.down ]
                	then
                        	let numArchivos++
	                fi
        	done < serversCierre.txt
        else
		while read LINE ; do
                	if [ -e $LINE.down ]
                	then
                        	let numArchivos++
                	fi
        	done < serversCluster.txt
	fi

        if [ $numArchivos -eq $numServers ]
        then
                numEspera=11
        else
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud, han parado $numArchivos horizontales" >> $strFileName
                let numEspera++
                sleep 60
        fi
done

if [ $numEspera -eq 10 ]
then
        while read LINE ; do
                touch $LINE.kill
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando MATAR Murex en la $LINE" >> $strFileName
        done < serversCluster.txt

        numEspera=0
        while [ $numEspera -lt 3 ]
        do
                numArchivos=0

                while read LINE ; do
                        if [ -e $LINE.kill ]
                        then
                                let numArchivos++
                        fi
                done < serversCluster.txt

                if [ $numArchivos -eq 0 ]
                then
                        numEspera=4
                else
                        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud de matar, no han parado $numArchivos horizontal
es" >> $strFileName
                        let numEspera++
                        sleep 60
                fi
        done
        if [ $numEspera -eq 3 ]
        then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - No bajo el sistema en las horizontales - Solo bajaron $numArchivos servidores" >> $strFileName
                ls -lrt *.down >> $strFileName
                exit 3

        fi
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Reiniciando el Middleware Server" >> $strFileName
mx_lanzarMxPdn.sh restart pbmdeapmur03

if [ -e $strLock ]
then
	while read LINE ; do
        	touch $LINE.start
        	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando subir Murex en la $LINE" >> $strFileName
	done < serversCierre.txt
else
	while read LINE ; do
        	touch $LINE.start
        	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando subir Murex en la $LINE" >> $strFileName
	done < serversCluster.txt
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Esperando que suban los horizontales..." >> $strFileName
numEspera=0
while [ $numEspera -lt 10 ]
do
        numArchivos=0

        if [ -e $strLock ]
        then
                while read LINE ; do
                        if [ -e $LINE.up ]
                        then
                                let numArchivos++
                        fi
                done < serversCierre.txt
        else
                while read LINE ; do
                        if [ -e $LINE.up ]
                        then
                                let numArchivos++
                        fi
                done < serversCluster.txt
        fi

        if [ $numArchivos -eq $numServers ]
        then
                numEspera=11
        else
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud, han arrancado $numArchivos horizontales" >> $strFileName
                let numEspera++
                sleep 60
        fi
done
if [ $numEspera -eq 10 ]
then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - No subieron los horizontales, solo subieron $numArchivos servidor(es)" >> $strFileName
        ls -lrt *.up >> $strFileName
        exit 6
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Subiendo Proceso de WorkFlows para inicio el Lunes" >> $strFileName

cd $MUREX_HOME/murex_app/app/mxprocessingscript; ./xmlprocessingscript_xmlreq_startAll.sh; cd -

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Servicio Murex disponible" >> $strFileName
rm *.up
rm *.start
rm *.down
rm *.stop

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Reinicio de servicio completo" >> $strFileName
exit 0

