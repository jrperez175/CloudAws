#!/bin/bash

#########################################
# mx_menu_mls.sh
# Descripcion                           Menu para el cierre  manual de MLC.
# Fecha de creacion                     2010/03/02
#########################################

opcion=10

while [ $opcion -ne 0 ]; do
  clear
  echo
  echo
  echo
  echo
  echo
  echo
  echo "                                   1. Cierre Manual de MLC"
  echo
  echo "                                   0. Terminar"
  echo
  echo Digite su opcion 
  read opcion
  case $opcion in
    0) clear;;
    1) if [ `hostname` = "pbmdeapmur03" ]; then
         cd /murex/murex_app/app/mlc/mlc_eod/
         ./mlc_eod.sh
         if [ $? -ne 0 ]; then
           echo 
           echo
           echo "El cierre no termino bien"
           echo
           echo "Presione ENTER para continuar"
           read
           exit 1
         fi
       else
         echo "Este proceso se debe correr en la maquina pbmdeapmur03"
         read 
       fi 
       ;;
    *) echo "Teclee 0 o 1"
       echo
       echo "Presione ENTER para continuar"
       read;;
  esac
done 

