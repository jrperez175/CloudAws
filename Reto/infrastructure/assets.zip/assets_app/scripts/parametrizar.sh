#!/bin/bash -l

#Cambia la configuraci�n de los archivos de producci�n a los parametros de desarrollo


#############################REMPLAZA LOS ARCHIVOS DE CONFIGURACION

cd /murex/murex_app/app

echo -e "\n\nSe remplaz� $1 por $2 en los siguientes archivos:\n" >> /murexLocal/scripts/mx_appRestore.log
grep -lr "$1" *  >> /murexLocal/scripts/mx_appRestore.log

grep -lr "$1" * | while read file;
        do
           sed "s/$1/$2/g" "$file" > "$file".tmp
           mv "$file".tmp "$file"
           chmod 775 "$file"
        done;
