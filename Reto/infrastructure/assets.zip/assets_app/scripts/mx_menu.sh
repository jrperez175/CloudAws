#!/bin/bash

#########################################
# mx_menu.sh
# Descripcion                           Menu para pantallas de monitoreo, operacion, etc.
# Fecha de creacion                     2009/10/26
#########################################

opcion=10

while [ $opcion -ne 0 ]; do
  clear
  echo
  echo
  echo
  echo
  echo
  echo
  echo "                                   1. Iniciar Murex"
  echo
  echo "                                   2. Parar Murex"
  echo
  echo "                                   3. Reiniciar Murex"
  echo
  echo "                                   4. Subir tasas CIB"
  echo
  echo "                                   5. Subir tasas SetFx"
  echo
  echo "                                   6. Verificar que Murex este arriba"
  echo
  echo "                                   7. Reiniciar MLC"
  echo
  echo "                                   8. Reiniciar modulo impuestos"
  echo
  echo "                                   0. Terminar"
  echo
  echo Digite su opcion 
  read opcion
  case $opcion in
    0) clear;;
    1) clear
       op1="n"
       echo "Esta seguro de iniciar Murex (S/N)?"
       read op1
       if [ $op1 = "S" ]; then
         case `hostname` in
           pbmdeapmur03) 
             mx_subirPdn.sh;; 
           *) 
              echo "Debe estar en la maquina pbmdeapmur03 para ejecutar este comando"
              read;;
         esac
       fi;;
    2) clear
       op1="n"
       echo "Esta seguro de parar Murex (S/N)?"
       read op1
       if [ $op1 = "S" ]; then
          case `hostname` in
           pbmdeapmur03)
             mx_bajarPdn.sh
           *)
             echo "Debe estar en la maquina pbmdeapmur03 para ejecutar este comando"
              read;;
         esac

       fi;;
    3) case `hostname` in
         pbmdeapmur03)
                  op1="n"
                  clear
                  echo
                  echo
                  echo "Esta seguro que desea reiniciar Murex (S/N)?"
                  read op1
                  if [ $op1 = "S" ]; then
                    mx_reiniciar.sh
                  fi ;;
         *) clear
            echo
            echo
            echo
            echo "Debe estar en el pbmdeapmur03 para hacer esta tarea"
            echo
            echo "Presione Enter para continuar"
            read;;
       esac
       ;;
    4) case `hostname` in
           pbmdeapmur03)
              /murex/scripts/mx_CIB_tasas.sh ;;
           *)
              echo "Debe estar en el pbmdeapmur03 para hacer esta tarea"
              echo
              echo "Presione Enter para continuar"   
              read;;
       esac
       ;;
    5) case `hostname` in
           pbmdeapmur03)
              /murex/scripts/mx_setfx_tasas.sh ;;
           *)
              echo "Debe estar en el pbmdeapmur03 para hacer esta tarea"
              echo
              echo "Presione Enter para continuar"
              read;;
       esac
       ;;
    6) cd /murex/murex_app/app
       ./launchmxj.app -s
       echo
       echo "Presione ENTER para continuar"
       read;;
    7) case `hostname` in
           pbmdeapmur03)
              op1="n"
              clear
              echo 
              echo
              echo
              echo "Esta seguro de reniciar el modulo de MLC (S/N)?"
              read op1
              if [ $op1 -eq "S" ]; then
                MLCrestart.sh
                echo "Recuerde pedir que se reinicie el flujo del Distribution, ya que esta relacionado con MLC"
              fi ;;
           *)
              echo "Debe estar en el pbmdeapmur03 para hacer esta tarea"
              echo
              echo "Presione ENTER para continuar"
              read ;;
       esac
       ;;
    8) echo
       echo
       echo "Esta seguro de Reiniciar el Modulo de Impuestos (S/N)?"
       op1="n"
       read op1
       if [ $op1 -eq ]; then
         case `hostname` in
           pbmdeapmur03)
             cd /impyval/bin
             ./stop-tax-module.sh
              sleep 10
             ./start-tax-module.sh;;
           *) ssh pbmdeapmur03 /mpyval/bin/stop-tax-module.sh
              ssh pbmdeapmur03 /mpyval/bin/start-tax-module.sh;;
         esac
       fi
       ;;
    *) echo "Teclee un numero del 0 al 6"
       echo
       echo "Presione ENTER para continuar"
       read;;
  esac
done 

