#!/bin/bash -l

#########################################
# mx_preIniSube.sh
# Descripcion                           Comandos de precondicion a ejecutar antes del sube de las maquinas
#					que van a ejecutar el cierre
# Fecha de creacion                     2010/01/06
#########################################

cd $MUREX_HOME$MUREX_APP
hostname=`hostname`
strFecha=`date +"%Y%m%d"`
strFileName=$MUREX_HOME/proceso/$hostname.$strFecha.log

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Inicio precondiciones sube" >> $strFileName

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Archivos a mover - launcherall.mxres" >> $strFileName
#ls -lrt fs/public/mxres/common/launcherall.mxres >> $strFileName

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Archivos a mover - launcherhss.mxres" >> $strFileName
#ls -lrt fs/public/mxres/common/launcherhss.mxres >> $strFileName

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Mover a la ruta de respaldo los archivos" >> $strFileName
#mv fs/public/mxres/common/launcherall.mxres $MUREX_HOME/logs/normal/
#mv fs/public/mxres/common/launcherhss.mxres $MUREX_HOME/logs/normal/

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Verificacion archivos respaldados" >> $strFileName
#ls -lrt $MUREX_HOME/logs/normal/ >> $strFileName

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Moviendo los archivos que habilitan el log" >> $strFileName
#cp $MUREX_HOME/logs/activar/* fs/public/mxres/common/

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Verificacion archivos movidos" >> $strFileName
#ls -lrt $MUREX_HOME/logs/normal/ >> $strFileName

#ls -lrt fs/public/mxres/common/launcherall.mxres >> $strFileName

#ls -lrt fs/public/mxres/common/launcherhss.mxres >> $strFileName

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Sacando copia del appdir" >> $strFileName
#cd ..
#tar -cvpf - app/ | gzip -9 -c > appProd20140314.tar.gz

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Fin precondiciones sube" >> $strFileName
