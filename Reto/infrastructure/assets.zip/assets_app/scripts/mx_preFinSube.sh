#!/bin/bash -l

#########################################
# mx_preFinSube.sh
# Descripcion                           Comandos de precondicion a ejecutar antes del sube de las maquinas
#					luego que termina el cierre
# Fecha de creacion                     2010/12/13
#########################################

cd $MUREX_HOME$MUREX_APP
hostname=`hostname`
strFecha=`date +"%Y%m%d"`
strFileName=$MUREX_HOME/proceso/$hostname.$strFecha.log

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Inicio precondiciones sube" >> $strFileName

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Archivos a mover - launcherall.mxres" >> $strFileName
#ls -lrt fs/public/mxres/common/launcherall.mxres >> $strFileName

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Archivos a mover - launcherhss.mxres" >> $strFileName
#ls -lrt fs/public/mxres/common/launcherhss.mxres >> $strFileName

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Mover a la ruta de respaldo los archivos" >> $strFileName
#mv $MUREX_HOME/logs/normal/launcherall.mxres fs/public/mxres/common/
#mv $MUREX_HOME/logs/normal/launcherhss.mxres fs/public/mxres/common/

#echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Verificacion archivos movidos" >> $strFileName
#ls -lrt $MUREX_HOME/logs/normal/ >> $strFileName

#ls -lrt $MUREX_HOME/logs/activar/ >> $strFileName

#ls -lrt fs/public/mxres/common/launcherall.mxres >> $strFileName

#ls -lrt fs/public/mxres/common/launcherhss.mxres >> $strFileName

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Fin precondiciones sube" >> $strFileName
