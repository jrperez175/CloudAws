#!/bin/bash -l

#Elimina archivos de los modulos que tengan mas de 30 dias
#Elimina archivos de la carpeta Acc_Sql_Log que tenga mas de 2 meses

mt=30
mtinf=15
mtAcc=60

echo "Se borraron los siguientes archivos de de los modulos:" > /murex/proceso/mx_depurarModulos.log


echo -e  "\n\nVALORACION INFOVAL:" >> /murex/proceso/mx_depurarModulos.log
find /VALUATION-MODULE/INFOVAL  -mtime +$mtinf >> /murex/proceso/mx_depurarModulos.log
find /VALUATION-MODULE/INFOVAL  -mtime +$mtinf | xargs rm

echo -e  "\n\nVALORACION INFOVALMER:" >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/eod_scripts/MarketDataInfovalmer/* -prune -name "*.txt*" -mtime +$mtinf >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/eod_scripts/MarketDataInfovalmer/* -prune -name "*.txt*" -mtime +$mtinf  | xargs rm
find /murex/murex_app/app/eod_scripts/MarketDataInfovalmer/* -prune -name "*.001" -mtime +$mtinf >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/eod_scripts/MarketDataInfovalmer/* -prune -name "*.001" -mtime +$mtinf  | xargs rm

echo -e "\n\nIMPUESTOS - IMV:" >> /murex/proceso/mx_depurarModulos.log
find /impyval/mfc-module/taxmodule/processed -mtime +$mt >> /murex/proceso/mx_depurarModulos.log
find /impyval/mfc-module/taxmodule/processed -mtime +$mt | xargs rm

echo -e "\n\nVALORACION PRECIOS INT:" >> /murex/proceso/mx_depurarModulos.log
find /VALUATION-MODULE/murex -mtime +$mt  >> /murex/proceso/mx_depurarModulos.log
find /VALUATION-MODULE/murex -mtime +$mt | while read file;
do
rm "$file"
done;

echo -e "\n\nFINANCIERO CONTABLE-MFC:" >> /murex/proceso/mx_depurarModulos.log
find /mfc-module/taxmodule/processed -mtime +$mt >> /murex/proceso/mx_depurarModulos.log
find /mfc-module/taxmodule/processed -mtime +$mt | xargs rm

echo -e "\n\nDATAMART EXTRACTIONS IMP COUPON:" >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/taxmodule/coupon/datamart_extractions/ProcessedFiles -mtime +$mt >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/taxmodule/coupon/datamart_extractions/ProcessedFiles -mtime +$mt | xargs rm

echo -e "\n\nDATAMART EXTRACTIONS IMP INTERESTRATES:" >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/taxmodule/interestrates/datamart_extractions/ProcessedFiles -mtime +$mt >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/taxmodule/interestrates/datamart_extractions/ProcessedFiles -mtime +$mt | xargs rm

echo -e "\n\nACC Sql Log:" >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/Acc_Sql_Log/datamart_extractions -mtime +$mtAcc >> /murex/proceso/mx_depurarModulos.log
find /murex/murex_app/app/Acc_Sql_Log/datamart_extractions -mtime +$mtAcc -mtime +$mt | xargs rm

echo -e "\n\nCARTAS DE CONFIRMACION:" >> /murex/proceso/mx_depurarModulos.log
find /murex/tmp/matching/processedfiles -mtime +$mt >> /murex/proceso/mx_depurarModulos.log
find /murex/tmp/matching/processedfiles -mtime +$mt | while read file;
do
rm "$file"
done;

echo -e "\n\nINSTRUCCIONES DE CUMPLIMIENTO:" >> /murex/proceso/mx_depurarModulos.log
find /murex/tmp/matching/processedfilesSI -mtime +$mt >> /murex/proceso/mx_depurarModulos.log
find /murex/tmp/matching/processedfilesSI -mtime +$mt | while read file;
do
rm "$file"
done;

