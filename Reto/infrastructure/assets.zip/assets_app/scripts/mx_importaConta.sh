#!/bin/bash

imp MUREX@MURCERT file=trn_acr1.dbf tables=\(TRN_ACR1_DBF\)
imp MUREX@MURCERT file=trn_aca1.dbf tables=\(TRN_ACA1_DBF\)
imp MUREX@MURCERT file=trn_aca2.dbf tables=\(TRN_ACA2_DBF\)
imp MUREX@MURCERT file=trn_aca3.dbf tables=\(TRN_ACA3_DBF\)
imp MUREX@MURCERT file=trn_acaf.dbf tables=\(TRN_ACAF_DBF\)
imp MUREX@MURCERT file=trn_acat.dbf tables=\(TRN_ACAT_DBF\)
imp MUREX@MURCERT file=trn_acfd.dbf tables=\(TRN_ACFD_DBF\)
imp MUREX@MURCERT file=acccfg_fil_accb.dbf tables=\(ACCCFG#FIL_ACCB_DBF\)
imp MUREX@MURCERT file=acccfg_fil_accd.dbf tables=\(ACCCFG#FIL_ACCD_DBF\)
imp MUREX@MURCERT file=acccfg_fil_acch.dbf tables=\(ACCCFG#FIL_ACCH_DBF\)
imp MUREX@MURCERT file=acccfg_fil_acct.dbf tables=\(ACCCFG#FIL_ACCT_DBF\)

echo "Terminado"

