dsmc retrieve -fromdate=03/18/11 -todate=03/18/11 -subdir=yes -replace=yes /backupapli/logs/ /backupapli/recuperar/
