#!/bin/bash

cd /murex/murex_app/app
./mx3_launchallDoc.sh start
