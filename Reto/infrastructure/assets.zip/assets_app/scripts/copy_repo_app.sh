#!/bin/bash

#Realiza la copia del app de produccion
strFecha=`date +"%Y%m%d"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
echo "Hora de inicio:" $strFechaHora > /murex/scripts/log_copy.log

# Comprime el app
cd /murex/murex_app/
tar -zcf /murex/murex_app/appProd$strFecha.tar.gz --exclude='mxdoc_fs' --exclude='/murex/murex_app/app/AccountEntries/' --exclude='/murex/murex_app/app/delCpt/' --exclude='/murex/murex_app/app/MX_PYG/' --exclude='mfc' --exclude='/murex/murex_app/app/CRCC/Archive/' --exclude='/murex/murex_app/app/fs/murex/' --exclude='/murex/murex_app/app/core.*' --exclude='/murex/murex_app/app/tmp_mra/mr_engine_all' --exclude='/murex/murex_app/app/tmp_mra/mrb_run_0' --exclude='/murex/murex_app/arch_conversion' --exclude='/murex/murex_app/temporal' --exclude='/murex/murex_app/modulos_bck' --exclude='/murex/murex_app/Reportes_audit' --exclude='/murex/murex_app/logs_back' --exclude='/murex/murex_app/Controles_sox' --exclude='/murex/murex_app/rest' --exclude='/murex/murex_app/appP*.tar.gz' --exclude='/murex/murex_app/.mxdoc_fs.tar.8oeeSH' --exclude='/murex/murex_app/app/log_*' --exclude='/murex/murex_app/app/logs' --exclude=\*.{tar*,0,1,2,3,4,10,64,120313,14614608,20140424,20170609,26092013,20180212_beforeNewEodREstart,a,a*,b*,c*,C2,d*,e*,F*,g*,h*,i*,j*,k*,l*,M*,mod,mxres*,n*,o,o*,pc,pd*,ph*,pid,pl,png,policy,pr*,prod*,properties*,props,pus*,py*,r*,sc*,se*,sh*,sig,sl,so,sql,SW*,sy*,t*,up*,v*,w*,xd*,xh*,xl*,xml*,xs*,z*} /murex/murex_app/

echo "Copia del app finalizada" >> /murex/scripts/log_copy.log

strFecha=`date +"%Y%m%d"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
echo "Hora de finalizacion:" $strFechaHora >> /murex/scripts/log_copy.log
echo "paso 1: Copia produccion realizada OK" >> /murex/scripts/log_copy.log
