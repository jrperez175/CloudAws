#!/bin/sh
# Script to load the parameters to be use by the modification script.
# Developed by Sebastian Eraso for Murex Application
# Client: Bancolombia S.A.

cd /murex/scripts/ 
. ../murex_app/app/mxg2000_settings.sh
TIMESTAMP=`date "+%Y%m%d_%H%M%S"`

_auto (){
echo -e "\e[3;32;40mAutomatic configuration procedure has been initialized.\e[0m"
echo ""

cat Parameters | while read LINE;
	do
		./scriptModifyConfig.sh $LINE 
	done
echo ""
echo -e "\e[3;32;40mProcess finished.\e[0m"
}

_manual () {
echo -e "\e[3;32;40mManual configuration procedure has been initialized.\e[0m"
echo ""

cat ParametersManual | while read LINE;
	do
		./scriptModifyConfigManual.sh $LINE 
	done
echo ""
echo -e "\e[3;32;40mProcess finished.\e[0m"
}

_changeHA () {
echo -e "\e[3;32;40mHA configuration procedure has been initialized.\e[0m"
echo ""

if [ "$MXJ_FILESERVER_HOST" = "SBMDEBMUR01" ]
then
	cat Parameters.HA | while read LINE;
	        do
	                ./scriptModifyConfig.sh $LINE
	        done
	echo ""
	echo -e "\e[3;32;40mProcess finished.\e[0m"
else if [ "$MXJ_FILESERVER_HOST" = "SBMDEBMUR03" ]
	then
		cat Parameters.03to01 | while read LINE;
                	do
                	        ./scriptModifyConfig.sh $LINE
                	done
	        echo ""
	        echo -e "\e[3;32;40mProcess finished.\e[0m"
	fi
fi
}

_usage() {
              echo ''
			  echo " Usage: $0 automatic|manual|changeHA" 1>&2
			  echo ''
			  echo ' +-----------------------------------------------------------------------+'
			  echo ' |          Script for configuration modification BANCOLOMBIA            |'
			  echo ' +-----------------------------------------------------------------------+'
			  echo ' | automatic          : Automatic procedure find and change files        |'
			  echo ' | manual             : Manual procedure to specific files               |'			  
			  echo ' | changeHA		: Change configuration for HA use		 |'
			  echo ' +-----------------------------------------------------------------------+'
			  echo ''
			  exit 1

}
# Mx Main
# =================================================================================
NAME=${0##*/} # Same as `basename $0`

case $NAME in

  (scriptLoadParameters.sh) # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    case $1 in
      automatic)
        _auto 
      ;;
	  manual)
        _manual
      ;;
	 changeHA)
        _changeHA
      ;;
      *)
       _usage
      ;;
   esac
esac
