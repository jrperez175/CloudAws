#!/bin/bash

an=`date +"%Y"`
me=`date +"%m"`

if [ $me -eq 1 ]; then
  me=11
else
  if [ $me -eq 2 ]; then
    me=12
  else
    me=`expr $me - 2`
  fi
fi

if [ $me -lt 10 ]; then
  me=0$me
fi

nom=$an$me
# falta hacer cd al directorio para borrar
rm *$nom*
