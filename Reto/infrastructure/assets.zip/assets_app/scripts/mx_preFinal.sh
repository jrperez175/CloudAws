#!/bin/bash -l

#########################################
# mx_preFinal.sh
# Descripcion                           Comandos de precondicion a ejecutar antes del ultimo reinicio luego del cierre
# Fecha de creacion                     2010/01/04
#########################################

hostname=`hostname`
strFecha=`date +"%Y%m%d"`
strFileName=$MUREX_HOME/proceso/$hostname.$strFecha.log

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Inicio precondiciones" >> $strFileName

#cp $MUREX_HOME/mlcLogger/mlclogger.pdn $MUREX_HOME$MUREX_APP/fs/public/mxres/mxmlc/mlclogger.xml
cd /tmp
tar -cvpf - /tmp/mlc*.xml | gzip -9 -c > mlcEngineRecoveryFiles$strFecha.tar.gz
mv mlcEngineRecoveryFiles$strFecha.tar.gz $BACKUP_DIR/logs

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Fin precondiciones" >> $strFileName
