!/bin/bash

ulimit -n 8192

./launchmxj.app -s

case $1 in
        start)
                echo "STARTING ALL SERVICES"
                ejecutar.sh "./launchmxj.app -fs -jopt:-Xmx512m"
		if [ $? -ne 0 ]; then
			echo "Fallo el inicio del servicio file server"
			exit 1
		fi
                ejecutar.sh "./launchmxj.app -xmls -jopt:-Xmx256m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio xml server"
                        exit 1
                fi
		ejecutar.sh "./launchmxj.app -l -jopt:-Xmx256m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio launcherall"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:launchergc.mxres -jopt:-Xmx256m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio LauncherGC"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -mxnet"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio mxnet"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -mxml"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio mxml"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -mandatory"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio mandatory"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -warehouse"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio warehouse"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -hub /MXJ_HUB_NAME:hub_madrid"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio hub madrid"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -mxhibernate -jopt:-Xms512m -jopt:-Xmx2G"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio hibernate"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launchermxcontribution.mxres -jopt:-Xmx128m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio mxcontribution"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -mdcs"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio mdcs"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -rtbs"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio rtbs"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -mdrs"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio mdrs"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -aagent"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio aagent"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launcherreportsrv.mxres -jopt:-Xmx128m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio report server"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launchermxdistribution.mxres -jopt:-Xmx128m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio mxdistribution"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launchermxfinparser.mxres"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio fin parser"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -smonit /MXJ_CONFIG_FILE:public.mxres.mxsoaprelay.start_mxsoapregistry.mxres -jopt:-Xmx128m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio soap relay registry"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launcherireporting.mxres"
                sleep 5
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio ireporting"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.RTBStargets_INTRADAY.xml /MXJ_ANT_TARGET:startConfig -jopt:-DconfigName=Realtime_INTRADAY_REAL"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio RTBS Targets Intraday Real"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launchermxdealscanner_m.mxres -jopt:-Xmx128m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio DealScanner Master"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launchermxdealscanner_s.mxres -jopt:-Xmx128m"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio DealScanner Slave"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -mlc"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio MLC server"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launcherltsservice.mxres"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio LTS"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -lrb"
                if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio LRB"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launchermxvar.mxres"
        	if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio MXVAR"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.sessioncheck.mxres  /MXJ_ANT_TARGET:disable"
                if [ $? -ne 0 ]; then
                        echo "Fallo el chequeo de sesiones"
                        exit 1
                fi
                ejecutar.sh "mx_lanzarCacheWarmup.sh"
		if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio Cache Warmup"
                        exit 1
                fi
                ejecutar.sh "./launchmxj.app -xmlreq /MXJ_CONFIG_FILE:startworkflow.xml"
        	if [ $? -ne 0 ]; then
                        echo "Fallo el inicio del servicio startWorkflow"
                        exit 1
                fi
		;;
        stop)
                echo "STOPPING ALL SERVICES"
                ./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.broadcastmessage5.mxres /MXJ_ANT_TARGET:broadcast
#               sleep 60
                ./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.broadcastmessage4.mxres /MXJ_ANT_TARGET:broadcast
#		sleep 60
                ./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.broadcastmessage3.mxres /MXJ_ANT_TARGET:broadcast
#		sleep 60
                ./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.broadcastmessage2.mxres /MXJ_ANT_TARGET:broadcast
#		sleep 60
                ./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.broadcastmessage1.mxres /MXJ_ANT_TARGET:broadcast
#		sleep 60
                ./launchmxj.app -xmlreq /MXJ_CONFIG_FILE:stopworkflow.xml
                ./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.RTBStargets_INTRADAY.xml /MXJ_ANT_TARGET:stopConfig -jopt:-DconfigName=Realtime_INTRADAY_REAL
                ./launchmxj.app -hub /MXJ_HUB_NAME:hub_madrid -k
                ./launchmxj.app -smonit /MXJ_CONFIG_FILE:public.mxres.mxsoaprelay.stop_mxsoapregistry.mxres -jopt:-Xmx128m
                ./launchmxj.app -killfeeder:activityfeeder.all -jopt:-Xmx128m
                ./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.killMx.xml /MXJ_ANT_TARGET:kill_mx_services -jopt:-Xmx256m
                ./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.remove_temp.mxres /MXJ_ANT_TARGET:cleanup
                ./launchmxj.app -stopall
		;;
        *)
                echo "Usage: $0 {start|stop}" 1>&2
                exit 1
esac
