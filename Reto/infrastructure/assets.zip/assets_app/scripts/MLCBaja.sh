#!/usr/bin/bash

#########################################
# MLCBaja.sh
# Descripcion                           Detiene los servicios de MLC
# Fecha de creacion                     2009/10/26
#########################################

cd /murex/murex_app/app
./launchmxj.app.64 -lrb -k
./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launcherltsservice.mxres -k
./launchmxj.app.64 -mlc -k
./run_las_ssl.sh stop

