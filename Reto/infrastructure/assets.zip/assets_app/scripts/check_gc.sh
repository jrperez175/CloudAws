#!/bin/bash

# Usage helper for this script
function usage() {
    local prog="${1::check_gcsh}"
    echo "Usage: $prog -v";
    echo "       Print version and exit"
    echo "Usage: $prog -h";
    echo "      Print this help nd exit"
    echo "Usage: $prog -w <warning threshold in KB> -c <critical memory threshold in KB> -l <log file path>";
}

VERSION='0.2'
WARNING_THRESHOLD=3000000
CRITICAL_THRESHOLD=3200000
TOTAL_THRESHOLD=210000
LOG_FILE="UNDEFINED"
hostname=`hostname`

while getopts hvw:t:c:l: opt ; do
    case ${opt} in
    v)  echo "$0 version $VERSION"
        exit 0
        ;;
    h)  usage $0
        exit 3
        ;;
    w)  WARNING_THRESHOLD="${OPTARG}"
        ;;
    c)  CRITICAL_THRESHOLD="${OPTARG}"
        ;;
    t)  TOTAL_THRESHOLD="${OPTARG}"
        ;;
    l)  LOG_FILE="${OPTARG}"
        ;;
    esac
done

#sample format:

AF_START='<af type="tenured" id="1" timestamp="Apr 18 14:36:40 2013" intervalms="123.012">'
GC_START='<gc type="global" id="2" totalid="2" intervalms="123.012">'
GC_DURATION='<timesms mark="100.0" sweep="100.0" compact="0.2" total="200.2" />'
GC_MEMORY_SUMMARY='<tenured freebytes="200000" totalbytes="2000000" percent="33" >'
GC_END="</gc>"
AF_END="</af>"

# regular expressions
AF_START_REGEX='<af type="([A-Za-z]+)" id="([0-9]+)" timestamp="([A-Za-z:0-9 ]+)" intervalms="([0-9.]+)">'
GC_START_REGEX='<gc type="([a-z]+)" id="([0-9]+)" totalid="([0-9]+)" intervalms="([0-9.]+)">'
GC_DURATION_REGEX='<timesms mark="([0-9.]+)" sweep="([0-9.]+)" compact="([0-9.]+)" total="([0-9.]+)" />'
GC_MEMORY_SUMMARY_REGEX='<tenured freebytes="([0-9]+)" totalbytes="([0-9]+)" percent="([0-9]+)" >'
GC_END_REGEX="</gc>"
AF_END_REGEX="</af>"

CURRENT_STATE=0
RETURN_CODE=0

function test_threshold {
    VALUE=$1
    THRESHOLD=$2
    LEVEL=$3
    ERROR_CODE=$4
    GC_TYPE=$5
    #echo "test_threshold : " $VALUE $THRESHOLD $LEVEL $ERROR_CODE
    if [[ $VALUE > $THRESHOLD ]]
    then
       echo "$LEVEL: heap size still above threshold ($THRESHOLD) after $GC_TYPE : $"
       if [[ $ERROR_CODE > $RETURN_CODE ]]
       then
           RETURN_CODE=$ERROR_CODE
       fi

    fi

}
function check_line {

    if [[ $1 =~ $AF_START_REGEX ]]
    then
        #echo "AF line " ${BASH_REMATCH[1]}  ${BASH_REMATCH[2]} ${BASH_REMATCH[3]}  ${BASH_REMATCH[4]}
        TIMESTAMP=${BASH_REMATCH[3]}
        if [[ $CURRENT_STATE == 0 ]]
        then
           CURRENT_STATE=1
        else
#           echo "Unexpected AF start"
           CURRENT_STATE=1
        fi

    fi
    if [[ $1 =~ $GC_START_REGEX ]]
    then
        #echo "GC start " ${BASH_REMATCH[1]}  ${BASH_REMATCH[2]} ${BASH_REMATCH[3]} ${BASH_REMATCH[4]}

        if [[ $CURRENT_STATE == 1 ]]
        then
           CURRENT_STATE=2
        else
#           echo "Unexpected GC start"
           CURRENT_STATE=2
        fi
    fi

    if [[ $1 =~ $GC_DURATION_REGEX ]]
    then
        if [[ $CURRENT_STATE != 2 ]]
        then
           echo "Unexpected GC duration"
        fi
        #echo "GC duration " ${BASH_REMATCH[1]}  ${BASH_REMATCH[2]} ${BASH_REMATCH[3]} ${BASH_REMATCH[4]}
    fi

    if [[ $1 =~ $GC_MEMORY_SUMMARY_REGEX ]]
    then
        if [[ $CURRENT_STATE == 2 ]]
        then
#           echo "GC memory summary " ${BASH_REMATCH[1]}  ${BASH_REMATCH[2]} ${BASH_REMATCH[3]} ${BASH_REMATCH[4]}
           TENURED_FREE_BYTES=${BASH_REMATCH[1]}
           TOTALBYTES=${BASH_REMATCH[2]} 
          if [[ $TOTALBYTES -gt $TOTAL_THRESHOLD ]]
          then

             if [[ $TENURED_FREE_BYTES -lt $CRITICAL_THRESHOLD ]]
             then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] CRITICAL: Murex - $hostname - $LOG_FILE La memoria liberada Free bytes=$TENURED_FREE_BYTES de un total de TotalBytes=$TOTALBYTES es menor a la del umbral definido. Ver log  $hostname.ProcessMonitor.log timestamp: $TIMESTAMP"

             elif [[ $TENURED_FREE_BYTES -lt $WARNING_THRESHOLD ]]
             then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] WARNING: Murex - $hostname - $LOG_FILE La memoria liberada Free bytes=$TENURED_FREE_BYTES de un total de TotalBytes=$TOTALBYTES es menor a la del umbral definido. Ver log  $hostname.ProcessMonitor.log timestamp: $TIMESTAMP"

             fi
          fi
        fi
    fi

    if [[ $1 =~ $GC_END_REGEX ]]
    then
        CURRENT_STATE=1
    fi
    if [[ $1 =~ $AF_END_REGEX ]]
    then
        CURRENT_STATE=0
    fi
}



while read line; do
    check_line "$line"
done < <(tail -100 $LOG_FILE)

exit $RETURN_CODE

