#!/bin/bash

su - murex -c '/murex/scripts/mx_lanzarMxPdn.sh start pbmdeapmur10'

exit
