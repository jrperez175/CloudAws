#!/bin/sh
# Script to replace values of configuration files so it wont be pointing to other environment.
# Developed by Sebastian Eraso for Murex Application
# Client: Bancolombia S.A.
# 1. Extension Archivos
# 2. Parametro a buscar
# 3. Parametro por el cual remplazar 2
# 4. Explicacion en una palabra del cambio ejemplo (passwordAdmin, puertosMxnet, etc)

cd /murex/murex_app/app 
TIMESTAMP=`date "+%Y%m%d_%H%M%S"`
ARCHIVO_LOG=/murex/logsRestauracion/modification_${4}_on_${1}_${TIMESTAMP}.log

echo -e "\e[3;32;40mInicio de Ejecuccion Cambios de $4 en archivos extension ${1}\e[0m"
echo -e "Inicio de Ejecuccion Cambios de $4 en archivos extension ${1}" >> $ARCHIVO_LOG
		
find . -name "*.$1" -exec grep -il "$2" {} \; | while read nxt ;
		do 
			sed -e "s/$2/$3/g" ${nxt} > ${nxt}.new ; mv ${nxt}.new ${nxt}
			chmod 775 "$nxt"			
			echo -e "En el archivo $nxt se le cambia el parametro $2 por => $3" >> $ARCHIVO_LOG
		done;
		
echo -e "\e[3;32;40mRevisar el archivo $ARCHIVO_LOG para conocer los cambios realizados.\e[0m"
echo ""

