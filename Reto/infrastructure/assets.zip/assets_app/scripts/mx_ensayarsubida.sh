#!/bin/bash

#########################################
# mx_ensayarsubida.sh
# Descripcion                           Script para pruebas de scripts
# Fecha de creacion                     2009/10/26
#########################################

hostname=`hostname`

echo "$0 Subiendo $hostname, un momento por favor..."

sleep 10

