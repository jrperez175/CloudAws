#!/bin/sh

###################################################################################################################
# este shell verifica el estado del cliente de opcon si encuentra que no esta activo los sube y sino no hace nada #
###################################################################################################################

sudo /usr/local/lsam/bin/lsam3100 status | grep -Ev "^$|Currently|^-|UID" | wc -l | read cont
if [ $cont -eq 0 ]
then
    echo "Servicio Detenido" >> /syslog/opcon.log
else
   sudo /usr/local/lsam/bin/lsam3100 status | grep sma_lsam > /syslog/opcon.log
fi

sudo /usr/local/lsam/bin/lsam3100 status | grep sma_lsam
if [ $? = 1 ]; then
 sudo /usr/local/lsam/bin/lsam3100 start
fi
