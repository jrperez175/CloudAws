#!/bin/bash -l

cd $MUREX_HOME/proceso
hostname=`hostname`
SharedGhost=`ipcs -a | awk  '$9 == 0' | awk  '$10 > 0' | wc -l`
SharedMx=`ipcs -a | grep "^m" | awk '$5=="murex"' | awk '$9 > 0' | wc -l`
HighMemProcessCr=`ps -eo pid,vsz,rssize,args| sort -n -k 2,2 | awk '$2>3200000' | awk '$4=="mx" || $4=="mx_cache"' | wc -l`
HighMemProcessWr=`ps -eo pid,vsz,rssize,args| sort -n -k 2,2 | awk '$2>2800000' | awk '$4=="mx" || $4=="mx_cache"' | wc -l`

####################### Busca procesos fantasma con memoria compartida en la maquina (Con NATTCH=0) y los elimina automaticamente 

if [ $SharedGhost -gt 2 ]; then
        echo -e "\n[`date +"%Y/%m/%d %H:%M:%S"`] WARNING: Murex - $hostname - Se encontraron $SharedGhost procesos con NATTCH=0 en el servidor. Ver log  $hostname.ProcessMonitor.log"  >> $hostname.ProcessMonitor.log
        ipcs -a | awk  '$9 == 0' | awk  '$10 > 0' |awk {'print $2'} |  xargs -l1 ipcrm -m
fi

####################### Busca procesos Murex con memoria compartida  en la maquina (Con Owner=murex y con NATTCH!=0) y genera una alerta 

#if [ $SharedMx -gt 3 ]; then
#        echo -e "\n[`date +"%Y/%m/%d %H:%M:%S"`] WARNING: Murex - $hostname - Se encontraron $SharedMx procesos con OWNER=murex y NATTCH>0 en el servidor. Ver log  $hostname.ProcessMonitor.log"  >> $hostname.ProcessMonitor.log
#fi

####################### Busca procesos MX o MX_CACHE con alto consumo de memoria y genera alerta CRITICAL

if [ $HighMemProcessCr -gt 0 ]; then
        echo -e  "\n[`date +"%Y/%m/%d %H:%M:%S"`] CRITICAL: Murex - $hostname - Se encontraron $HighMemProcessCr procesos Murex con alto consumo de memoria en el servidor. Ver log  $hostname.ProcessMonitor.log \n"  >> $hostname.ProcessMonitor.log
        ps -eo pid,vsz,rssize,args| sort -n -k 2,2 | awk '$2>3200000' | awk '$4=="mx" || $4=="mx_cache"' >> $hostname.ProcessMonitor.log
        echo -e  "\n" >> $hostname.ProcessMonitor.log
fi

####################### Busca procesos MX o MX_CACHE con alto consumo de memoria y genera alerta WARNING

if [ $HighMemProcessWr -gt 0 ]; then
        echo -e  "\n[`date +"%Y/%m/%d %H:%M:%S"`] WARNING: Murex - $hostname - Se encontraron $HighMemProcessWr procesos Murex con alto consumo de memoria en el servidor. Ver log  $hostname.ProcessMonitor.log \n"  >> $hostname.ProcessMonitor.log
        ps -eo pid,vsz,rssize,args| sort -n -k 2,2 | awk '$2>2800000' | awk '$4=="mx" || $4=="mx_cache"' >> $hostname.ProcessMonitor.log
        echo -e  "\n" >> $hostname.ProcessMonitor.log
fi

####################### Revisa los archivos de Garbage collector comparandolos con un umbral y genera alerta

if [ $hostname == "pbmdeapmur03" ]; then
check_gc.sh -c 100000000 -w 280000000 -t 3500000000 -l $MUREX_HOME$MUREX_APP/logs/mxmlc.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 480000000 -t 3500000000 -l $MUREX_HOME$MUREX_APP/logs/mxlrb.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 480000000 -t 3500000000 -l $MUREX_HOME$MUREX_APP/logs/mxhibernate.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 380000000 -t 2100000000 -l $MUREX_HOME$MUREX_APP/logs/RTBS.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 380000000 -t 2100000000 -l $MUREX_HOME$MUREX_APP/logs/warehouse.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 380000000 -t 2100000000 -l $MUREX_HOME$MUREX_APP/logs/aagent.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 380000000 -t 2100000000 -l $MUREX_HOME$MUREX_APP/logs/mxmlexchage.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 480000000 -t 3500000000 -l $MUREX_HOME$MUREX_APP/logs/mxmlworker.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 480000000 -t 3500000000 -l $MUREX_HOME$MUREX_APP/logs/mxmlspaces.gc.log >> $hostname.ProcessMonitor.log
check_gc.sh -c 300000000 -w 380000000 -t 2100000000 -l $MUREX_HOME$MUREX_APP/logs/mxmlsecondary.gc.log >> $hostname.ProcessMonitor.log
fi

