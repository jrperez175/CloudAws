#!/bin/bash -l

cd $MUREX_HOME$MUREX_APP
cd mxmlexchange
i=0
while [ $i -lt 66 ]; do
echo "Iniciando el monitoreo de WF..."
./MxMLExchange_TaskStatusMonitor.sh > /murex/murex_app/app/logs/taskMonitor.log &
sleep 300
echo "Cerrando procesos viejos"
ps -aef | grep taskstatusmonitorconfig | awk {'print $2'} | xargs kill -9
i=`expr $i + 1`
done
