#!/bin/bash -l

#########################################
# mx_cierre.sh
# Descripcion                           Invoca los scripts del cierre para ejecutarlos via shell
#					Por validar el comportamiento
# Fecha de creacion                     2009/10/26
#########################################

cd /murex/murex_app/app/eod_scripts/

echo "Arranca el proceso fx_closing_exterior.sh"
./fx_closing_exterior.sh
echo "Termina el proceso, presione C para continuar, F para finalizar"

salida="F"

while [ $salida == "F" ]
do
  read texto
  if [ $texto == "F" -o $texto == "f" ]
  then
    exit 1
  fi
  if [ $texto == "C" -o $texto == "c" ]
  then
    salida="T"
  fi
done

if [ $texto == "C" ]
then
  echo "Arranca el proceso cierre_exterior_1.sh" 
 ./cierre_exterior_1.sh
fi
./fx_conversions.sh
./cierre_exterior_2.sh
./cierre_exterior_3.sh
./cierre_exterior_4.sh
./vistas_fo.sh
./fo_closing_exterior.sh
./cierre_exterior_5.sh
./cierre_exterior_6.sh
./move_date_exterior.sh


echo "Empieza cierre Colombia"

./fx_closing_colombia.sh
./cierre_colombia_1.sh
./cierre_colombia_2_2.sh
./cierre_colombia_3.sh
./cierre_colombia_4.sh
./var_eod.sh
./vistas_fo.sh
./fo_closing_colombia.sh
./cierre_colombia_5.sh
./cierre_colombia_5_1.sh
./pcenter_date_move.sh
./cierre_colombia_6.sh
./move_date_colombia.sh
cd ../mlc/mlc_eod
./mlc_eod.sh
cd ../../eod_scripts/
./reportes_auditoria.sh
./reportes_fin_dia.sh

