#!/bin/bash

#########################################
# mx_bajarMLCcluster.sh
# Descripcion                           Baja el servicio de MLC en el pbmdeapmur10 para hacer el cambio de cluster
# Fecha de creacion                     2009/10/26
#########################################

su - murex -c '/murex/scripts/mx_lanzarMxPdn.sh stop pbmdeapmur10'

exit
