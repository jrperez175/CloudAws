#!/bin/ksh

MXPID=$1

DELAY=1
while (( 1 == 1 )) ; do
        DATE=$( date '+%Y-%m-%d--%H:%M:%S' )
        echo "MX PROCSTACk: $DATE" >> logs/mx.$MXPID.log
        sleep 1 
        /murex/upload/procstack $MLCPID >> logs/mx.$MXPID.log
        sleep $DELAY
done

