#!/bin/bash

#######################################################################################################
# Este programa hace un depurado de los archivos de logs que genera el programa de impuestos de murex #
#######################################################################################################
cd /impyval/logs
rm wrapper.log
touch wrapper.log
cd /impyval/conf
rm *tasaCIB*
cd /impyval/lib
rm *tasasCIB*
