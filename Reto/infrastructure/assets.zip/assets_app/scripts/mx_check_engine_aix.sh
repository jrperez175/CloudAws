#!/usr/bin/env bash

#PATCH THESE VARIABLES TO ADAPT TO ENV:
TIMING_DIR=./timing
# START OF CODE
TARGET=$1

OS=`uname`
echo "Analyzing:" $TARGET
if echo $TARGET | grep "^[0-9]*$"> /dev/null
then
   LIVE=1 #TARGET is a PID
   PID=$TARGET
else
   LIVE=0 #TARGET is a core file
   PID=`echo $TARGET|awk -F. '{print $4}'`
fi

TARGET=$1
SUFFIX=$TARGET
TS=`date +"%Y%m%d"`
TMP_FILES=""
echo ""
echo ""
echo "Collecting pstack for $TARGET"
if [ $LIVE -eq 0 ]
then
  perl -e "alarm 10 ; exec @ARGV" "pstack_aix.sh mx $TARGET" > pstack.$SUFFIX.txt
  TMP_FILES=$TMP_FILES" pstack.$SUFFIX.txt"
else
  procstack $PID > pstack.$SUFFIX.txt
  TMP_FILES=$TMP_FILES" pstack.$SUFFIX.txt"
fi 

#echo "Collecting pargs for $TARGET"
#pargs $TARGET > pargs.$SUFFIX.txt

echo ""
echo ""
echo "Collecting size information for $TARGET"
if [ -f $TARGET ];
then

   ls -l $TARGET > ls-l.$SUFFIX.txt
   cat ls-l.$SUFFIX.txt
   TMP_FILES=$TMP_FILES" ls-l.$SUFFIX.txt"
fi
if [ $LIVE -eq 1 ]
then
   ps -eo pid,vsz,rssize,args | grep "^$PID" > ps_output.$SUFFIX.txt
   cat ps_output.$SUFFIX.txt
   TMP_FILES=$TMP_FILES" ps_output.$SUFFIX.txt"
fi
echo ""
echo ""
echo "Looking for timing files for PID: $PID"
TIMING_FILES=`find $TIMING_DIR -name "mxtiming*$PID".log`
TRACE_FILES=`find $TIMING_DIR -name "*$PID".trc`

echo "Tarring files for $TARGET"
tar cvf check_${SUFFIX}_$TS.tar $TMP_FILES $TIMING_FILES $TRACE_FILES
gzip -f check_${SUFFIX}_$TS.tar


echo "---Start of Summary---"
echo "* Pstack Summary"
awk  '/>\$t1/ {START=START+1}; {if (START>2) print}' < pstack.$SUFFIX.txt| head -30

echo "---End of Summary---"
echo "Removing temporary files"
rm -rf $TMP_FILES

echo "Please send check_${SUFFIX}_$TS.tar to Murex support"


