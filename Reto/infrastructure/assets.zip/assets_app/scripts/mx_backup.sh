#!/bin/bash

#########################################
# mx_backup.sh
# Descripcion                           Coloca en un archivo tar.gz el directorio/archivo que le especifiquen
# Parametros                            $1 Ruta a respaldar
#                                       $2 Nombre del archivo
# Fecha de creacion                     2009/10/26
#########################################

echo "******** Proceso de respaldo ********"
echo "1. Generando respaldo de $1 en $BACKUP_DIR/$2.tar.gz ..."
tar -cpvf - $1 | gzip -9 -c > $BACKUP_DIR/$2.tar.gz

echo "Archivo generado"

echo "Proceso finalizado"
