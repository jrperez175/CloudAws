#!/bin/bash -l

cd /murex/murex_app/app
opcion=10
hostname=`hostname`
strFecha=`date +"%Y%m%d"`
strFileName=/murex/proceso/prostack_$hostname.$strFecha.log
i=0
echo Digite el numero del proceso para sacar el procstack
  read opcion
    while [ $i -lt 2 ]
        do
            date >> trace001_20140429.txt
            procstack_fix_61TL2-2010-07-14 $opcion >> trace001_20140429.txt
                if [ $? = 0 ]; then
                      echo  "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - se ejecuta prosctack" >> $strFileName
                      i=1
                else
                     echo  "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - El proceso ya no esta disponible" >> $strFileName
                     exit 1
                     i=4
                fi
        done
