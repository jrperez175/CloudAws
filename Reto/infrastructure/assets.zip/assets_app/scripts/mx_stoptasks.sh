#!/bin/bash -l


# Subir y bajar determinadas tareas
cd /murex/murex_app/app/mxmlexchange
./xmlrequestscript_stoptasks.sh

