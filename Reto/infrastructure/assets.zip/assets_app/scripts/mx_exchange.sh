#!/bin/bash

cd $MUREX_HOME$MUREX_APP
echo "Bajando los flujos"
                ./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launchermxdistribution.mxres -jopt:-Xmx128m -k
		./launchmxj.app -mxml -jopt:-Djava.library.path=/usr/mqm/java/lib64 -k
		sleep 10
echo "Subiendo los flujos"
		./launchmxj.app -mxml -jopt:-Djava.library.path=/usr/mqm/java/lib64
                ./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launchermxdistribution.mxres -jopt:-Xmx128m
echo "Reinicio completado"
