#!/bin/bash -l

#########################################
# mx_fastReinicio.sh
# Descripcion                           Mata y reinicia Murex mas rapido
# Fecha de creacion                     2013/05/28
# Fecha de modificacion                 2014/03/14
# Descripcion modificacion		Mover los logs y los timings a la carpeta /murex/proceso/Mover los logs y los timings a la carpeta /murex/proceso/
# Fecha de modificacion                 2015/04/09
# Modificacion                          Incluir nuevo balanceador para Banistmo
#########################################

declare -i numArchivos
declare -i numEspera

cd $MUREX_HOME/proceso
strFecha=`date +"%Y%m%d"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
hostname=`hostname`
strFileName=$hostname.$strFecha.log

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Matando procesos en horizontales" >> $strFileName

touch pbmdeapmur04.kill
touch pbmdeapmur05.kill
touch pbmdeapmur08.kill
touch pbmdeapmur09.kill
touch pbmdeapmur10.kill
touch pbmdeapmur11.kill
touch pbmdeapmur12.kill
#touch pbmdeapmur14.kill


echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Matando procesos en la pbmdeapmur03" >> $strFileName

cat $MUREX_HOME$MUREX_APP/logs/pbmdeapmur03.*.pid | xargs kill -9

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Cerrando sesiones y procesos fantasma" >> $strFileName

ps -aef | grep 10000 | awk {'print $2'} | xargs kill -9
ps -aef | grep 10080 | awk {'print $2'} | xargs kill -9
ps -aef | grep 10090 | awk {'print $2'} | xargs kill -9
ps -aef | grep 10091 | awk {'print $2'} | xargs kill -9
ps -aef | grep 10099 | awk {'print $2'} | xargs kill -9

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Procesos en la pbmdeapmur03" >> $strFileName
ps -efa | grep murex >> $strFileName
ps -efa | grep murex

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Subiendo Murex" >> $strFileName

echo "Respaldando directorio de logs..."
mx_backup.sh logs/ logs_$strFechaHora

echo "Respaldando directorio de timings..."
mx_backup.sh timing/ dirTiming_$strFechaHora

mx_subirPdn.sh
echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Termina el fastReinicio" >> $strFileName
exit 0

