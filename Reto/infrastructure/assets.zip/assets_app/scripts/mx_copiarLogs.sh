#!/bin/bash -l

#########################################
# mx_copiarLogs.sh           
# Descripcion				Copiar el log de los scripts al directorio $BACKUP_DIR/logs
# Fecha de creacion                     2009/11/13
# Fecha de modificacion			2011/01/24
# Descripcion modificacion		Se mueve el log de los pings
# Fecha de modificacion                 2010/12/09
# Descripcion modificacion              Se ajusta la copia de logs para todos los equipos
#########################################

cd $MUREX_HOME/proceso
strFecha=`date +"%Y%m%d"`
hostname=`hostname`
strFileName=$hostname.$strFecha.log
strFileNamePing=$hostname.$strFecha.ping

if [ ! -e $BACKUP_DIR/logs/$hostname ]
then
	mkdir $BACKUP_DIR/logs/$hostname
	echo "Creo directorio"
fi
sleep 300
mv $strFileName $BACKUP_DIR/logs/$hostname
mv $strFileNamePing $BACKUP_DIR/logs/$hostname
if [ $hostname = 'pbmdeapmur03' ]
then
	mv mx_depurarModulos.log $BACKUP_DIR/logs/$hostname
	mv servicios*.log $BACKUP_DIR/logs/$hostname
fi
