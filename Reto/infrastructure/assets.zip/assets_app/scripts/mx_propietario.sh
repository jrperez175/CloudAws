#!/bin/bash

cd /impyval 
echo -e "\nLos archivos con propietario diferente a MUREX:\n\n" > /murex/scripts/mx_propietario.log
l -lR | awk ' {if ( $3 != "murex") {print $0} }' >> /murex/scripts/mx_propietario.log
