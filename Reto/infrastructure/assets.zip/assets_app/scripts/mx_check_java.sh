
SERVICE=$1
TS=`date +"%Y%m%d"`
TMP_FILES=""
for PID in `cat logs/*$SERVICE*.pid`
do 
   echo "Requesting javacore file with kill -3 $PID"

   kill -3  $PID

   echo "Requesting stacks with procstack"

   procstack $PID > pstack.$PID.txt

   ps -eo pid,vsz,rssize,args | grep "^$PID" > ps_output.$PID.txt
   TMP_FILES=$TMP_FILES" ps_output.$PID.txt" 
   TMP_FILES=$TMP_FILES" pstack.$PID.txt"

done

FILES=`ls -1 logs/*$SERVICE*.log javacore*$PID*.txt heapdump.*$PID*.phd`


echo "Tarring files for $TARGET"
tar cvf check_${SUFFIX}_$TS.tar $TMP_FILES $FILES
gzip check_${SUFFIX}_$TS.tar

