#!/bin/bash -l

cd $MUREX_HOME/proceso

strFecha=`date +"%Y%m%d"`

hostname=`hostname`
ping -c 2 pbmdeapmur01 > $hostname.$strFecha.ping
ping -c 2 pbmdeapmur02 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur03 >> $hostname.$strFecha.ping
ping -c 2 10.4.80.53   >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur04 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur05 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur06 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur07 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur08 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur09 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur10 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur11 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur12 >> $hostname.$strFecha.ping
ping -c 2 pbmdebpmur14 >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur03_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur04_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur05_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur07_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur08_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur09_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur10_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur11_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdeapmur12_gpfs >> $hostname.$strFecha.ping
ping -c 2 pbmdebpmur14_gpfs >> $hostname.$strFecha.ping
