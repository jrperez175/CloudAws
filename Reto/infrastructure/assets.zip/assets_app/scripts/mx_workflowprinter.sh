#!/bin/bash -l

sleep 300

# Subir y bajar determinadas tareas  
cd /murex/murex_app/app/mxmlexchange
#./xmlrequestscript_launchtasks.sh
./xmlrequestscript_stoptasks.sh

# Prender la interface de Bloomberg
cd /murex/murex_app/app
#./launchrtbs.sh stop RTBS
#./launchrtbs.sh start RTBS 
./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.RTBStargets_INTRADAY.xml /MXJ_ANT_TARGET:stopConfig -jopt:-DconfigName=Realtime_INTRADAY_REAL
./launchmxj.app -scriptant /MXJ_ANT_BUILD_FILE:public.mxres.script.middleware.RTBStargets_INTRADAY.xml /MXJ_ANT_TARGET:startConfig -jopt:-DconfigName=Realtime_INTRADAY_REAL


# Subir WorkFlow Impresoras 
cd /murex/murex_app/app/mxmlexchange
./xmlrequestscript_launchtasks.sh
