#!/bin/bash

#########################################
# mx_bajarcluster.sh
# Descripcion                           Baja el servicio de Murex en el pbmdeapmur03 para hacer el cambio de cluster
# Fecha de creacion                     2009/10/26
#########################################

#su - murex -c '/murex/scripts/mx_lanzarMxPdn.sh stop pbmdeapmur03'

exit
