#!/bin/bash -l

#########################################
# mx_controlarhss.sh
# Descripcion                           Atender comandos de subir / bajar las horizontales
# Fecha de creacion                     2009/11/13
# Fecha modificacion                    2013/02/20
# Descripcion modificacion              Se a�ade el manejo de matar las horizontales en caso de pasar 10 minutos sin responder
#########################################

cd $MUREX_HOME/proceso
hostname=`hostname`
strFecha=`date +"%Y%m%d"`
strFileName=$hostname.$strFecha.log
strLock=$hostname.mx_controlarhss.lock

if [ ! -e $strFileName ]
then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - El $hostname esperando por ordenes" >> $strFileName
fi

if [ ! -e $strLock ]
then
	if [ -e $hostname.stop ]
	then	
		touch $strLock
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitud de parada del servicio" >> $strFileName
		mx_lanzarMxPdn.sh stop $hostname
		rm $hostname.stop
		rm $hostname.up 
		touch $hostname.down
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitud de parada del servicio atendida con exito" >> $strFileName
		rm $strLock
	fi

	if [ -e $hostname.start ]
	then
		touch $strLock
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitud de inicio del servicio" >> $strFileName
		mx_lanzarMxPdn.sh start $hostname
		rm $hostname.start
		rm $hostname.down
        	touch $hostname.up
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitud de inicio del servicio atendida con exito" >> $strFileName
		rm $strLock
	fi

        if [ -e $hostname.pl ]
        then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Procesos Murex en la maquina" >> $strFileName
		ps -ef | grep murex >> $strFileName
		rm $hostname.pl
        fi

        if [ -e $hostname.discos ]
        then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Discos" >> $strFileName
                df -g >> $strFileName
                rm $hostname.discos
        fi

        if [ -e $hostname.kill ]
        then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Cerrando sesiones y procesos fantasma" >> $strFileName
                ps -aef | grep 10000 | awk {'print $2'} | xargs kill -9
                ps -aef | grep 10080 | awk {'print $2'} | xargs kill -9
                ps -aef | grep 10090 | awk {'print $2'} | xargs kill -9
                ps -aef | grep 10091 | awk {'print $2'} | xargs kill -9
                ps -aef | grep 10099 | awk {'print $2'} | xargs kill -9
                ps -aef | grep broadcast | awk {'print $2'} | xargs kill -9
                rm $hostname.kill
        fi

else
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - El mx_controlarhss ya esta ejecutandose en la maquina" >> $strFileName
        if [ -e $hostname.kill ]
        then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - KILL -" >> $strFileName
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Cerrando sesiones y procesos fantasma" >> $strFileName
                ps -aef | grep 10000 | awk {'print $2'} | xargs kill -9
                ps -aef | grep 10080 | awk {'print $2'} | xargs kill -9
                ps -aef | grep 10090 | awk {'print $2'} | xargs kill -9
                ps -aef | grep 10091 | awk {'print $2'} | xargs kill -9
                ps -aef | grep 10099 | awk {'print $2'} | xargs kill -9
                ps -aef | grep broadcast | awk {'print $2'} | xargs kill -9
                rm $hostname.kill $hostname.stop $hostname.start $hostname.*.lock
	fi
fi
exit 0
