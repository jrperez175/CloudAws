#!/bin/bash

#########################################
# mx_ensayarbajada.sh
# Descripcion                           Script de prueba para los script de cierre
# Fecha de creacion                     2009/10/26
#########################################

hostname=`hostname`

echo "$0 - Bajando $hostname, un momento por favor..."

sleep 10

mx_ensayarsubida.sh
