#!/bin/bash
#BUSCAR LOS ULTIMOS 60 DIAS
DIAS_A_BUSCAR=60

#DIAS DE RETENCION
DIAS_A_RETENER=8

#RUTA DESTINO
RUTA_DESTINO="/murex/murex_log/"

if [ ! [ "$DIAS_A_BUSCAR" -eq "$DIAS_A_BUSCAR" ] ] 2>/dev/null;
then
        echo "DIAS_A_BUSCAR no es un día válido"
        exit 1
fi

if [ ! [ "$DIAS_A_RETENER" -eq "$DIAS_A_RETENER" ] ]  2>/dev/null;
then
        echo "DIAS_A_RETENER no es un día válido"
        exit 1
fi

if [ ! -d "$RUTA_DESTINO" ] ;
then
        echo "RUTA_DESTINO no es una ruta válida"
        exit 1
fi

for PATRON in $(seq 1 $DIAS_A_BUSCAR)
do
        if [ "$PATRON" -gt "$DIAS_A_RETENER" ]
        then
                FECHA=`date "+%Y%m%d" -d -"$PATRON"days`
                echo "moviendo logs de $FECHA a la ruta $RUTA_DESTINO"
                mv /murex/murex_app/app/logs_$FECHA*.tar.gz $RUTA_DESTINO
                mv /murex/murex_app/app/mxtiming_logs_$FECHA*.tar.gz $RUTA_DESTINO
                mv /murex/murex_app/app/fixing_mxtiming_logs_$FECHA*.tar.gz $RUTA_DESTINO
                mv /murex/murex_app/app/timing_$FECHA*.tar.gz $RUTA_DESTINO
        fi
done
