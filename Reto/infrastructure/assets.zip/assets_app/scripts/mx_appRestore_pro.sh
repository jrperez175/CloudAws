#!/bin/bash -l


#############################Cambia la configuraci�n de los archivos de producci�n a los parametros de desarrollo
#############################En el archivo RestoreConf cada linea tiene dos campos: configuracion actual y configuracion deseada 

cd /murex/scripts

while read LINE ; do
	if [ "$LINE" == "" ]
        then
	        echo -e "\n\nLinea Vacia" >> /murex/scripts/mx_appRestore.log
	else
	       ./parametrizar.sh $LINE 
	fi
done < RestoreConf

echo -e "\n\nFin de Ejecucion" >> /murex/scripts/mx_appRestore.log
