#!/bin/sh
# MX.3 Cleaning Development environments Script
# It is only use for conversion to prepare the application directory ffrom production
# Built By Sebastian Eraso Pena from Sophos Banking


cd /murex/murex_app/app/

#Cleaning
#Algunas carpetas
cd /murex/murex_app/app
rm -r mlc_bckup20161111/
rm -r Install_201*
rm -r mlc-new-20110813-1019/
rm -r logs/*
rm *.tar.gz
rm *.tar
rm package_2167367.xml  package_4811041.xml  package_5582016.xml  package_5676459.xml  package_5820628.xml
rm package_4800581.xml  package_5536541.xml  package_5676449.xml  package_5804087.xml  package_6435583.xml
rm heapdump.20171023.080953.16646144.0001.phd
rm hola00*.txt
rm Snap.20171023.080953.16646144.0003.trc
rm heapdump.20171023.080953.16646144.0001.phd
rm mbx10080.err
rm mxg2000_settings2013-08-13.sh
rm 2366063-131107-1624-008139-SetupMlcService.jar 2292759-130814-1612-793255-SetupMlcService.jar 2848411-150109-1821-379911-SetupMlcService.jar
rm EMail_38430147_51115217_1394531612015.xml EMail_38430147_51115448_1394531612015.xml event_2720198.xml arcHeap_201302251300.fin arcCore_201302251300.fin app_prod20140207.txt  appProd20131218.txt
rm mx3_launch*

#Todos los archivos de backup con fecha
find . -name "*.mxres*201*" | while read nxt ; do rm ${nxt} ;done
find . -name "*.sh*201*" | while read nxt ; do rm ${nxt} ;done

cd /murex/murex_app/app/mlc
rm logs20160628.tar.gz
rm logs20160727
rm logs.tar.gz
rm mlc_eod20160628.tar.gz
rm -r mlc_eod20160727
rm mlc_eod20161007.tar.gz

cd /murex/murex_app/app/eod_scripts
rm -r Viejos/
rm cache-warmup-xmlrequestscript.xml.120313
rm Depo_LIBORUSD_Diaria_20131218.txt
rm EXERCISE_PROCESS_B20111026.sh
rm header_pcenter_date_move.xml20150501
rm header_var_backteasting.xml20160318
rm header_var_backteasting.xml20160429
rm MLC_EXP_DATES_PS-20131013.sh
rm pcenter_date_move.xml20150501
rm var_backteasting.xml20160318
rm var_backteasting.xml20160429
rm  Fwd_AUDUSD_Diaria_20131218.txt
rm  Fwd_EURUSD_Diaria_20131218.txt
rm  Fwd_GBPUSD_Diaria_20131218.txt
rm  Fwd_USDBRL_Diaria_20131218.txt
rm  Fwd_USDCAD_Diaria_20131218.txt
rm  Fwd_USDCHF_Diaria_20131218.txt
rm  Fwd_USDDKK_Diaria_20131218.txt
rm  Fwd_USDJPY_Diaria_20131218.txt
rm  Fwd_USDMXN_Diaria_20131218.txt
rm  Fwd_USDSEK_Diaria_20131218.txt
rm -r logs

cd /murex/murex_app/app/fs
rm javacore.20170621.112719.15597688.0002.txt
rm javacore.20170621.112726.15597688.0006.txt
rm javacore.20170621.112726.15597688.0007.txt
rm javacore.20170621.145149.7536770.0003.txt
rm javacore.20170621.145149.7536770.0004.txt
rm javacore.20170621.145158.7536770.0008.txt
rm license20120225.tar.gz
rm license20130213.tar.gz
rm license20120328.tar.gz
rm license20120516.tar.gz
rm license20120719.tar.gz
rm license20130126.tar.gz
rm license20130313.tar.gz
rm license20130426.tar.gz
rm license2013o512.tar.gz
rm license20150327.tar.gz
rm license20150717.tar.gz
rm license20150729.tar.gz
rm license20150828.tar.gz
rm licensetmp20120401.tar.gz
rm Snap.20170621.112719.15597688.0003.trc
rm Snap.20170621.112726.15597688.0009.trc
rm Snap.20170621.145149.7536770.0005.trc
rm Snap.20170621.145149.7536770.0006.trc
rm Snap.20170621.145158.7536770.0009.trc


cd /murex/murex_app/app/fs/public/mxres
rm -r mxmlc-new-20110813-1019
rm -r mxsoaprelay-new-20110813-1019

cd /murex/murex_app/app/fs/public/mxres/script/assembly
rm execContextLabel.mxres20131122
rm execContext.mxres-new-20110813-1019
rm execContextLabel.mxres.20130813
rm execContextLabel.mxres-new-20110813-1019
rm install.mxres-new-20110813-1019

cd /murex/murex_app/app/fs/public/mxres/script/middleware
rm ajuste_contable_manual_sql.xml20131122
rm killMx.xml_20131027
rm killMx.xml20131122
rm killMx.xml_20131123
rm registros_despues.xml_20161124
rm registros_despues.xml20170407
rm remove_temp_dm.mxres20131122
rm remove_temp.mxres20131122
rm RTBStargets_CLOSE.xml20131122
rm RTBStargets_FIXING.xml20131122
rm RTBStargets_INTRADAY.xml20131122
rm RTBStargets_PTY.xml20131122
rm javacore.20170621.112719.15597688.0002.txt
rm javacore.20170621.112726.15597688.0006.txt
rm run_acc_audit_purge.xml_20131217
rm run_accounting_2.xml20131122
rm run_accounting_purge.xml20131122
rm run_accounting.xml20131122
rm run_acc_purge_anual.xml_20131217
rm run_acc_purge_mensual.xml_20131217
rm run_cierre_colombia_4_6.xml20131122
rm run_cierre_colombia_4.6.xml20131122
rm run_circular16.xml20131122
rm run_mxmlexchange_purge.xml_20131217
rm run_sql_var.xml20131122
rm sessioncheck.mxres20131122
rm sessioncheck.mxres-new-20110813-1019

cd /murex/murex_app/app/fs/public/mxres/common
rm launchergc.mxres.120313
rm launcherhss.mxres.old
rm launchergc20111026.mxres
rm launchermxactivityfeeders.mxres.new
rm launchermxactivityfeeders.mxres.old
rm launchermxdatapublisher.mxres.trc
rm launchermxrepository.mxres.pmo15532

cd /murex/murex_app/app/fs/public/mxres/common/dbconfig
rm mxservercredential20111026.mxres
rm mxservercredential.mxrespmo15532


cd /murex/murex_app/app/fs/public
find . -name "*.xml*201*" | while read nxt ; do rm ${nxt} ;done

#Carpetas con una gran cantidad de archivos los cuales no permite borrar por lo cual s eborra la carpeta y se crea nuevamente con los permisos correspondientes 750
rm -r /murex/murex_app/app/ProcessedFilesSF; mkdir /murex/murex_app/app/ProcessedFilesSF; chmod -R 750 /murex/murex_app/app/ProcessedFilesSF
rm -r /murex/murex_app/app/FWDPOS/BookedTrades; mkdir /murex/murex_app/app/FWDPOS/BookedTrades; chmod -R 750 /murex/murex_app/app/FWDPOS/BookedTrades
rm -r /murex/murex_app/app/FWDPOS/ErrorTrades; mkdir /murex/murex_app/app/FWDPOS/ErrorTrades; chmod -R 750 /murex/murex_app/app/FWDPOS/ErrorTrades
rm -r /murex/murex_app/app/FWDPOS/Processed; mkdir /murex/murex_app/app/FWDPOS/Processed; chmod -R 750 /murex/murex_app/app/FWDPOS/Processed
rm -r /murex/murex_app/app/SVE/ErrorFiles; mkdir /murex/murex_app/app/SVE/ErrorFiles; chmod -R 750 /murex/murex_app/app/SVE/ErrorFiles
rm -r /murex/murex_app/app/SVE/ProcessedFiles; mkdir /murex/murex_app/app/SVE/ProcessedFiles; chmod -R 750 /murex/murex_app/app/SVE/ProcessedFiles
rm -r /murex/murex_app/app/SCFPOS/ErrorXML; mkdir /murex/murex_app/app/SCFPOS/ErrorXML; chmod -R 750 /murex/murex_app/app/SCFPOS/ErrorXML
rm -r /murex/murex_app/app/mlc_reporting/datamart_extractions/ ; mkdir /murex/murex_app/app/mlc_reporting/datamart_extractions/ ; chmod -R 750 /murex/murex_app/app/mlc_reporting/datamart_extractions/ 
rm -r /murex/murex_app/app/delCpt/NOK/; mkdir /murex/murex_app/app/delCpt/NOK/; chmod -R 750 /murex/murex_app/app/delCpt/NOK/