#!/bin/bash

#########################################
# mx_protegerLogs.sh
# Descripcion                           Copia, tar y gzip los archivos de logs y otros al directorio de backups para
#					enviarlos a cinta
# Fecha de creacion                     2009/10/26
# Fecha de modificacion                 2015/12/XX
# Descripción Ultima Modificacion       Se modifican los respaldos de mlc_eod para tomar todos los logs
# Fecha de modificacion                 2014/03/28
# Descripción Ultima Modificacion       Se respaldan los scripts de inicio de Murex
# Fecha de modificacion                 2013/02/20
# Descripción Ultima Modificacion       Se comentarea los backup de los heap
# Fecha de modificacion                 2012/05/17
# Descripción Ultima Modificacion       Agregar archivos de los modulos propios al esquema de respaldos
# Fecha de modificacion                 2011/06/01
# Descripcion Ultima Modificacion       Se agrega respaldo de los logs de los procesos de EOD
# Fecha de modificacion			2010/06/03
# Descripcion Ultima Modificacion	Se comentarea la ejecucion del backup de los core files
# Fecha de modificacion                 2010/05/24
# Descripción Ultima Modificacion       Agregar archivos /tmp/mx*xml al esquema de respaldos
# Fecha de modificacion			2010/05/22
# Descripción Ultima Modificacion	Agregar archivos mx.*.log y mx.*.xml al esquema de respaldos
#########################################

strFecha=`date +"%Y%m%d%H%M"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
strFileName=MLC.$strFechaHora.tar.gz
strAppDirName=appDirPdn.$strFecha.tar.gz

echo "Empezando proceso de respaldos..."
cd $MUREX_HOME$MUREX_APP

echo "Moviendo logs de MLC para revision de Murex..."
cp logs/pbmdeapmur03.mxmlc.site1.public.mxres.common.launchermxmlc.mxres.log $MUREX_HOME/MLC
cp logs/mxmlc.gc.log $MUREX_HOME/MLC
cp -R logs/mxmlc/mxmlc/ $MUREX_HOME/MLC
cp logs/pbmdeapmur03.lrb.site1.public.mxres.common.launchermxlrb.mxres.log $MUREX_HOME/MLC
cp logs/mxlrb.gc.log $MUREX_HOME/MLC
cp -R logs/mxlrb/mxlrb/ $MUREX_HOME/MLC
cp mlc_histo.log $MUREX_HOME/MLC

echo "Moviendo archivo que se encuentra en /murex/murex_app/app/mlc/mlc_eod/logs/proxy de MLC proxy.log para revision de Murex..."
cp mlc/mlc_eod/logs/proxy/proxy.log $MUREX_HOME/MLC 
rm mlc/mlc_eod/logs/proxy/proxy.log
echo "Finalizo moviendo archivo que se encuentra en /murex/murex_app/app/mlc/mlc_eod/logs/proxy de MLC proxy.log para revision de Murex..."

tar -cpvf - $MUREX_HOME/MLC/ | gzip -9 -c > $MUREX_HOME/$strFileName
rm -r $MUREX_HOME/MLC/*

echo "Respaldando los scripts de manejo de Murex"
mx_backup.sh '$MUREX_HOME/scripts/*' mx_scripts_$strFecha

echo "Respaldando archivo limpos.log"
mx_backup.sh limpos.log limpos_log_$strFecha

echo "Respaldando archivos de /tmp/mlc*xml"
mx_backup.sh '/tmp/mlc*xml' arcTmpMlcXml_$strFecha
rm /tmp/mlc*xml

echo "Respaldando archivos de log mx.*.log"
mx_backup.sh 'mx.*.log' arcMxLog_$strFecha
rm mx.*.log

echo "Respaldando archivos de log mx.*.xml"
mx_backup.sh 'mx.*.xml' arcMxXml_$strFecha
rm mx.*.xml

echo "Respaldando los javacore como $strNombre..."
mx_backup.sh 'javacore*' arcJavacore_$strFecha
mx_backup.sh 'mlc/mlc_eod/javacore*.txt' javacoreMLC_$strFecha
rm javacore*
rm mlc/mlc_eod/javacore*.txt

#echo "Respaldando los heap..."
#mx_backup.sh 'heap*' arcHeap_$strFecha
#mx_backup.sh 'mlc/mlc_eod/heapdump*phd' arcHeapMLC_$strFecha
#rm heap*
#rm mlc/mlc_eod/heapdump*phd

echo "Respaldando los EngineReset..."
mx_backup.sh 'EngineReset*' arcEngineReset_$strFecha
rm EngineReset*

echo "Respaldando los archivos *err..."
mx_backup.sh '*err' errFiles_$strFecha
rm *err
#########################################################
#echo "Respaldando archivo Core..."
#mx_backup.sh 'core*' arcCore_$strFecha
#rm core*
#########################################################
echo "Respaldando archivos timing..."
mx_backup.sh '*mxtiming*' timing_$strFecha
rm *mxtiming* 

echo "Respaldando directorio de logs..."
mx_backup.sh logs/ logs_$strFecha
rm -rf logs/*

echo "Respaldando directorio de timings..."
mx_backup.sh timing/ dirTiming_$strFecha
rm -rf timing/*

echo "Respaldando Archivo MXCIB_TBI.txt..."
mx_backup.sh datamart_extractions/MXCIB_TBI.txt MXCIB_TBI_$strFecha

echo "Respaldando Archivos CONV_SEC_FIX_ERROR_"
mx_backup.sh CONV_SEC_FIX_ERROR_* CONV_SEC_FIX_ERROR_$strFecha

echo "Respaldando archivos de Logs del EOD"
mx_backup.sh 'eod_scripts/log_*xml' logs/eod_logs/logs_eod_$strFecha
mx_backup.sh 'eod_scripts/answers/*' logs/eod_logs/answers_eod_$strFecha
mx_backup.sh 'mlc/mlc_eod/eod_*.log' logs/eod_logs/logs_mlc_eod_$strFecha
#mx_backup.sh 'mlc/mlc_eod/reporting_eod_*.log' logs/eod_logs/logs_mlc_reporting_eod_$strFecha
#mx_backup.sh 'mlc/mlc_eod/reports_ctg_*.log' logs/eod_logs/logs_mlc_reports_ctg_$strFecha
mx_backup.sh 'mlc/mlc_eod/answers/*' logs/eod_logs/answers_mlc_eod_$strFecha
mx_backup.sh 'mlc/mlc_eod/*.log' logs/eod_logs/logs_mlc_eod_$strFecha #ret 02 validar los .log
mx_backup.sh 'mlc/mlc_eod/valores/*' logs/eod_logs/valores_mlc_eod_$strFecha  #ret 02 validar la carpeta valores 
rm mlc/mlc_eod/*.log
#rm mlc/mlc_eod/eod_*.log
#rm mlc/mlc_eod/reporting_eod_*.log
#rm mlc/mlc_eod/reports_ctg_*.log

######### Archivos Modulos propios  #####################

echo "Respaldando Archivos short..."
cp short* tmpshort
mx_backup.sh tmpshort/ shortFiles_$strFecha

echo "Respaldando Archivos taxmodule..."
mx_backup.sh taxmodule/ taxmodule_$strFecha

echo "Respaldando Archivos Impuestos..."
mx_backup.sh Impuestos/ Impuestos_$strFecha

echo "Respaldando Archivos valoracion..."
mx_backup.sh valoracion/ valoracion_$strFecha

echo "Respaldando Archivos MFC..."
mx_backup.sh MFC/ MFC_$strFecha

echo "Respaldando Archivos mfc..."
mx_backup.sh mfc/ mfc_$strFecha
rm -rf mfc/*

echo "Borrando archivos innecesarios..."
rm -rf Snap.*
rm -rf mlc/mlc_eod/Snap*
rm -rf dbx_commands.*

cd $BACKUP_DIR

mkdir logs/
mv *.tar.gz logs/

#echo "Respaldo de AppDir especial pedido por Murex"
#tar -cpvf - $MUREX_HOME$MUREX_APP | gzip -9 -c > $BACKUP_DIR/$strAppDirName

echo "Proceso terminado, archivos respaldados en la ruta de backup"
