#!/bin/bash
#File to copy
FL=/murex/scripts/lista.txt
RD=/murex/murex_app
# Path to SSH ID file (private key)
#ID=~/.ssh/id_rsa
# USERname to login as
USER=solivare
# HOST to login to
HOST=10.8.64.115
scp -p $FL $USER@$HOST:$RD/
