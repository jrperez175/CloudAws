#!/bin/sh

#########################################
# mx_respaldar.sh
# Descripcion                           Mueve el archivo indicado como parametro al directorio
#					$MUREX_HOME/old/DiaHoraMinuto para respaldarlo en caso de problemas cuando
# 					se modifique
# Parametro				$1 Nombre del archivo a respaldar
# Fecha de creacion                     2009/10/26
#########################################

strDirectorio=$MUREX_HOME/old/`date +"%Y%m%d%H%M"`

mkdir $strDirectorio

cp -p $1 $strDirectorio

echo "Archivo respaldado en ruta $strDirectorio"
ls -l $strDirectorio
