#!/bin/bash -l

#########################################
# MLCSube.sh
# Descripcion				Arranca los servicios de MLC
# Fecha de creacion			2009/10/26
# Fecha ultima modificacion		2009/12/02
# Descripcion ultima modificacion	Se le hace cd al directorio donde esta el archivo
#########################################

cd $MUREX_HOME$MUREX_APP

./launchmxj.app.64 -mlc /MXJ_FORCE_LAUNCHER_STARTUP:Y
./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launcherltsservice.mxres /MXJ_FORCE_LAUNCHER_STARTUP:Y
./launchmxj.app.64 -lrb /MXJ_FORCE_LAUNCHER_STARTUP:Y
./run_las_ssl.sh start
