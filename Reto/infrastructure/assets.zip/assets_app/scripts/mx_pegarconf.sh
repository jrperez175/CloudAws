#!/bin/bash

#restaura la configuracion en el ambiente



cp /murex/backup/conf/mxg2000_settings.sh /murex/murex_app/app
cp /murex/backup/conf/sites.mxres /murex/murex_app/app/fs/public/mxres/sites 
cp /murex/backup/conf/murexnet.mxres /murex/murex_app/app/fs/public/mxres/common/dbconfig
cp /murex/backup/conf/dbsource.mxres /murex/murex_app/app/fs/public/mxres/common/dbconfig
cp /murex/backup/conf/dbsourceoracle.mxres /murex/murex_app/app/fs/public/mxres/common/dbconfig
cp /murex/backup/conf/dbsource_rep.mxres /murex/murex_app/app/fs/public/mxres/common/dbconfig 
cp /murex/backup/conf/dbsource_mlc.mxres /murex/murex_app/app/fs/public/mxres/mxmlc/dbconfig 
cp /murex/backup/conf/mlc/dbsource.mxres /murex/murex_app/app/fs/public/mxres/mxmlc/dbconfig
cp /murex/backup/conf/mlc.mxres /murex/murex_app/app/fs/public/mxres/mxmlc 

cp /murex/backup/conf/broadcastmessage1.mxres /murex/murex_app/app/fs/public/mxres/script/middleware  
cp /murex/backup/conf/broadcastmessage2.mxres /murex/murex_app/app/fs/public/mxres/script/middleware  
cp /murex/backup/conf/broadcastmessage3.mxres /murex/murex_app/app/fs/public/mxres/script/middleware  
cp /murex/backup/conf/broadcastmessage4.mxres /murex/murex_app/app/fs/public/mxres/script/middleware 
cp /murex/backup/conf/broadcastmessage5.mxres /murex/murex_app/app/fs/public/mxres/script/middleware 

#cp /murex/backup/conf/launcherall.mxres  /murex/murex_app/app/fs/public/mxres/common
#cp /murex/backup/conf/launcherhss.mxres /murex/murex_app/app/fs/public/mxres/common
#cp /murex/backup/conf/launchergc.mxres  /murex/murex_app/app/fs/public/mxres/common
cp /murex/backup/conf/launchmlc.sh /murex/murex_app/app/mlc 
cp /murex/backup/conf/xmlrequestscript.sh /murex/murex_app/app/mxprocessingscript 
cp /murex/backup/conf/ps-xmlrequestscript.sh /murex/murex_app/app/mxprocessingscript 



#Archivos de claves

cp /murex/backup/conf/mxservercredential.mxres /murex/murex_app/app/fs/public/mxres/common/dbconfig/
cp /murex/backup/conf/eod_reset.xml /murex/murex_app/app/mlc/mlc_eod/
cp /murex/backup/conf/intraday_reset.xml /murex/murex_app/app/mlc/mlc_eod/
cp /murex/backup/conf/cptReporte4.xml /murex/murex_app/app/fs/public/mxres/mxmlc/scripts/
cp /murex/backup/conf/tradersReportes.xml /murex/murex_app/app/fs/public/mxres/mxmlc/scripts/
#cp /murex/backup/conf/mlc.mxres /murex/murex_app/app/fs/public/mxres/mxmlc
cp /murex/backup/conf/start_mxsoapregistry.mxres /murex/murex_app/app/fs/public/mxres/mxsoaprelay/
cp /murex/backup/conf/stop_mxsoapregistry.mxres /murex/murex_app/app/fs/public/mxres/mxsoaprelay/
cp /murex/backup/conf/startstopentitlements.mxres /murex/murex_app/app/fs/public/mxres/mxentitlement/

#Archivos de colas MQ

cd /murex/murex_app/app/fs
rm -r mqconfig

cp -r /murex/backup/conf/mqconfig /murex/murex_app/app/fs

#rm -r /murex/backup/conf 

#Chequeo de sesiones
cp /murex/backup/conf/sessioncheck.mxres /murex/murex_app/app/fs/public/mxres/script/middleware/

#Archivos de configuracion Bloomberg
cp /murex/backup/conf/bloomberg-properties.mxres /murex/murex_app/app/fs/public/mxres/mxinterfaces/bloomberg
cp /murex/backup/conf/rtbsbbg.properties /murex/murex_app/app/fs/public/mxres/mxinterfaces/bloomberg

