#!/bin/sh
# Copyright MUREX 2001.
# Murex: Nov  2002

MAJOR_VERSION=2
MINOR_VERSION=2


# Path to standard tools
VMSTATTOOL=/usr/bin/vmstat
UPTIMETOOL=/usr/bin/uptime

#delay is in seconds
DELAY=60
#DELAY=300
#DELAY=600
#DELAY=900


# Log files location
FILE_LOCATION=.
#FILE_LOCATION=/zephir/vol1/work/thomas/scripts/unix
MACHINE_NAME=`hostname`
DATE=`date | awk '{print $2"_"$3"_"$4}' | sed 's/:/_/g'`

VMSTAT_LOGFILE=$FILE_LOCATION/vmstat_${MACHINE_NAME}_${DATE}.log
UPTIME_LOGFILE=$FILE_LOCATION/uptime_${MACHINE_NAME}_${DATE}.log

help() {
        echo "$0: Usage:"
        echo "Version : $MAJOR_VERSION.$MINOR_VERSION"
        echo
        echo "	"`basename $0`" [-csv]"
        echo
}

csv() {
#set -x
for file in $FILE_LOCATION/uptime_*.log  
do 
   UPTIME_LOGFILE=$file
   echo "Converting $UPTIME_LOGFILE to $UPTIME_LOGFILE.csv\n"  
   echo "date;time;load last 1m;load last 5m;load last 15m;" >$UPTIME_LOGFILE.tmp
   cat $UPTIME_LOGFILE | awk '{  {i = NF;j = NF-1;k = NF-2 } print $1";"$2";"$k";"$j";"$i";"}' >>$UPTIME_LOGFILE.tmp
#for ,rather than . in excel
#cat $UPTIME_LOGFILE.tmp | sed s/\\./,/g >$UPTIME_LOGFILE.csv 
   cat $UPTIME_LOGFILE.tmp > $UPTIME_LOGFILE.csv 
   rm $UPTIME_LOGFILE.tmp
done
for file in $FILE_LOCATION/vmstat_*.log 
do 
  VMSTAT_LOGFILE=$file
   echo "Converting $VMSTAT_LOGFILE to $VMSTAT_LOGFILE.csv\n"  
   echo "date;time;proc in run queue;proc IO blocked;proc swapped;free swap;free real;swap-ins(per sec);swap-outs(per sec);cpu user;cpu sys;cpu idle;" > $VMSTAT_LOGFILE.tmp
  cat $VMSTAT_LOGFILE | grep -v date | awk '{ print $1 ";" $2  ";" $3  ";" $4  ";" $5  ";" $6 ";" $7  ";" $10  ";" $11  ";" $22  ";" $23 ";" $24 ";" }' >> $VMSTAT_LOGFILE.tmp
#cat $VMSTAT_LOGFILE.tmp | sed s/\\./,/g >$VMSTAT_LOGFILE.csv
  cat $VMSTAT_LOGFILE.tmp > $VMSTAT_LOGFILE.csv
  rm $VMSTAT_LOGFILE.tmp
done
exit 0
}
#set -x
ARG=$1
case $ARG in
            -help | /help | -h | /h )
                help
                exit 0
                ;;
            -csv )
		csv
                ;;
esac


if [ -f $VMSTAT_LOGFILE ]; then
        > $VMSTAT_LOGFILE
fi

#vmstat header
$VMSTATTOOL | head -2 | sed 's/^/date time /' >> $VMSTAT_LOGFILE

if [ -f $UPTIME_LOGFILE ]; then
	> $UPTIME_LOGFILE
fi

while true 
do
	MYDATE=`date '+%d/%m/%y	%H:%M:%S'`
	MYVMSTAT=`$VMSTATTOOL 5 2 | tail -1` 
	MYUPTIME=`$UPTIMETOOL | sed s/,//g | sed s/\ hr\(s\)/:00/g `

	echo $MYDATE	$MYUPTIME >> $UPTIME_LOGFILE
	echo $MYDATE	$MYVMSTAT >> $VMSTAT_LOGFILE

	sleep $DELAY
done
