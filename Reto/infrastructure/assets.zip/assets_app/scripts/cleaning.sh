#!/bin/sh
# MX.3 Cleaning Development environments Script
# Remember that the ParameterCleaning file must be in the same folder that cleaning.sh script
# Remembet to check that the ParametersCleaning file has information and its correct.
# Built By Sebastian Eraso Pena from Sophos Banking

TIMESTAMP=`date "+%Y%m%d_%H%M%S"`

cd /murex/murex_app/app/
ARCHIVO_LOG=/murex/logsRestauracion/cleaning_process_${TIMESTAMP}.log

cat /murex/scripts/ParametersCleaning | while read nxt ;
	do
		find . -name "$nxt" | while read bar ;
			do 
				rm "$bar"			
				echo -e "Se elimina el archivo $bar" >> $ARCHIVO_LOG
			done;
	done;
