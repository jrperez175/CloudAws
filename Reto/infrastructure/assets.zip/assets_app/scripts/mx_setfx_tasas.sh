#!/bin/bash -l

#########################################
# mx_setfx_tasas.sh
# Descripcion                           Carga el archivo de Tasas de SetFX una vez que el usuario 
#					sube el archivo al sistema
# Fecha de creacion                     2010/01/04
#Actualizaciones:
#2014/12/16:	Se reduce el tiempo de ejecucion del shell script hasta las 9 am, dado que esta generando inconvenientes de max runtime en OpCon. 
#				Para mas detalle verificar el Incidente 7154284
#########################################

i=0
j=0
h=0
/murex/scripts/festivo `date +"%d %m %Y"`
# if [ $? = 0 ]; then
if [ $? = 0 ]; then
	if [ -f /impyval/conf/setfx.xls ]; then
		cd /impyval/lib/
		./base-rates-set-fx.sh
		if [ $? = 0 ]; then
			if [ -f /impyval/conf/setfx.xls ]; then
				cd /impyval/conf/
				rm setfx.xls
			fi
			echo "Finaliza correctamente"
			h=1
			i=1
		else
			echo "Finaliza con errores"
			exit 1
		fi
	fi
	
	if [ $h -ne 1 ]; then
		dia=`date +%a`
		if [ $dia = "sat" -o $dia = "sun" ]; then
			echo "Finaliza por ser fin de semana"
			exit 0
		else
			echo "Finaliza con error, no hay archivo setfx.xls"
			exit 1
		fi
	fi
fi

