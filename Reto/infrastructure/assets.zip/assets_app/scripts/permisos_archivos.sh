#!/bin/bash

AMBIENT=/murex/
LOGS=/murex/scripts

cd $AMBIENT
while read LINE ; do
        if [ "$LINE" == "" ]
        then
                echo -e "\n\nLinea Vacia" > $LOGS/archivos_app.log
        else
		     chmod 0750 $LINE
             echo "Se actualizaron los permisos de la ruta:" $LINE
             echo "Se actualizaron los permisos de la ruta:" $LINE >> $LOGS/archivos_app.log
        fi
done < permisos_archivos

echo "Proceso de actualizacion de rutas app finalizado."