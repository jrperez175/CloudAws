#!/bin/ksh

#########################################
# mx_partir.sh
# Descripcion                           Parte el archivo que viene como parametro en partes de 200 MB
# Fecha de creacion                     2009/10/26
#########################################

split -b 200m $1
