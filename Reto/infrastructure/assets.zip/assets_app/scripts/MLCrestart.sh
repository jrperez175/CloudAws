#!/usr/bin/bash

cd /murex/murex_app/app
./launchmxj.app.64 -lrb -k
./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launcherltsservice.mxres -k
./launchmxj.app.64 -mlc -k
./run_las_ssl.sh stop
sleep 10
./launchmxj.app.64 -mlc /MXJ_FORCE_LAUNCHER_STARTUP:Y
./launchmxj.app -l /MXJ_CONFIG_FILE:public.mxres.common.launcherltsservice.mxres /MXJ_FORCE_LAUNCHER_STARTUP:Y
./launchmxj.app.64 -lrb /MXJ_FORCE_LAUNCHER_STARTUP:Y
./run_las_ssl.sh start