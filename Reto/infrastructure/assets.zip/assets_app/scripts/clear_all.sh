leaning Development environments Script when there is diferrent disks per environment
# Where they are just one disk per environemtn just use the cleaning.sh script with its configuration
#Build By Sebastian Eraso Pena from Sophos Banking

_central () {
	cd /murex/scripts/
	./cleaning.sh
 }
 
_business () {
	cd /murex/murex_app/app/
	cat servidores_BS | while read nxt; do ssh echo "" | ssh murex@${nxt} /murex/scripts/cleaning.sh; done
}

_mlc_var_NO_PERF () {
	cd /murex/murex_app/app/
	cat servidores_MLC | while read nxt; do ssh echo "" | ssh murex@${nxt} /murex/scripts/cleaning.sh; done
}

_mlc_var_PERF () {
	cd /murex/murex_app/app/
	cat servidores_MLC | while read nxt; do ssh echo "" | ssh murex@${nxt} /murex/scripts/cleaning.sh; done
	cat servidores_VAR | while read nxt; do ssh echo "" | ssh murex@${nxt} /murex/scripts/cleaning.sh; done
}

_todos () {
	cd /murex/scripts/
	./cleaning.sh
	cd /murex/murex_app/app/
	cat servidores_BS | while read nxt; do ssh echo "" | ssh murex@${nxt} /murex/scripts/cleaning.sh; done
	cat servidores_MLC | while read nxt; do ssh echo "" | ssh murex@${nxt} /murex/scripts/cleaning.sh; done
	cat servidores_VAR | while read nxt; do ssh echo "" | ssh murex@${nxt} /murex/scripts/cleaning.sh; done
 }
 
 
 _usage() {
              echo ''
			  echo " Usage: $0 start|restart_all|stop" 1>&2
			  echo ''
			  echo ' +-----------------------------------------------------------------------+'
			  echo ' |            Custom startup Global script for BANCOLOMBIA               |'
			  echo ' +-----------------------------------------------------------------------+'
			  echo ' | central	: Cleaning process on the main server						 |'
			  echo ' | bs		: Cleaning process on all business servers					 |'
			  echo ' | mv_np	: Cleaning process on all mlc/var servers different to a	 |'
			  echo ' |				Performance configuration								 |'
			  echo ' | mv_p		: Cleaning process on all mlc/var servers on Performance	 |'
			  echo ' | all		: Cleaning process on all servers							 |'
			  echo ' +-----------------------------------------------------------------------+'
			  echo ''
			  exit 1

}
# Mx Main
# =================================================================================
NAME=${0##*/} # Same as `basename $0`

case $NAME in

  (clear_all.sh) # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    case $1 in
      central)
        _central
      ;;
	  bs)
        _business
      ;;
	  mv_np)
        _mlc_var_NO_PERF
      ;;
	  mv_p)
        _mlc_var_PERF
      ;;
	  all)
        _todos
      ;;
	  
      *)
       _usage
      ;;
   esac
esac
