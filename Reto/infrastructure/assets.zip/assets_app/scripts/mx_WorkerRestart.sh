#!/bin/bash -l

cd /murex/murex_app/app

hostname=`hostname`
i=0
         while [ $i -lt 40 ]
                 do
                      error=`cat /murex/murex_app/app/logs/$hostname.mxmlworker.site1.public.mxres.common.launchermxmlworker.mxres.log | grep "java/lang/OutOfMemoryError" | wc -l`
                      if [ $error -ne 0 ] ; then
                              echo
                              echo "Se encontraron $error mensajes de error java"
                              echo
                              ./launchmxj.app -xmlreq /MXJ_CONFIG_FILE:stopworkflow.xml
                              ./launchmxj.app -mxmlworker -k
                              mv /murex/murex_app/app/logs/$hostname.mxmlworker.site1.public.mxres.common.launchermxmlworker.mxres.log /murex/murex_app/app/logs/$hostname.mxmlworker.site1.public.mxres.common.launchermxmlworker.mxres.log.old
                              mv /murex/murex_app/app/logs/mxmlworker.gc.log /murex/murex_app/app/logs/mxmlworker.gc.log.old
                              ./launchmxj.app -mxmlworker /MXJ_FORCE_LAUNCHER_STARTUP:Y
                              ./launchmxj.app -xmlreq /MXJ_CONFIG_FILE:startworkflow.xml
                      i=41
                      else
                      echo "Se encontraron $error mensajes de error java"
                      sleep 60
                      i=`expr $i + 1`
                      fi

                done

