#!/bin/bash

#DIAS DE RETENCION
DIAS_A_RETENER=2

#RUTA LIMPIAR
RUTA_LIMPIAR="/murex/murex_app/app"

#RUTA DESTINO
RUTA_DESTINO="/murex/scripts"

if [ ! [ "$DIAS_A_RETENER" -eq "$DIAS_A_RETENER" ] ]  2>/dev/null;
then
        echo "DIAS_A_RETENER no es un día válido"
        exit 1
fi

if [ ! -d "$RUTA_LIMPIAR" ] ;
then
        echo "RUTA_LIMPIAR no es una ruta válida"
        exit 1
fi

if [ ! -d "$RUTA_DESTINO" ] ;
then
        echo "RUTA_DESTINO no es una ruta válida"
        exit 1
fi

date=`date +"%Y%m%d"`

for archivo in $(find $RUTA_LIMPIAR -type f -name "core.*" -mtime +$DIAS_A_RETENER);
do
        echo $archivo
        echo $date
        #ar -zcvf $RUTA_DESTINO/compres_core_file_$date.tar $archivo
        rm $archivo
done

