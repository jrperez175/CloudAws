#!/bin/bash -l

#########################################
# mx_lanzarMxPdn.sh
# Descripcion                           Sube / Baja Murex segun el servidor que se le pase como parametro
# Parametros				$1 Accion (start|stop|restart)
#					$2 hostname
# Fecha de creacion                     2009/10/26
# Fecha ultima modificacion             2011/06/03
# Descripcion modificacion              Se a�ade la proteccion del log del gc de MLC renombrando el archivo con fecha y hora
# Fecha ultima modificacion             2009/12/11
# Descripcion ultima modificacion	Se coloca la hora en todos los mensajes que el script hace echo
# Fecha ultima modificacion		2009/12/02
# Descripcion ultima modificacion       Se adicionan los servidores horizontales pbmdeapmur10 y pbmdeapmur12 
# Fecha ultima modificacion             2012/05/14
# Descripcion ultima modificacion	Antes de remover los logs se copian los de MLC a otro directorio
#					para enviar a Murex en la ma#ana
# Fecha ultima modificacion             2015/04/09
# Descripcion ultima modificacion       Incluir nueva horizontal para Banitsmo
#########################################

strFechaHora=`date +"%Y%m%d-%H%M%S"`
cd $MUREX_HOME$MUREX_APP

case $1 in
	start)
		case $2 in
			pbmdeapmur03)
				./mx3_launchallfs.sh start
				;;
			pbmdeapmur04)
				./mx3_launchallhss.sh start $2
				;;
			pbmdeapmur05)
				./mx3_launchallhss.sh start $2
				;;
			pbmdeapmur11)
				./mx3_launchallhss.sh start $2
				;;
			pbmdeapmur08)
                                ./mx3_launchallhss.sh start $2
                                ;;
			pbmdeapmur09)
                                ./mx3_launchallhss.sh start $2
                                ;;
                        pbmdeapmur10)
                                ./mx3_launchallhss.sh start $2
                                ;;
                        pbmdeapmur12)
                                ./mx3_launchallhss.sh start $2
                                ;;
                       pbmdebpmur14)
                              ./mx3_launchallhss.sh start $2
                                ;;
 
			*)
				echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Usage: $0 (start|stop|restart) machineName"
				exit 1
		esac
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Servicio Subir Murex en $2 finalizado"
		;;
	stop)
                case $2 in
                        pbmdeapmur03)
                                ./mx3_launchallfs.sh stop
		                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Removiendo archivos y logs"
				mx_protegerLogs.sh
                                ;;
                        pbmdeapmur04)
                                ./mx3_launchallhss.sh stop $2
                                ;;
                        pbmdeapmur05)
                                ./mx3_launchallhss.sh stop $2
                                ;;
                        pbmdeapmur11)
                                ./mx3_launchallhss.sh stop $2
                                ;;
                        pbmdeapmur08)
                                ./mx3_launchallhss.sh stop $2
                                ;;
                        pbmdeapmur09)
                                ./mx3_launchallhss.sh stop $2
                                ;;
                        pbmdeapmur10)
                                ./mx3_launchallhss.sh stop $2
                                ;;
                        pbmdeapmur12)
                                ./mx3_launchallhss.sh stop $2
                                ;;
                       pbmdebpmur14)
                                ./mx3_launchallhss.sh stop $2
                                ;;
                        *)
                                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Usage: $0 (start|stop|restart) machineName"
                                exit 1
                esac
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Cerrando sesiones y procesos fantasma"
		ps -aef | grep 10000 | awk {'print $2'} | xargs kill -9
		ps -aef | grep 10080 | awk {'print $2'} | xargs kill -9
		ps -aef | grep 10090 | awk {'print $2'} | xargs kill -9
		ps -aef | grep 10091 | awk {'print $2'} | xargs kill -9
		ps -aef | grep 10099 | awk {'print $2'} | xargs kill -9

		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Servicio Bajar Murex en $2 finalizado"
		;;
	restart)
		case $2 in
			pbmdeapmur03)
				./mx3_launchallfs.sh stopnopurge
       			        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Cerrando sesiones y procesos fantasma"
		                ps -aef | grep 10000 | awk {'print $2'} | xargs kill -9
                		ps -aef | grep 10080 | awk {'print $2'} | xargs kill -9
		                ps -aef | grep 10090 | awk {'print $2'} | xargs kill -9
                		ps -aef | grep 10091 | awk {'print $2'} | xargs kill -9
		                ps -aef | grep 10099 | awk {'print $2'} | xargs kill -9

				mv logs/mxmlc.gc.log logs/mxmlc.gc.$strFechaHora.log

				sleep 10
				
				echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Reiniciando Murex en $2"

				./mx3_launchallfs.sh start
				;;
			*)
                                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Usage: $0 (start|stop|restart) machineName"
                                exit 1
                esac
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Servicio Reiniciar Murex en $2 finalizado"
                ;;
		
	*)
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - Usage: $0 (start|stop|restart) machineName"
                exit 1
esac

