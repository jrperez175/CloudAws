#!/bin/bash

#find /murex/murex_app/app -type d -exec du -Sh {} + | sort -rh | head -n 10 > /murex/murex_app/listado_tamaño.txt
find /murex/murex_app/app -type d -exec ls -lrt {} \; | sort -n | head  -n 100 > /murex/murex_app/listado_tamaño.txt
