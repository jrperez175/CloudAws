#!/bin/bash -l

#########################################
# mx_borrarMLCLogs.sh
# Descripcion				Borra los log de MLC de la ruta /murex 
# Fecha de creacion                     2010/01/07
#########################################

cd $MUREX_HOME
mv MLC*tar.gz $BACKUP_DIR/logs/

