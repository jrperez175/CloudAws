#!/bin/bash

cd $MUREX_HOME$MUREX_APP

strFecha=`date +"%Y%m%d%H%M"`
FechaHora=`date +"%Y%m%d-%H%M%S"`
strFileName=MLC.$strFechaHora.tar.gz
strAppDirName=appDirPdn.$strFecha.tar.gz
mx_backup.sh 'eod_scripts/log_*xml' logs/eod_logs/logs_eod_$strFecha
mx_backup.sh 'eod_scripts/answers/*' logs/eod_logs/answers_eod_$strFecha
mx_backup.sh 'mlc/mlc_eod/eod_*.log' logs/eod_logs/logs_mlc_eod_$strFecha
mx_backup.sh 'mlc/mlc_eod/answers/*' logs/eod_logs/answers_mlc_eod_$strFecha


