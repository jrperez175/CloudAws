#!/bin/bash

cd /murex/murex_app/app
./launchmxj.app -s > /murex/backup/servicios.txt
