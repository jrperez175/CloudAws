#!/bin/bash -l

cd /murex/murex_app/app
hostname=`hostname`
i=0
    while [ $i -lt 2 ]
        do
strFecha=`date +"%Y%m%d"`
            date >> /murex/proceso/ping.$strFecha.log
            ping -c 2 10.25.5.115 >> /murex/proceso/ping.$strFecha.log
                if [ $? = 0 ]; then
                      echo  "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $0 - se ejecuta ping" >> /murex/proceso/ping.$strFecha.log 
                else
                      echo  "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $0 - se perdio comunicacion" >> /murex/proceso/ping.$strFecha.log 
                fi
        done
