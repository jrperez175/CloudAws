#!/bin/bash -l

#########################################
# mx_inicioCierre.sh
# Descripcion                           Baja los horizontales, el middleware
#					Sube el middleware y el 04 para el cierre
# Fecha de creacion                     2009/10/26
# Fehca de modificacion                 2009/01/06
# Descripcion modificacion		Se a�ade invocacion al script de mx_preIniSube para ejecutar cosas
#					adicionales antes de subir el ambiente para el cierre
# Fecha modificacion                    2013/02/20
# Descripcion modificacion              Se a�ade el manejo de matar las horizontales en caso de pasar 10 minutos sin responder
# Fecha de modificacion			2010/01/04
# Descripcion modificacion		Se a�ade invocacion al script de mx_preInicio para ejecutar cosas
#					adicionales antes del cierre
#
# Fecha modificacion                    2014/04/03
# Descripcion de modificacion           Inclusion script para inicio de workflows para empezar el cierre
#########################################

declare -i numArchivos
declare -i numEspera

cd $MUREX_HOME/proceso
strFecha=`date +"%Y%m%d"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
hostname=`hostname`
strFileName=$hostname.$strFecha.log
strLock=$hostname.mx_cierre.lock

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Inicio de cierre" >> $strFileName

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Verificando y ejecutando precondiciones para bajar" >> $strFileName
mx_preInicio.sh

if [ ! -f $MUREX_HOME/proceso/serversCluster.txt ]; then
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCluster.txt no existe" >> $strFileName
	exit 1
elif [ ! -r $MUREX_HOME/proceso/serversCluster.txt ]; then
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCluster.txt no se puede leer" >> $strFileName
	exit 2
fi

if [ ! -f $MUREX_HOME/proceso/serversCierre.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCierre.txt no existe" >> $strFileName
        exit 3
elif [ ! -r $MUREX_HOME/proceso/serversCierre.txt ]; then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Archivo $MUREX_HOME/proceso/serversCierre.txt no se puede leer" >> $strFileName
        exit 4
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando parar Murex en las horizontales" >> $strFileName

numServersCluster=`wc -l < serversCluster.txt`
numServersCierre=`wc -l < serversCierre.txt`

while read LINE ; do
        touch $LINE.stop
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando parar Murex en la $LINE" >> $strFileName
done < serversCluster.txt

numEspera=0

while [ $numEspera -lt 10 ]
do
	numArchivos=0

	while read LINE ; do
        	if [ -e $LINE.down ]
        	then
                	let numArchivos++
        	fi
	done < serversCluster.txt

        if [ $numArchivos -eq $numServersCluster ]
        then
                numEspera=11
        else
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud, han parado $numArchivos horizontales" >> $strFileName
                let numEspera++
                sleep 60
        fi
done

if [ $numEspera -eq 10 ]
then
        while read LINE ; do
                touch $LINE.kill
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Solicitando MATAR Murex en la $LINE" >> $strFileName
        done < serversCluster.txt

        numEspera=0
        while [ $numEspera -lt 3 ]
        do
                numArchivos=0

                while read LINE ; do
                        if [ -e $LINE.kill ]
                        then
                                let numArchivos++
                        fi
                done < serversCluster.txt

                if [ $numArchivos -eq 0 ]
                then
                        numEspera=4
                else
                        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud de matar, no han parado $numArchivos horizontal
es" >> $strFileName
                        let numEspera++
                        sleep 60
                fi
        done
        if [ $numEspera -eq 3 ]
        then
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - No bajo el sistema en las horizontales - Solo bajaron $numArchivos servidores" >> $strFileName
                ls -lrt *.down >> $strFileName
                exit 3

        fi
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Bajando el Middleware Server" >> $strFileName
mx_lanzarMxPdn.sh stop $hostname
touch $hostname.down
sleep 10

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Verificando y ejecutando precondiciones inicio" >> $strFileName
mx_preIniSube.sh

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Subiendo el Middleware Server" >> $strFileName
mx_lanzarMxPdn.sh start $hostname
touch $hostname.up
rm $hostname.down

while read LINE ; do
        touch $LINE.start
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Esperando el $LINE para iniciar el cierre..." >> $strFileName
done < serversCierre.txt

numEspera=0
while [ $numEspera -lt 10 ]
do
        numArchivos=0

        while read LINE ; do
                if [ -e $LINE.up ]
                then
                        let numArchivos++
                fi
        done < serversCierre.txt

        if [ $numArchivos -eq $numServersCierre ]
        then
                numEspera=11
        else
                echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $numEspera minuto(s) tras la solicitud de subir para el cierre" >> $strFileName
                let numEspera++
                sleep 60
        fi
done

if [ $numEspera -eq 10 ]
then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - ABORTA POR TIEMPO **** No subio el sistema en el pbmdeapmur04" >> $strFileName
        ls -lrt *.up >> $strFileName
        exit 6
fi

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Subiendo Proceso Workflows para inicio cierre" >> $strFileName

cd $MUREX_HOME/murex_app/app/mxprocessingscript; ./xmlprocessingscript_xmlreq_startAll.sh; cd -

touch $strLock
echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - Todo listo para empezar el cierre" >> $strFileName
exit 0

