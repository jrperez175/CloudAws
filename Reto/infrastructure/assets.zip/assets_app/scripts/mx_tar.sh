#!/bin/bash

#########################################
# mx_tar.sh
# Descripcion                           Comprime el archivo / ruta enviado por parametro y lo deja con un nombre
# Parametros				$1 archivo / ruta a comprimir
#					$2 Nombre del archivo (sin extension tar.gz) donde se dejara la informacion
# Fecha de creacion                     2009/10/26
#########################################

tar -cpvf - $1 | gzip -9 -c > $2.tar.gz
