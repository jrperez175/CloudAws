#!/bin/bash -l

#########################################
# mx_manejarCore.sh
# Descripcion                           Copia, tar y gzip los archivos core generados durante el dia para 
#					enviarlos a cinta
# Fecha de creacion                     2010/03/17
# Fecha de modificacion			2013/02/20
#					Se a#aden en el script los respaldos del heap del appdir y de mlc
#########################################

strFecha=`date +"%Y%m%d%H%M"`
strFechaHora=`date +"%Y%m%d-%H%M%S"`
strFechaArchivo=`date +"%Y%m%d"`
hostname=`hostname`
strFileName=$MUREX_HOME/proceso/$hostname.$strFechaArchivo.log

echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Manejar Core" >> $strFileName

cd $MUREX_HOME$MUREX_APP

cores=`ls core* | wc -l`

if [ $cores -ne 0 ]
then
 	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Respaldando archivos Core..." >> $strFileName
        if [ -e core ]
        then
		mv core core.dmp
        fi
	mx_backup.sh 'core*' arcCore_$strFecha
 	rm core*
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Proceso terminado, archivos respaldados en la ruta de backup" >> $strFileName
else
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - No hay archivos core para respaldar" >> $strFileName
fi

numHeap=`ls heap* | wc -l`

if [ $numHeap -ne 0 ]
then
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Respaldando los heap..." >> $strFileName
	mx_backup.sh 'heap*' arcHeap_$strFecha
	rm heap*
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Proceso terminado, archivos respaldados en la ruta de backup" >> $strFileName
else
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - No hay archivos heap para respaldar" >> $strFileName
fi

numHeap=`ls mlc/mlc_eod/heapdump* | wc -l`

if [ $numHeap -ne 0 ]
then
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Respaldando los heap de MLC..." >> $strFileName
	mx_backup.sh 'mlc/mlc_eod/heapdump*phd' arcHeapMLC_$strFecha
	rm mlc/mlc_eod/heapdump*phd
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Proceso terminado, archivos respaldados en la ruta de backup" >> $strFileName
else
	echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - No hay archivos heap de MLC para respaldar" >> $strFileName
fi

numHeap=`ls javacore* | wc -l`

if [ $numHeap -ne 0 ]
then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Respaldando los javacore..." >> $strFileName
        mx_backup.sh 'javacore*' arc_javacore$strFecha
        rm javacore*
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Proceso terminado, archivos respaldados en la ruta de backup" >> $strFileName
else
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - No hay archivos javacore para respaldar" >> $strFileName
fi

numHeap=`ls Snap* | wc -l`

if [ $numHeap -ne 0 ]
then
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Respaldando los Snap..." >> $strFileName
        mx_backup.sh 'Snap*' arc_Snap$strFecha
        rm Snap*
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Proceso terminado, archivos respaldados en la ruta de backup" >> $strFileName
else
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - No hay archivos Snap para respaldar" >> $strFileName
fi


echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Manejar Core" >> $strFileName


cd mlc/mlc_eod/

numHeap=`ls core.*.dmp | wc -l`

if [ $numHeap -ne 0 ]

then
		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Respaldando los core*..." >> $strFileName
		mx_backup.sh 'core.*.dmp' logs/eod_logs/core_mlc_eod_$strFecha
		rm core.*.dmp

 		echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex - $hostname - $0 - Proceso terminado, archivos respaldados en la ruta de backup" >> $strFileName
else
        echo "[`date +"%Y/%m/%d %H:%M:%S"`] - Murex -  $hostname - $0 - No hay archivos core.*.dmp para respaldar" >> $strFileName
fi
