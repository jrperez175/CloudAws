
export env=${1}
export EC2_INSTANCE_ID="`wget -q -O - http://169.254.169.254/latest/meta-data/instance-id || die \"wget instance-id has failed: $?\"`"
export MUREX_ROLE=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$EC2_INSTANCE_ID" "Name=key,Values=bancolombia:murex_role" --query 'Tags[].{Value:Value}' --output text)

export INSTALLCONTROLM=/var/log/controlm-installation.log
{
if [ "$MUREX_ROLE" == 'orchestrator' ]; then
  #Creando Usuario y Grupo para control M
  groupadd svcpbca9
  useradd -d /opt/data/svcpbca9 -c "usuario agente controlm" -s /bin/bash -g svcpbca9 svcpbca9
  #Directorio de instalacion
  mkdir /opt/data
  mkdir /opt/data/svcpbca9
  mkdir /opt/data/svcpbca9/instaladores
  chmod 755 /opt/data
  #Descarga de instalador
  aws s3 cp s3://controlm-ap0001001-control-m-${env}-s3-instaladores/${env}/linux/DRKAI.z /opt/data/svcpbca9/instaladores/DRKAI.z
  #Descarga de parametrizador de instalador
  aws s3 cp s3://controlm-ap0001001-control-m-${env}-s3-instaladores/${env}/linux/instalador.xml /opt/data/svcpbca9/instaladores/instalador.xml
  #Descomprimir instalador
  cd /opt/data/svcpbca9/instaladores
  tar -xzvf DRKAI.z
  chown -R svcpbca9:svcpbca9 /opt/data
  #Intalacion del agente
  su - svcpbca9 -c "/opt/data/svcpbca9/instaladores/setup.sh -silent /opt/data/svcpbca9/instaladores/instalador.xml"
  su - svcpbca9 -c "/opt/data/svcpbca9/ctm/scripts/shut-ag -u svcpbca9 -p ALL"
  #Subir agente como root
  cd /opt/data/svcpbca9/ctm/scripts/
  echo -e "\n\nY" | ./start-ag
fi
} | tee "$INSTALLCONTROLM"
