#!/bin/bash

set -x

env=${1}
envmurex=${2}
projectcode=${3}
projectname=${4}

groupadd -g 523 grpcnxusers
useradd -u 641 cnxgpmrx -g murex -G grpcnxusers -s /bin/bash -c "Usuario de Sterling"

if [ "$env" == 'pdn' ]; then
  groupadd -g 523 grpcnxusers
  useradd -u 530 cnxtpval -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 531 cnxtpmur -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 532 cnxtpwas -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 533 cnxtpdet -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 534 cnxtpbbg -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 535 cnxtpebs -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 536 cnxtppmx -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 537 cnxtptmx -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 538 cnxptval -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 539 cnxtpmlc -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 540 cnxfpmml -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 541 cnxtpbmo -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 542 cnxtpidc -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 543 cnxtpsia -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 561 cnxfpmur -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 562 cnxpdsml -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 563 cnxtpifr -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 622 cnxtpswp -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 627 cnxsqmrx -g grpcnxusers -s /sbin/nologin
  useradd -u 630 cnxtpmrx -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 632 cnxtpmux -g murex -G grpcnxusers -s /sbin/nologin
  useradd -u 636 cnxiplnx -g grpcyberark -s /bin/bash -c "Usuario Conexion Identidades Privilegiadas CyberArk"
fi
if [ "$env" == 'dev' ]; then
  useradd -u 701 dcnxsintd -g murex -G grpcnxusers -s /sbin/nologin -c "Usuario de DataStage"
fi


#importar llaves cnxgpmrx
mkdir /home/cnxgpmrx/.ssh
aws secretsmanager get-secret-value --secret-id ${projectcode}-${projectname}-${env}-${envmurex}-secrets-SecretEc2  --query SecretString --output text|jq -r '.id_pri_rsa_cnxgpmrx' | base64 -d  > /home/cnxgpmrx/.ssh/id_rsa
chmod 600  /home/cnxgpmrx/.ssh/id_rsa
ssh-keygen -e -m 'RFC4716' -f /home/cnxgpmrx/.ssh/id_rsa  > /home/cnxgpmrx/.ssh/id_rsa_temp_ASCII
ssh-keygen -i -m 'RFC4716' -f /home/cnxgpmrx/.ssh/id_rsa_temp_ASCII  > /home/cnxgpmrx/.ssh/id_rsa.pub
aws secretsmanager get-secret-value --secret-id ${projectcode}-${projectname}-${env}-${envmurex}-secrets-SecretEc2  --query SecretString --output text|jq -r '.id_pub_rsa_cnxgdmre' >> /home/cnxgpmrx/.ssh/authorized_keys
cat /home/cnxgpmrx/.ssh/id_rsa.pub  >> /home/cnxgpmrx/.ssh/authorized_keys
echo -e  "Host * \n StrictHostKeyChecking no" > /home/cnxgpmrx/.ssh/config
chmod 400 /home/cnxgpmrx/.ssh/config
chown -R cnxgpmrx:murex /home/cnxgpmrx/.ssh
