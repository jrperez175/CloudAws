mxg2000=/murex/murex_app/app/mxg2000_settings.sh
if test -f "$mxg2000"; then
  patern="MXJ_FILESERVER_HOST="
  hoster=`grep $patern /murex/murex_app/app/mxg2000_settings.sh`
  len_patern=`expr length "$patern"`
  len_hoster=`expr length "$hoster"`
  total=`expr $len_patern + 1`
  old_host=`echo $hoster | cut -c"$total"-"$len_hoster"`
  echo $old_host
  new_host=`hostname`
  echo $new_host
  app_home=/murex/murex_app/app
  echo $app_home
  if [ ! -z "$old_host" ] && [ ! -z "$new_host" ] && [ -d "$app_home" ]; then
    echo "Procesing, just wait"
    a=1
    for y in `find /murex/murex_app/app \( -name '*.sh' -o -name '*.mxres' -o -name '*.properties' \) -exec grep -irl $old_host {} \;`;
    do
      sed "s/$old_host/$new_host/g" $y > temp;
      mv temp $y;
      awk 'BEGIN {printf "\r Files done : %d",'$a'}';
    done;
    echo "Hostname replaced or rewrited successfully"
  else
    echo "Not processed the new host";
  fi;
fi;
new_host_ip=`hostname -I | awk -F '"' '{print $1}' | xargs`
echo $new_host_ip
new_host=`hostname`
echo $new_host
if test -f "/murex/impyval/lib/environment.xml"; then
  old_name_value=$(xmllint --xpath "string(//environments/env/hostName)" /murex/impyval/lib/environment.xml)
  sed -i -E "s/<hostName>$old_name_value<\/hostName>/<hostName>$new_host<\/hostName>/g" /murex/impyval/lib/environment.xml
  old_host_ip=$(xmllint --xpath "string(//environments/env/ip)" /murex/impyval/lib/environment.xml)
  sed -i -E "s/<ip>$old_host_ip<\/ip>/<ip>$new_host_ip<\/ip>/g" /murex/impyval/lib/environment.xml
  echo "Hostname replaced is completed in /murex/impyval/lib/environment.xml"
else
  echo "Nothing done for /murex/impyval/lib/environment.xml"  
fi;
if test -f "/murex/mfc-module/environment.xml"; then
  old_name_value=$(xmllint --xpath "string(//environments/env/hostName)" /murex/mfc-module/environment.xml)
  sed -i -E "s/<hostName>$old_name_value<\/hostName>/<hostName>$new_host<\/hostName>/g" /murex/mfc-module/environment.xml
  old_host_ip=$(xmllint --xpath "string(//environments/env/ip)" /murex/mfc-module/environment.xml)
  sed -i -E "s/<ip>$old_host_ip<\/ip>/<ip>$new_host_ip<\/ip>/g" /murex/mfc-module/environment.xml
  echo "Hostname replaced is completed in /murex/mfc-module/environment.xml"
else
  echo "Nothing done for /murex/mfc-module/environment.xml"  
fi;
if test -f "/murex/VALMODULE-BSMO/environment.xml"; then
  old_name_value=$(xmllint --xpath "string(//environments/env/hostName)" /murex/VALMODULE-BSMO/environment.xml)
  sed -i -E "s/<hostName>$old_name_value<\/hostName>/<hostName>$new_host<\/hostName>/g" /murex/VALMODULE-BSMO/environment.xml
  old_host_ip=$(xmllint --xpath "string(//environments/env/ip)" /murex/VALMODULE-BSMO/environment.xml)
  sed -i -E "s/<ip>$old_host_ip<\/ip>/<ip>$new_host_ip<\/ip>/g" /murex/VALMODULE-BSMO/environment.xml
  echo "Hostname replaced is completed in /murex/VALMODULE-BSMO/environment.xml"
else
  echo "Nothing done for /murex/VALMODULE-BSMO/environment.xml"  
fi;
if test -f "/murex/VALUATION-MODULE/environment.xml"; then
  old_name_value=$(xmllint --xpath "string(//environments/env/hostName)" /murex/VALUATION-MODULE/environment.xml)
  sed -i -E "s/<hostName>$old_name_value<\/hostName>/<hostName>$new_host<\/hostName>/g" /murex/VALUATION-MODULE/environment.xml
  old_host_ip=$(xmllint --xpath "string(//environments/env/ip)" /murex/VALUATION-MODULE/environment.xml)
  sed -i -E "s/<ip>$old_host_ip<\/ip>/<ip>$new_host_ip<\/ip>/g" /murex/VALUATION-MODULE/environment.xml
  echo "Hostname replaced is completed in /murex/VALUATION-MODULE/environment.xml"
else
  echo "Nothing done for /murex/VALUATION-MODULE/environment.xml"  
fi;
echo "Hostname replace is done in modules"