#!/bin/bash

set -x

asgname=$(aws ssm get-parameters --name aw0434001-murex-core-env-envmurex-asg-business-parameter-name-asg --query 'Parameters[0].Value' --output text)
minsize=$(aws ssm get-parameters --name aw0434001-murex-core-env-envmurex-asg-business-parameter-minsize-after-closing --query 'Parameters[0].Value' --output text)
maxsize=$(aws ssm get-parameters --name aw0434001-murex-core-env-envmurex-asg-business-parameter-maxsize-after-closing --query 'Parameters[0].Value' --output text)


asg=$(aws autoscaling describe-auto-scaling-groups --query 'AutoScalingGroups[].[AutoScalingGroupName]' --output text  | grep $asgname)
aws autoscaling update-auto-scaling-group --auto-scaling-group-name $asg --min-size $minsize --max-size $maxsize --desired-capacity $minsize

echo "Orden de escalamiento lanzada..."
sleep 40

while :
do

        status=$(aws autoscaling describe-auto-scaling-groups --auto-scaling-group-name $asg --query 'AutoScalingGroups[0].Instances[].{LifecycleState:LifecycleState,InstanceId:InstanceId}' --output text | awk '{print $1}' | while read line; do aws ec2 describe-instance-status --instance-id $line  --query "InstanceStatuses[0].{Name:InstanceState.Name,sstatus:SystemStatus.Status,istatus:InstanceStatus.Status}" --output text | awk '{print $2}'; done)

        statusok=true

        for i in ${status// / }
        do
                if [[ $i != 'ok' ]]; then
                        statusok=false
                        echo "Servicios subiendo..."
                        sleep 5
                        echo $status
                fi
        done

        if $statusok ; then
           echo "Servicios Activos"
           break
        fi
done
