#!/bin/bash
# configuracion agente CW y Logs Groups
set -x
export stackname=${1}
export servername=${2}
export loggroupretention=${3}
export env=${4}
export AGENT_CW_LOG=/var/log/cw-installation.log
export EC2_INSTANCE_ID="`wget -q -O - http://169.254.169.254/latest/meta-data/instance-id || die \"wget instance-id has failed: $?\"`"
export MUREX_ENVIRONMENT=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$EC2_INSTANCE_ID" "Name=key,Values=bancolombia:murex_environment" --query 'Tags[].{Value:Value}' --output text)
export MUREX_ROLE=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$EC2_INSTANCE_ID" "Name=key,Values=bancolombia:murex_role" --query 'Tags[].{Value:Value}' --output text)
export MUREX_PMO=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$EC2_INSTANCE_ID" "Name=key,Values=bancolombia:pmo" --query 'Tags[].{Value:Value}' --output text)
export HOSTNAME=$(hostname)

echo -e "{
  \"logs\": {
    \"logs_collected\": {
      \"files\": {
        \"collect_list\": [
          {
            \"file_path\": \"/var/log/messages\",
            \"log_group_name\": \"/${stackname}/messages\",
            \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
          },
          {
            \"file_path\": \"/var/log/boot.log\",
            \"log_group_name\": \"/${stackname}/boot\",
            \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
          },
          {
            \"file_path\": \"/opt/aws/amazon-cloudwatch-agent/logs/amazon-cloudwatch-agent.log\",
            \"log_group_name\": \"/${stackname}/cloudwatch-agent\",
            \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
          },
          {
            \"file_path\": \"/var/log/secure\",
            \"log_group_name\": \"/${stackname}/secure\",
            \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
          },
          {
            \"file_path\": \"/murex/murex_app/app/logs/errors.log\",
            \"log_group_name\": \"/${stackname}/murex_app/errors.log\",
            \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
          },
          {
            \"file_path\": \"/var/log/audit/audit.log\",
            \"log_group_name\": \"/${stackname}/auth\",
            \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
          }
        ]
      }
    }
  }
}" > /tmp/assets/params-config-cw-log-groups-murex-core.json
mv -v /tmp/assets/params-config-cw-log-groups-murex-core.json /opt/aws/amazon-cloudwatch-agent/etc/

sudo amazon-cloudwatch-agent-ctl -m ec2 -a stop
mv -v /tmp/aw0434001_murex_core_aws_cod_sop/assets_app/CW_process_murex.json  /opt/aws/amazon-cloudwatch-agent/etc/
amazon-cloudwatch-agent-ctl -a append-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/params-config-cw-log-groups-murex-core.json -s
amazon-cloudwatch-agent-ctl -a append-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/CW_process_murex.json -s
echo "Cloudwatch Agent configuration finished"


if [ $MUREX_ROLE = "orchestrator" ]; then

    echo -e "{
    \"logs\": {
        \"logs_collected\": {
        \"files\": {
            \"collect_list\": [
            {
                \"file_path\": \"/murex/murex_app/app/logs/mxgeneric_service/osp_server/service.log\",
                \"log_group_name\": \"/${stackname}/murex_app/osp_server/service.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/mxmlexchange/mxmlexchange_launcher/service.log\",
                \"log_group_name\": \"/${stackname}/murex_app/mxmlexchange_launcher/service.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/mxmlexchange/mxmlexchange/service.log\",
                \"log_group_name\": \"/${stackname}/murex_app/mxmlexchange/service.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/mxmlc/mxmlc/service.log\",
                \"log_group_name\": \"/${stackname}/murex_app/mxmlc/mxmlc/service.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/errors.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/errors.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/eod_scripts/MarketDataInfovalmer/Options/Volatility.log\",
                \"log_group_name\": \"/${stackname}/murex_app/Options/Volatility.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/eod_scripts/MarketDataInfovalmer/Options/smileCurve.log\",
                \"log_group_name\": \"/${stackname}/murex_app/Options/smileCurve.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/eod_scripts/answers/answer_cierre_colombia_2.2.xml\",
                \"log_group_name\": \"/${stackname}/murex_app/answers/answer_cierre_colombia_2.2.xml\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/mfc-module/AccountingModule.log\",
                \"log_group_name\": \"/${stackname}/murex_app/mfc-module/AccountingModule.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/impyval/preeod/bin/preeod.log\",
                \"log_group_name\": \"/${stackname}/murex_app/bin/preeod.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/impyval/bin/log4j.log\",
                \"log_group_name\": \"/${stackname}/murex_app/bin/log4j.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.mxosp.site1.public.mxres.common.launchermxosp.mxres.loadbalance_mxosp_.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/mxosp.site1.public.mxres.common.launchermxosp.mxres.loadbalance_mxosp_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}bos.site1.public.mxres.common.launcherbos.mxres.loadbalance_bos_.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/bos.site1.public.mxres.common.launcherbos.mxres.loadbalance_bos_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            }
            ]
        }
        }
    }
    }" > /tmp/assets/params-config-cw-log-groups-murex-core-orchestrator.json
    mv -v /tmp/assets/params-config-cw-log-groups-murex-core-orchestrator.json /opt/aws/amazon-cloudwatch-agent/etc/
    sudo amazon-cloudwatch-agent-ctl -m ec2 -a stop
    amazon-cloudwatch-agent-ctl -a append-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/params-config-cw-log-groups-murex-core-orchestrator.json -s
    echo "Cloudwatch Agent configuration finished"
fi

if [ $MUREX_ROLE = "mlc" ]; then

    echo -e "{
    \"logs\": {
        \"logs_collected\": {
        \"files\": {
            \"collect_list\": [
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.sessionmgmt.site1.public.mxres.mxmlc.session.launcher.launcher.mxres.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/sessionmgmt.site1.public.mxres.mxmlc.session.launcher.launcher.mxres.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            }
            ]
        }
        }
    }
    }" > /tmp/assets/params-config-cw-log-groups-murex-core-MLC.json
    mv -v /tmp/assets/params-config-cw-log-groups-murex-core-MLC.json /opt/aws/amazon-cloudwatch-agent/etc/
    sudo amazon-cloudwatch-agent-ctl -m ec2 -a stop
    amazon-cloudwatch-agent-ctl -a append-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/params-config-cw-log-groups-murex-core-MLC.json -s
    echo "Cloudwatch Agent configuration finished"
fi

if [ $MUREX_ROLE = "business" ]; then

    echo -e "{
    \"logs\": {
        \"logs_collected\": {
        \"files\": {
            \"collect_list\": [
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxprocessing.mxres.loadbalance_mxprocessing_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launchermxprocessing.mxres.loadbalance_mxprocessing_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxdealscanner.mxres.loadbalance_mxdealscanner_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launchermxdealscanner.mxres.loadbalance_mxdealscanner_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}launcher.site1.public.mxres.common.launchermxdispatcher.mxres.loadbalance_mxdispatcher_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launchermxdispatcher.mxres.loadbalance_mxdispatcher_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxdistribution.mxres.loadbalance_mxdistribution_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launchermxdistribution.mxres.loadbalance_mxdistribution_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxfinparser.mxres.loadbalance_mxfinparser_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launchermxfinparser.mxres.loadbalance_mxfinparser_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxlock.mxres.loadbalance_mxlock_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launchermxlock.mxres.loadbalance_mxlock_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.mxmlworker.site1.public.mxres.common.launchermxmlworker.mxres.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/mxmlworker.site1.public.mxres.common.launchermxmlworker.mxres.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxobjectrepository.mxres.loadbalance_mxobjectrepository_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/.launcher.site1.public.mxres.common.launchermxobjectrepository.mxres.loadbalance_mxobjectrepository_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxprocessing.mxres.loadbalance_mxprocessing_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launchermxprocessing.mxres.loadbalance_mxprocessing_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxrepository.mxres.loadbalance_mxrepository_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/.launcher.site1.public.mxres.common.launchermxrepository.mxres.loadbalance_mxrepository_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launchermxsqluserauthorizedlists.mxres.loadbalance_mxsqluserauthorizedlists_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launchermxsqluserauthorizedlists.mxres.loadbalance_mxsqluserauthorizedlists_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launcherreportsrv.mxres.loadbalance_reportsrv_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launcherreportsrv.mxres.loadbalance_reportsrv_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.mxdatapublisher.site1.public.mxres.common.launchermxdatapublisher.mxres.loadbalance_mxdatapublisher_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/mxdatapublisher.site1.public.mxres.common.launchermxdatapublisher.mxres.loadbalance_mxdatapublisher_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.aagent.site1.public.mxres.common.launcheraagent.mxres.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/aagent.site1.public.mxres.common.launcheraagent.mxres.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.dsd.site1.public.mxres.common.launcher-rdbms.mxres.loadbalance_dsd_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/dsd.site1.public.mxres.common.launcher-rdbms.mxres.loadbalance_dsd_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.feeder.site1.public.mxres.common.launchermxactivityfeeders.mxres.loadbalance_mxactivityfeeders_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/feeder.site1.public.mxres.common.launchermxactivityfeeders.mxres.loadbalance_mxactivityfeeders_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launcherhss.mxres.loadbalance_launcherhss_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launcherhss.mxres.loadbalance_launcherhss_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            },
            {
                \"file_path\": \"/murex/murex_app/app/logs/${servername}.launcher.site1.public.mxres.common.launcherhss.mxres.loadbalance_launcherhss_${HOSTNAME}.log\",
                \"log_group_name\": \"/${stackname}/murex_app/logs/launcher.site1.public.mxres.common.launcherhss.mxres.loadbalance_launcherhss_.log\",
                \"log_stream_name\": \"$EC2_INSTANCE_ID-$servername\"
            }
            ]
        }
        }
    }
    }" > /tmp/assets/params-config-cw-log-groups-murex-core-business.json
    mv -v /tmp/assets/params-config-cw-log-groups-murex-core-business.json /opt/aws/amazon-cloudwatch-agent/etc/

    sudo amazon-cloudwatch-agent-ctl -m ec2 -a stop
    amazon-cloudwatch-agent-ctl -a append-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/params-config-cw-log-groups-murex-core-business.json -s
    echo "Cloudwatch Agent configuration finished"
fi

{
aws logs describe-log-groups --query 'logGroups[].[logGroupName]' --output text | grep -E "aw0434001-murex-core-${env}-$MUREX_ENVIRONMENT-asg-$MUREX_ROLE|aw0434001-murex-core-${env}-DNS|aw0434001-murex-core-${env}-DownUpLoadDump|aw0434001-murex-core-${env}-ImpExpDump|aw0434001-murex-core-${env}-OperationsTBS|aw0434001-murex-core-${env}-ResetPassword|aw0434001-murex-core-${env}-ScriptsInicialesRDS|aw0434001-murex-core-${env}-TunningRedolog|aw0434001-murex-core-${env}-kms-policy|aw0434001-murex-core-${env}-lambda-rotation-ldap|aw0434001oraclemurexcore" > /tmp/loggroups; sleep 5
</tmp/loggroups xargs -I{} \
aws logs put-retention-policy --log-group-name  "{}" --retention-in-days ${loggroupretention}
export tagsloggroup=$(echo -e "bancolombia:pmo=$MUREX_PMO,bancolombia:servername=$(hostname -s),ec2launchtemplate:id=$EC2_INSTANCE_ID,bancolombia:application-code=${projectcode},bancolombia:environment=${env},bancolombia:murex_environment=$MUREX_ENVIRONMENT,bancolombia:project-name=${projectname},cloudformation:stack-name=${stackname}")
</tmp/loggroups xargs -I{} \
aws logs tag-log-group --log-group-name "{}"  --tags $tagsloggroup
} | tee "${AGENT_CW_LOG}"
