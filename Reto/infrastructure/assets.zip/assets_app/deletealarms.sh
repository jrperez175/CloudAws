#!/bin/bash
set -x 
export EC2_INSTANCE_ID="`wget -q -O - http://169.254.169.254/latest/meta-data/instance-id || die \"wget instance-id has failed: $?\"`"
export MUREX_ROLE=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$EC2_INSTANCE_ID" "Name=key,Values=bancolombia:murex_role" --query 'Tags[].{Value:Value}' --output text)
if [ $MUREX_ROLE = "orchestrator" ]; then

  aws cloudwatch delete-alarms --alarm-names $stackname-processmurexmxresfsfileservermxres $stackname-processMXJHUBNAME $stackname-processpublicmxrescommonlauncherallmxres $stackname-processmurexmxrescommonlaunchermandatorymxres $stackname-processpublicmxrescommonlauncherwarehousemxres $stackname-processhubmadridsite1 $stackname-processpublicmxrescommonlaunchermxhibernatemxres $stackname-processpublicmxrescommonlaunchermxcontributionmxres $stackname-processpublicmxrescommonlaunchermxcachemxres $stackname-processpublicmxrescommonlaunchermxmarketdatarepositorymxres $stackname-processpublicmxrescommonlaunchermxfederationmxres $stackname-processpublicmxrescommonlauncheralertmxres $stackname-processpublicmxrescommonlauncherstatisticsmxres $stackname-processpublicmxrescommonlauncherbosmxres $stackname-processpublicmxrescommonlaunchergcmxres $stackname-processpublicmxrescommonlaunchermxloginimplmxres $stackname-processpublicmxrescommonlaunchermxlogaccessmxres $stackname-processpublicmxrescommonlaunchermxmarketriskregistrymxres

fi
if [ $MUREX_ROLE = "business" ]; then

  aws cloudwatch delete-alarms --alarm-names $stackname-processpublicmxrescommonlauncherprintsrvmxres $stackname-processpublicmxrescommonlauncheraagentmxres $stackname-processpublicmxrescommonlaunchermxmlexchangesecondarymxres publicmxrescommonlaunchermxmlexchangespacesmxres $stackname-processpublicmxrescommonlaunchermxmlworkermxres $stackname-processpublicmxrescommonlaunchermxmlexchangeallmxres $stackname-processpublicmxrescommonlaunchermxdispatchermxres $stackname-processpublicmxrescommonlaunchermxactivityfeedersmxres $stackname-processpublicmxrescommonlauncherrdbmsmxres $stackname-processpublicmxrescommonlaunchermxlockmxres publicmxrescommonlaunchermxobjectrepositorymxres $stackname-processpublicmxrescommonlaunchermxprocessingmxres $stackname-processpublicmxrescommonlaunchermxdealscannermxres $stackname-processpublicmxrescommonlaunchermxdatapublishermxres $stackname-processpublicmxrescommonlaunchermxsqluserauthorizedlistsmxres $stackname-processpublicmxrescommonlaunchermxentitlementmxres $stackname-processpublicmxrescommonlauncherreportsrvmxres $stackname-processpublicmxrescommonlaunchermxdistributionmxres $stackname-processpublicmxrescommonlauncherhssmxres $stackname-processpublicmxrescommonlaunchermxfinparsermxres $stackname-processpublicmxrescommonlauncherireportingmxres $stackname-processpublicmxrescommonlaunchermxdispatchermxres

fi
if [ $MUREX_ROLE = "mlc" ]; then

 aws cloudwatch delete-alarms --alarm-names $stackname-processpublicmxrescommonlaunchermxmlcmxres $stackname-processpublicmxrescommonlaunchermxlrbmxres $stackname-processpublicmxrescommonlauncherltsservicemxres $stackname-processpublicmxresmxmlcloggersserviceloggermxres

fi
if [ $MUREX_ROLE = "var" ]; then

  aws cloudwatch delete-alarms --alarm-names $stackname-processpublicmxrescommonlaunchermxmarketriskenginemxmxres

fi
